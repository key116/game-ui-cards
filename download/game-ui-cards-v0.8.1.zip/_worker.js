// 游戏卡片路由核心：字段名（关键词）→ 组件，题材词 → 皮肤，上一回合 → 变化。
// 只整理数据，不生成 HTML；界面由 game-ui-widget.js 在卡片里绘制。

const KEYWORD_MAP = {
  '标题': ['标题', '游戏名', '游戏', 'title', 'game', 'gamename'],
  '题材': ['题材', '标签', '风格', 'theme', 'tags', 'genre'],
  '时间': ['时间', '回合', '天数', '日期', '倒计时', 'time', 'turn', 'day', 'clock'],
  '数值': ['状态', '数值', '属性', 'stats', 'status', '生命', 'hp', '血量', '体力', '理智', 'san', '幸运', '魔力', 'mp',
    '精力', '饱食', '水分', '金币', '金钱', 'gold', '钱', '体面', '奶酪', '声望', '压力', '污染'],
  '地点': ['地点', '场景', '位置', '所在', 'location', 'scene', 'place', 'room', 'locationname'],
  '事件': ['事件', '提示', '消息', '通知', 'event', 'notice', 'message'],
  '判定': ['判定', '检定', '骰子', '掷骰', '鉴定', 'roll', 'check', 'dice'],
  '道具': ['背包', '物品', '道具', '装备', 'inventory', 'items', 'bag'],
  '线索': ['线索', '证据', '笔记', 'clues', 'evidence', 'notes'],
  '人物': ['人物', '角色', 'npc', 'npcs', 'characters', 'people', '同伴', '队友'],
  '关系': ['关系', '好感', '信任', 'relations', 'relationship', 'trust'],
  '任务': ['任务', '目标', '任务清单', 'quests', 'quest', 'objectives', 'tasks', 'todo'],
  '选项': ['选项', '行动', '可选行动', 'choices', 'options', 'actions'],
  '氛围': ['天气', '紧张度', '紧张', '气氛', '氛围', '温度', '月相', '地形', '环境', 'weather', 'tension', 'mood', 'temperature', 'terrain'],
  '字段': ['字段', '字段定义', '字段声明', 'fields', 'schema']
};

// 章节皮肤（按 AI 游戏总纲 §四，只增不改）：A 纸面档案（默认）、B 剧场报幕（地点/章节）、C 异常终端（调查、科幻、恐怖）、
// D 霓虹街区（赛博朋克）、E 像素冒险海报（8-bit 复古）。按命中的最长关键词打分，不再固定先查 C。
const CHAPTER_MAP = {
  C: ['科幻', '太空', '末日', '废土', '未来', '规则怪谈', '调查', '侦探', '悬疑', '推理', '恐怖', '克苏鲁', 'coc',
    '惊悚', '终端', '密室', '刑侦', '诡异', 'scifi', 'space', 'horror', 'mystery', 'detective'],
  B: ['剧场', '舞台', '宫廷', '歌剧', '戏剧', '话剧', '戏班', 'theater', 'theatre'],
  D: ['赛博', '赛博朋克', '霓虹', '黑客', '义体', '仿生', '赛博城', '夜之城', '电子', '蒸汽波', '合成波', 'cyberpunk', 'cyber', 'neon', 'hacker', 'synthwave', 'vaporwave'],
  E: ['像素', '8bit', '8-bit', '8位', '八位', '复古', '街机', '红白机', '地下城', '勇者', '魔王', '打怪', '刷怪', 'rpg', 'pixel', 'retro', 'arcade', 'dungeon', 'roguelike', '肉鸽'],
  A: ['中世纪', '奇幻', '搞笑', '童话', '冒险', '武侠', '仙侠', '古风', '日常', '经营', 'fantasy', 'medieval', 'comedy']
};

const SKIN_LABEL = { A: '纸面档案', B: '剧场报幕', C: '异常终端', D: '霓虹街区', E: '像素冒险海报' };
// 玩家/AI 直接点名皮肤时用的名字。
const SKIN_ALIAS = { a: 'A', b: 'B', c: 'C', d: 'D', e: 'E', '纸面': 'A', '纸面档案': 'A', '羊皮纸': 'A', '剧场': 'B', '剧场报幕': 'B',
  '终端': 'C', '异常终端': 'C', '霓虹': 'D', '霓虹街区': 'D', '赛博': 'D', '赛博朋克': 'D', '像素': 'E', '像素冒险海报': 'E', '8bit': 'E', '8-bit': 'E', '复古像素': 'E' };
function parseSkin(v) {
  const t = String(v ?? '').trim().toLowerCase();
  if (!t || t === '自动' || t === 'auto') return null;
  return SKIN_ALIAS[t] || null;
}
const CARD_LABEL = { choice: '选择卡', map: '地图节点选择卡', status: '状态卡', location: '地点卡', items: '物品卡', character: '角色卡' };
const ORDER = ['事件', '判定', '地点', '道具', '线索', '人物', '关系', '任务', '其他'];

const NAME = ['名称', '名字', 'name', 'title', '标题', '内容', '文字', 'text', 'label'];
const DESC = ['说明', '描述', '备注', '身份', '效果', 'desc', 'description', 'note', 'detail'];
const CLOCK_LABEL = { time: '时间', clock: '时间', turn: '回合', day: '天数', date: '日期' };
const PLACE_ICONS = ['📍', '🗺', '🗺️', '🏠', '🏰', '📌'];
const LIMITS = { text: 300, list: 30, choices: 6 };

const isObj = v => v !== null && typeof v === 'object' && !Array.isArray(v);
const clip = (v, n = LIMITS.text) => String(v ?? '').slice(0, n);

// 字段名前面的表情或符号当作图标，后面的文字拿去匹配关键词。例：“🔍 线索” → 图标 🔍，名字 线索。
function splitIcon(key) {
  const m = String(key ?? '').trim().match(/^([^\p{L}\p{N}\s]+)\s*(.*)$/u);
  if (m && m[2]) return { icon: m[1].slice(0, 4), label: m[2].trim() };
  return { icon: '', label: String(key ?? '').trim() };
}

function matchComponent(key) {
  const k = splitIcon(key).label.toLowerCase();
  for (const [comp, words] of Object.entries(KEYWORD_MAP)) if (words.includes(k)) return comp;
  let best = null, bestLen = 0;
  for (const [comp, words] of Object.entries(KEYWORD_MAP)) {
    for (const w of words) if (w.length >= 2 && k.includes(w) && w.length > bestLen) { best = comp; bestLen = w.length; }
  }
  return best;
}

function pickChapter(themeText) {
  const t = String(themeText || '').toLowerCase();
  if (!t) return null;
  let best = null, score = 0;
  for (const chapter of ['D', 'E', 'C', 'B', 'A']) {
    let sc = 0;
    for (const w of CHAPTER_MAP[chapter]) if (t.includes(w)) sc += w.length;
    if (sc > score) { best = chapter; score = sc; }
  }
  return best;
}

const REQUEST = { '状态': 'status', '状态卡': 'status', '地点': 'location', '地点卡': 'location', '地图': 'map', '物品': 'items', '背包': 'items',
  '物品卡': 'items', '线索': 'items', '角色': 'character', '人物': 'character', '角色卡': 'character', '选择': 'choice', '选择卡': 'choice' };

const filled = v => Array.isArray(v) ? v.length > 0 : !!v;

// 每次只出一张卡（总纲：每轮只渲染有变化的一张卡；一次不渲染多张）。
function pickCard(view, changes, requested, chapter) {
  const has = s => changes.sections.includes(s);
  const want = REQUEST[String(requested || '').trim()];
  let type;
  if (want === 'map' && view['地点']?.points?.length) type = 'map';
  else if (want === 'location' && view['地点']) type = 'location';
  else if (want === 'items' && (filled(view['道具']) || filled(view['线索']))) type = 'items';
  else if (want === 'character' && filled(view['人物'])) type = 'character';
  else if (want === 'status') type = 'status';
  else if (want === 'choice' && filled(view['选项'])) type = 'choice';
  else if (filled(view['选项'])) type = 'choice';
  else if (view['地点']?.points?.length && (changes.first || has('地点'))) type = 'map';
  else if (view['地点'] && has('地点')) type = 'location';
  else if (changes.newItems.length || changes.newClues.length) type = 'items';
  else if (changes.newPeople.length || has('关系')) type = 'character';
  else type = 'status';

  let variant = '';
  if (type === 'choice') {
    const statChanged = Object.keys(changes.statDelta).some(k => !k.startsWith('关系:'));
    variant = chapter === 'C' ? 'terminal' : (view['数值'].length && (changes.first || statChanged)) ? 'with-status' : 'compact';
  }
  // C/D/E 整局统一皮肤；A 局里地点和地图卡用 B 剧场报幕。
  const skin = ['C', 'D', 'E', 'B'].includes(chapter) ? chapter : (type === 'location' || type === 'map') ? 'B' : 'A';
  return { type, variant, skin };
}

function first(obj, keys, fallback = undefined) {
  if (!isObj(obj)) return fallback;
  for (const k of keys) if (obj[k] !== undefined && obj[k] !== null && obj[k] !== '') return obj[k];
  return fallback;
}
const asList = v => v === undefined || v === null ? [] : Array.isArray(v) ? v : [v];

function num(v) {
  if (typeof v === 'boolean' || v === null || v === undefined || v === '') return null;
  const n = typeof v === 'number' ? v : Number(String(v).trim());
  return Number.isFinite(n) ? n : null;
}
const isStatObj = v => isObj(v) && ['值', '当前', 'value', 'current', '上限', 'max'].some(k => k in v);

function stat(rawLabel, raw) {
  const { icon, label } = splitIcon(rawLabel);
  let value = null, max = null, text = null;
  if (typeof raw === 'boolean') text = raw ? '是' : '否';
  else if (typeof raw === 'number') value = Number.isFinite(raw) ? raw : null;
  else if (isObj(raw)) {
    value = num(first(raw, ['值', '当前', 'value', 'current']));
    max = num(first(raw, ['上限', 'max', '最大']));
    if (value === null) text = clip(first(raw, ['值', '当前', 'value', 'current'], ''), 40);
  } else {
    const s = String(raw ?? '').trim();
    const m = s.match(/^(-?\d+(?:\.\d+)?)\s*\/\s*(\d+(?:\.\d+)?)$/);
    const pct = s.match(/^(-?\d+(?:\.\d+)?)\s*%$/);
    if (m) { value = Number(m[1]); max = Number(m[2]); }
    else if (pct) { value = Number(pct[1]); max = 100; }
    else if (num(s) !== null) value = num(s);
    else text = clip(s, 40);
  }
  return { label: clip(label, 20), icon, value, max: max || null, text };
}

function named(item) {
  if (isObj(item)) {
    let name = first(item, NAME), desc = first(item, DESC, '');
    if (name === undefined && Object.keys(item).length === 1) [name, desc] = Object.entries(item)[0];
    return { name: clip(name ?? '未命名', 60), desc: clip(isObj(desc) ? JSON.stringify(desc) : desc, 160), raw: item };
  }
  return { name: clip(item, 60), desc: '', raw: null };
}

// 把“📍 灯塔底层 | 🔍 线索 8 | ⏳ 时间线 2/15”这类状态行拆成地点和数值。至少两段、用 | 分开才算。
function parseStatusLine(text) {
  const lines = String(text ?? '').split(/\r?\n/);
  const out = { place: null, stats: [], moods: [], rest: String(text ?? '') };
  const idx = lines.findIndex(l => l.split(/[|｜]/).filter(x => x.trim()).length >= 2);
  if (idx < 0) return out;
  for (const seg of lines[idx].split(/[|｜]/).map(x => x.trim()).filter(Boolean)) {
    const { icon, label } = splitIcon(seg);
    const m = label.match(/^(.*?)\s*[:：]?\s*(-?\d+(?:\.\d+)?(?:\s*\/\s*\d+(?:\.\d+)?)?%?)$/);
    if (m && m[1]) out.stats.push(stat((icon ? icon + ' ' : '') + m[1], m[2].replace(/\s+/g, '')));
    else if (m && !m[1]) out.stats.push(stat((icon ? icon + ' ' : '') + '数值', m[2]));
    else if (!out.place && (PLACE_ICONS.includes(icon) || matchComponent(label) === '地点')) out.place = clip(label, 40);
    else {
      const sp = label.match(/^(\S+)\s+(.+)$/);
      if (sp && matchComponent(sp[1]) === '氛围') out.moods.push({ icon, label: clip(sp[1], 12), text: clip(sp[2], 30) });
      else out.moods.push({ icon, label: '', text: clip(label, 30) });
    }
  }
  out.rest = lines.filter((_, i) => i !== idx).join('\n').trim();
  return out;
}

const done = v => typeof v === 'boolean' ? v : ['完成', '已完成', 'done', 'true', 'yes', '是', '✓', '√'].includes(String(v ?? '').trim().toLowerCase());

function normalizeState(state) {
  if (typeof state === 'string') { try { state = JSON.parse(state); } catch { state = { '事件': state }; } }
  if (!isObj(state)) state = {};
  const view = { '数值': [], '时间': [], '事件': [], '道具': [], '线索': [], '人物': [], '关系': [], '任务': [], '选项': [], '其他': [], '氛围': [] };
  let theme = '', fields = null;
  for (const [key, value] of Object.entries(state).slice(0, 40)) {
    const comp = matchComponent(key);
    if (comp === '标题') view['标题'] = clip(value, 40);
    else if (comp === '题材') theme = Array.isArray(value) ? value.join(' ') : String(value);
    else if (comp === '字段') fields = isObj(value) ? value : null;
    else if (comp === '氛围') {
      if (isObj(value) && !isStatObj(value)) for (const [k, v] of Object.entries(value).slice(0, 6)) view['氛围'].push({ ...splitIcon(k), text: clip(isObj(v) ? first(v, ['值', 'value', '描述'], '') : v, 30) });
      else view['氛围'].push({ ...splitIcon(key), text: clip(value, 30) });
    }
    else if (comp === '时间') view['时间'].push({ label: CLOCK_LABEL[String(key).trim().toLowerCase()] || clip(key, 12), text: clip(value, 40) });
    else if (comp === '数值') {
      if (isObj(value) && !isStatObj(value)) for (const [k, v] of Object.entries(value).slice(0, 12)) view['数值'].push(stat(k, v));
      else if (Array.isArray(value)) for (const it of value.slice(0, 12)) { if (isObj(it)) view['数值'].push(stat(first(it, NAME, '数值'), it)); }
      else view['数值'].push(stat(key, value));
    } else if (comp === '地点') {
      if (isObj(value)) {
        const points = [
          ...asList(first(value, ['可探索', '探索点', '互动点', 'points', 'explore'])).slice(0, 8).map(p => ({ name: named(p).name, danger: false })),
          ...asList(first(value, ['危险', '警告', 'danger', 'hazards'])).slice(0, 8).map(p => ({ name: named(p).name, danger: true }))
        ];
        view['地点'] = { name: clip(first(value, [...NAME, '地点', 'location'], '未知地点'), 40), desc: clip(first(value, DESC, '')), points, progress: clip(first(value, ['探索度', '进度', 'progress'], ''), 8), alert: clip(first(value, ['突发', '突发事件', 'alert'], ''), 80) };
      } else view['地点'] = { name: clip(value, 40), desc: '', points: [], progress: '', alert: '' };
    } else if (comp === '事件') view['事件'].push(...asList(value).slice(0, 4).map(v => typeof v === 'string' ? clip(v, 400) : named(v).name));
    else if (comp === '判定') {
      view['判定'] = isObj(value)
        ? { name: clip(first(value, ['项目', '技能', '属性', 'name', 'skill'], '判定'), 20), roll: clip(first(value, ['骰值', '点数', '掷出', 'roll', 'value'], '?'), 12),
            target: clip(first(value, ['目标', '难度', '目标值', 'target', 'difficulty'], ''), 12), result: clip(first(value, ['结果', 'outcome', 'result'], ''), 12) }
        : { name: '判定', roll: '?', target: '', result: clip(value, 12) };
    } else if (comp === '道具') {
      if (isObj(value) && !NAME.some(k => k in value)) view['道具'] = Object.entries(value).slice(0, LIMITS.list).map(([k, v]) => ({ name: clip(k, 60), desc: '', qty: num(v) }));
      else view['道具'] = asList(value).slice(0, LIMITS.list).map(it => { const n = named(it); return { name: n.name, desc: n.desc, qty: n.raw ? num(first(n.raw, ['数量', 'qty', 'count'])) : null }; });
    } else if (comp === '线索') {
      view['线索'] = asList(value).slice(0, LIMITS.list).map(it => { const n = named(it); return { name: n.name, desc: n.raw ? clip(first(n.raw, ['内容', ...DESC], n.desc), 160) : '' }; });
    } else if (comp === '人物') {
      view['人物'] = asList(value).slice(0, LIMITS.list).map(it => {
        const n = named(it);
        let rel = null, relLabel = '';
        for (const rk of ['信任', '好感', '关系', 'trust', 'affinity']) {
          if (n.raw && n.raw[rk] !== undefined && n.raw[rk] !== null && n.raw[rk] !== '') { rel = clip(n.raw[rk], 12); relLabel = { trust: '信任', affinity: '好感' }[rk] || rk; break; }
        }
        return { name: n.name, desc: n.desc, rel, relLabel };
      });
    } else if (comp === '关系') {
      view['关系'] = isObj(value)
        ? Object.entries(value).slice(0, LIMITS.list).map(([k, v]) => stat(k, v))
        : asList(value).filter(isObj).slice(0, LIMITS.list).map(it => stat(first(it, [...NAME, '对象'], '?'), first(it, ['值', '信任', '好感', 'value'], '')));
    } else if (comp === '任务') {
      if (isObj(value) && !NAME.some(k => k in value)) view['任务'] = Object.entries(value).slice(0, LIMITS.list).map(([k, v]) => ({ name: clip(k, 60), done: done(v) }));
      else view['任务'] = asList(value).slice(0, LIMITS.list).map(it => { const n = named(it); return { name: n.name, done: n.raw ? done(first(n.raw, ['完成', '已完成', 'done', '状态', 'status'])) : false }; });
    } else if (comp === '选项') {
      view['选项'] = asList(value).map(it => { const n = named(it); return { text: clip(n.name, 80).trim(), desc: n.desc }; }).filter(o => o.text).slice(0, LIMITS.choices);
    } else if ((typeof value === 'number' && Number.isFinite(value)) || isStatObj(value) || (typeof value === 'string' && /^-?\d+(?:\.\d+)?\s*(?:\/\s*\d+(?:\.\d+)?|%)$/.test(value.trim()))) {
      view['数值'].push(stat(key, value));
    } else {
      const text = Array.isArray(value) ? value.map(v => named(v).name).join('、') : isObj(value) ? JSON.stringify(value) : String(value);
      view['其他'].push({ label: clip(key, 20), text: clip(text, 160) });
    }
  }
  // 事件文字里夹带的状态行：拆出来变成地点和数值，原文去掉这一行。
  view['事件'] = view['事件'].map(t => {
    const p = parseStatusLine(t);
    if (!p.stats.length && !p.place && !p.moods.length) return t;
    const known = new Set(view['数值'].map(s => s.label));
    for (const st of p.stats) if (!known.has(st.label)) view['数值'].push(st);
    if (p.place && !view['地点']) view['地点'] = { name: p.place, desc: '', points: [], progress: '', alert: '' };
    view['氛围'].push(...p.moods);
    return p.rest;
  }).filter(Boolean);
  return { view, theme, fields };
}

const names = (view, comp) => new Set((view?.[comp] || []).map(x => x.name));
const minus = (a, b) => [...a].filter(x => !b.has(x));
const round = d => Number.isInteger(d) ? d : Math.round(d * 100) / 100;

function diffViews(prev, cur) {
  const firstTurn = !prev;
  prev = prev || {};
  const ch = { first: firstTurn, statDelta: {}, newItems: [], newClues: [], newPeople: [], questChanged: [], moodChanged: [], sections: [], summary: [], warnings: [] };
  const sections = new Set();
  const prevStats = new Map((prev['数值'] || []).map(s => [s.label, s]));
  for (const s of cur['数值'] || []) {
    const p = prevStats.get(s.label);
    if (p && typeof s.value === 'number' && typeof p.value === 'number' && s.value !== p.value) {
      const d = round(s.value - p.value);
      ch.statDelta[s.label] = d;
      ch.summary.push(s.label + (d > 0 ? '+' : '') + d);
    } else if (p && s.text && s.text !== p.text) ch.statDelta[s.label] = '变';
  }
  const prevRel = new Map((prev['关系'] || []).map(s => [s.label, s]));
  for (const s of cur['关系'] || []) {
    const p = prevRel.get(s.label);
    if (p && typeof s.value === 'number' && typeof p.value === 'number' && s.value !== p.value) { ch.statDelta['关系:' + s.label] = round(s.value - p.value); sections.add('关系'); }
  }
  for (const [comp, key, word] of [['道具', 'newItems', '获得'], ['线索', 'newClues', '新线索'], ['人物', 'newPeople', '遇见']]) {
    if (firstTurn) continue;
    const added = minus(names(cur, comp), names(prev, comp));
    ch[key] = added;
    if (added.length) { sections.add(comp); ch.summary.push(word + '：' + added.join('、')); }
    if (minus(names(prev, comp), names(cur, comp)).length) sections.add(comp);
  }
  const prevQ = new Map((prev['任务'] || []).map(q => [q.name, q.done]));
  if (!firstTurn) for (const q of cur['任务'] || []) {
    if (!prevQ.has(q.name) || prevQ.get(q.name) !== q.done) {
      ch.questChanged.push(q.name); sections.add('任务');
      ch.summary.push((q.done ? '完成任务：' : '新任务：') + q.name);
    }
  }
  if ((cur['地点'] || {}).name !== (prev['地点'] || {}).name) {
    sections.add('地点');
    if (!firstTurn && cur['地点']) ch.summary.push('来到：' + cur['地点'].name);
  }
  const prevMood = new Map((prev['氛围'] || []).map(m => [m.label || m.icon, m.text]));
  ch.moodChanged = [];
  if (!firstTurn) for (const m of cur['氛围'] || []) {
    const k = m.label || m.icon;
    if (prevMood.has(k) && prevMood.get(k) !== m.text) { ch.moodChanged.push(k); ch.summary.push((m.label || m.icon) + '：' + m.text); }
  }
  for (const comp of ['事件', '判定', '其他']) if (cur[comp] && (!Array.isArray(cur[comp]) || cur[comp].length)) sections.add(comp);
  if (firstTurn) for (const comp of ORDER) if (cur[comp] && (!Array.isArray(cur[comp]) || cur[comp].length)) sections.add(comp);
  ch.sections = [...sections];
  return ch;
}

function shownComponents(view) {
  return [...ORDER, '数值', '选项'].filter(c => view[c] && (!Array.isArray(view[c]) || view[c].length));
}

// 字段声明（借鉴 Doom's Enhancement Suite 的字段类型和锁定）：
// {"饥饿": {"类型": "数字", "范围": "0-10", "图标": "🍞"}, "紧张度": {"类型": "枚举", "选项": ["平静","不安","紧张"]}, "王冠": {"锁定": true}}
const TYPE_ALIAS = { '数字': 'number', 'number': 'number', '进度': 'progress', 'progress': 'progress', '枚举': 'enum', '选项': 'enum', 'enum': 'enum',
  '文字': 'text', 'text': 'text', '真假': 'bool', 'boolean': 'bool', 'bool': 'bool' };

function normalizeFields(raw) {
  const out = {};
  if (!isObj(raw)) return out;
  for (const [k, v] of Object.entries(raw).slice(0, 20)) {
    const { icon, label } = splitIcon(k);
    const d = isObj(v) ? v : { '类型': v };
    const range = String(first(d, ['范围', 'range'], '')).match(/(-?\d+(?:\.\d+)?)\s*[-~～到至]\s*(-?\d+(?:\.\d+)?)/);
    out[clip(label, 20)] = {
      type: TYPE_ALIAS[String(first(d, ['类型', 'type'], 'text')).toLowerCase()] || 'text',
      min: range ? Number(range[1]) : (num(first(d, ['最小', 'min'])) ?? null),
      max: range ? Number(range[2]) : (num(first(d, ['最大', '上限', 'max'])) ?? null),
      options: asList(first(d, ['选项', 'options'], [])).map(x => clip(x, 20)).slice(0, 12),
      icon: clip(first(d, ['图标', 'icon'], icon), 4),
      locked: first(d, ['锁定', 'locked'], false) === true
    };
  }
  return out;
}

// 按声明校正这一回合的数据：数字夹到范围内、枚举只认列出的词、锁定的值保持上一回合。返回提醒文字。
function applyFields(view, fields, prevView) {
  const warnings = [];
  const prevStats = new Map((prevView?.['数值'] || []).map(s => [s.label, s]));
  const prevMood = new Map((prevView?.['氛围'] || []).map(m => [m.label, m]));
  for (const [label, f] of Object.entries(fields || {})) {
    const st = view['数值'].find(s => s.label === label);
    const md = view['氛围'].find(m => m.label === label);
    if (st) {
      if (f.icon && !st.icon) st.icon = f.icon;
      if (f.type === 'progress') st.max = st.max || 100;
      if (f.max !== null && !st.max && f.type !== 'enum') st.max = f.max;
      if (typeof st.value === 'number' && (f.min !== null || f.max !== null)) {
        const clamped = Math.min(f.max ?? Infinity, Math.max(f.min ?? -Infinity, st.value));
        if (clamped !== st.value) { warnings.push(label + ' 超出范围，已按 ' + (f.min ?? '') + '~' + (f.max ?? '') + ' 显示为 ' + clamped); st.value = clamped; }
      }
      if (f.type === 'enum' && st.text && f.options.length && !f.options.includes(st.text)) {
        const keep = prevStats.get(label)?.text || f.options[0];
        warnings.push(label + ' 只能是 ' + f.options.join('/') + '，“' + st.text + '”不在其中，已保持 ' + keep); st.text = keep;
      }
      const p = prevStats.get(label);
      if (f.locked && p && (p.value !== st.value || p.text !== st.text)) {
        warnings.push(label + ' 是锁定值，不能由叙事修改，已保持 ' + (p.value ?? p.text)); st.value = p.value; st.text = p.text; st.max = p.max;
      }
    }
    if (md) {
      if (f.icon && !md.icon) md.icon = f.icon;
      if (f.type === 'enum' && f.options.length && !f.options.includes(md.text)) {
        const keep = prevMood.get(label)?.text || f.options[0];
        warnings.push(label + ' 只能是 ' + f.options.join('/') + '，已保持 ' + keep); md.text = keep;
      }
      const p = prevMood.get(label);
      if (f.locked && p && p.text !== md.text) { warnings.push(label + ' 是锁定值，已保持 ' + p.text); md.text = p.text; }
    }
    if (!st && !md && f.locked) {
      const p = prevStats.get(label);
      if (p) view['数值'].push({ ...p });
    }
  }
  return warnings;
}


const GAME_UI_URI = 'ui://b-game-ui/router-v5.html';

const gameUiMeta = {
  ui: { resourceUri: GAME_UI_URI, visibility: ['model', 'app'] },
  'openai/outputTemplate': GAME_UI_URI,
  'openai/widgetAccessible': true,
  'openai/toolInvocation/invoking': '正在绘制游戏界面…',
  'openai/toolInvocation/invoked': '游戏界面已显示'
};

const gameUiTools = [
  {
    name: 'render_game_ui',
    title: '显示游戏界面卡片',
    description:
      '把当前游戏状态显示成游戏 UI 卡片。每回合先写 2～4 句叙事，再调用一次本工具，放在回复最后。' +
      '每次只显示一张卡，由工具按字段名和本回合变化自动决定：有选项出选择卡（顶部带判定和本回合变化），否则按变化出地点卡、物品卡、角色卡或状态卡；按题材词选择皮肤（五套：纸面档案、剧场报幕、异常终端、霓虹街区=赛博朋克、像素冒险海报=8-bit 复古），也可以用 skin 直接指定，指定一次整局沿用。' +
      '玩家想单独看背包、状态、人物或地点时，把 card 设为“背包”“状态”“人物”“地点”。' +
      '字段名前可以加一个表情当图标（如 "🍞 饥饿": 6）。数值写法：数字、"当前/上限"、"40%"。天气、紧张度、氛围类字段会显示在卡片顶部的场景条。' +
      '新游戏第一次调用时用 fields 声明字段类型，之后会自动按声明校正：{"体面":{"类型":"数字","范围":"0-10"},"紧张度":{"类型":"枚举","选项":["平静","不安","紧张","敌对"]},"王冠":{"锁定":true}}。锁定的值叙事不能改，改了会被保持原值并提醒你。' +
      'state 用中文字段名，每回合交完整的当前状态，没有的字段不填。示例：' +
      '{"标题":"面包店学徒","回合":3,"数值":{"铜币":12,"体力":"6/10"},"地点":{"名称":"面包店后厨","描述":"一句画面描写","可探索":["烤炉","面粉仓"],"危险":["发烫的铁盘"]},' +
      '"事件":"猫从窗台跳下来，叼走了一个牛角包","判定":{"项目":"追猫","骰值":34,"目标":50,"结果":"成功"},"背包":[{"名称":"老面种","说明":"师傅留下的"}],' +
      '"线索":["面粉仓里有小脚印"],"人物":[{"名称":"老板娘","备注":"嘴硬心软","好感":2}],"任务":[{"名称":"天亮前烤好三十个面包","完成":false}],' +
      '"选项":["把牛角包抢回来","先把烤炉的火调小","去面粉仓看看脚印"]}。选项写成玩家会说出口的完整行动句，2～4 个。' +
      '调用后不要在文字里再罗列数值、背包或选项；玩家点卡片上的选项后，那句行动会作为玩家消息发来。',
    inputSchema: {
      type: 'object',
      properties: {
        state: { type: 'object', additionalProperties: true, description: '当前完整游戏状态，中文字段名。' },
        theme: { type: 'string', maxLength: 60, description: '题材词，如“中世纪 搞笑”“克苏鲁”“赛博朋克”。新游戏第一次调用时填。' },
        new_game: { type: 'boolean', description: '开始新的一局时为 true，清掉上一局的对比记录。' },
        card: { type: 'string', enum: ['自动', '选择', '状态', '背包', '人物', '地点', '地图'], description: '默认自动。玩家要求看某张卡时才指定。' },
        game_id: { type: 'string', maxLength: 40, description: '本局编号。新游戏第一次调用后工具会返回一个，之后每次调用都原样带上。' },
        skin: { type: 'string', enum: ['自动', '纸面档案', '剧场报幕', '异常终端', '霓虹街区', '像素冒险海报'], description: '可选，直接指定皮肤；玩家点名风格（如“赛博朋克”“8bit 像素”）时用。指定后整局沿用，换回自动按题材判断。' },
        fields: { type: 'object', additionalProperties: true, description: '可选。字段声明：类型（数字/进度/枚举/文字/真假）、范围、选项、图标、锁定。声明一次即可，之后沿用。' }
      },
      required: ['state'],
      additionalProperties: false
    },
    annotations: { readOnlyHint: false, destructiveHint: false, openWorldHint: false, idempotentHint: false },
    _meta: gameUiMeta
  }
];

class GameUiError extends Error {}

async function sha(text) {
  const digest = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(text));
  return [...new Uint8Array(digest)].map(n => n.toString(16).padStart(2, '0')).join('').slice(0, 32);
}

async function readRecord(store, key) {
  const object = await store.get(key);
  if (!object) return { record: null, etag: null };
  try {
    const record = await object.json();
    return { record: record?.schemaVersion === 2 ? record : null, etag: object.etag };
  } catch {
    return { record: null, etag: object.etag };
  }
}

async function writeRecord(store, key, etag, record) {
  return store.put(key, JSON.stringify(record), {
    httpMetadata: { contentType: 'application/json' },
    onlyIf: etag ? { etagMatches: etag } : new Headers({ 'If-None-Match': '*' })
  });
}

// 可选：部署时用环境变量 ENGINE_SKINS 指定某些外部游戏固定用哪套皮肤，例如 {"my-mystery-game":"C"}。
function engineSkin(raw, key) {
  try { const m = typeof raw === 'string' ? JSON.parse(raw) : raw; const v = m && m[key]; return /^[A-E]$/.test(v || '') ? v : null; } catch { return null; }
}

async function renderPipeline({ view, themeText, fieldsDecl, newGame, cardRequest, store, key, fixedChapter, skinRequest }) {
  let previous = null, etag = null;
  if (store) {
    try { ({ record: previous, etag } = await readRecord(store, key)); } catch { previous = null; }
  }
  if (newGame === true) previous = null;
  if (previous && view['标题'] && previous.view?.['标题'] && previous.view['标题'] !== view['标题']) previous = null;
  if (!view['标题'] && previous?.view?.['标题']) view['标题'] = previous.view['标题'];

  const fields = { ...(previous?.fields || {}), ...normalizeFields(fieldsDecl) };
  const warnings = applyFields(view, fields, previous?.view || null);
  // 皮肤优先级：本次指定 > 本局之前指定 > 引擎固定 > 本次题材词 > 上回合 > A。
  const pinned = skinRequest === undefined ? (previous?.pinnedSkin || null) : parseSkin(skinRequest);
  const autoChapter = fixedChapter || pickChapter(themeText) || previous?.autoChapter || (previous && !previous.pinnedSkin ? previous.chapter : null) || 'A';
  const chapter = pinned || autoChapter;
  const changes = diffViews(previous?.view || null, view);
  changes.warnings = warnings;
  const card = pickCard(view, changes, cardRequest, chapter);
  const turnIndex = (previous?.turnIndex || 0) + 1;

  let saved = false;
  if (store) {
    const record = { schemaVersion: 2, chapter, autoChapter, pinnedSkin: pinned, fields, view, turnIndex, updatedAt: new Date().toISOString() };
    try {
      saved = !!(await writeRecord(store, key, etag, record));
      if (!saved) {
        const again = await readRecord(store, key);
        saved = !!(await writeRecord(store, key, again.etag, record));
      }
    } catch { saved = false; }
  }

  const text =
    '已显示一张' + CARD_LABEL[card.type] + '（皮肤 ' + card.skin + ' ' + SKIN_LABEL[card.skin] + '）。' +
    (changes.summary.length ? '本回合变化：' + changes.summary.join('；') + '。' : '') +
    (warnings.length ? '数据校正：' + warnings.join('；') + '。下回合请按校正后的值继续。' : '') +
    (saved ? '' : '（本回合对比记录未能保存，下回合的变化高亮可能不准，不影响游戏。）') +
    (card.type === 'choice' || card.type === 'map' ? '选项已在卡片上，不要在文字里重复选项；等玩家点选或自己打字。' : '这回合没有选项按钮，可以在文字里简短问玩家想做什么。') +
    '不要在文字里罗列数值和背包。';

  return {
    content: [{ type: 'text', text }],
    structuredContent: { kind: 'game-ui', schemaVersion: 2, card, chapter, turnIndex, view, changes }
  };
}

// 记录归属：私人部署整份归主人；公开部署按平台给的匿名用户号（有就用）分人，再按 game_id 分局。
function ownerOf(userId, meta) {
  if (userId !== 'public') return userId || 'anonymous';
  const subject = meta && typeof meta['openai/subject'] === 'string' ? meta['openai/subject'] : '';
  return 'public:' + (subject || 'anon');
}
function cleanId(v) { return typeof v === 'string' ? v.trim().replace(/[^\w-]/g, '').slice(0, 40) : ''; }
function newGameId() {
  const abc = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789', r = crypto.getRandomValues(new Uint8Array(8));
  return 'G' + [...r].map(n => abc[n % abc.length]).join('');
}

async function callGameUiTool(name, args, store, userId, meta) {
  if (name !== 'render_game_ui') throw new GameUiError('未知游戏界面工具。');
  if (!args || typeof args !== 'object' || Array.isArray(args)) throw new GameUiError('参数必须是对象。');
  if (Object.keys(args).some(k => !['state', 'theme', 'new_game', 'card', 'fields', 'skin', 'game_id'].includes(k))) throw new GameUiError('包含未知参数。');
  if (args.theme !== undefined && typeof args.theme !== 'string') throw new GameUiError('theme 必须是文字。');
  if (args.card !== undefined && typeof args.card !== 'string') throw new GameUiError('card 必须是文字。');
  if (args.skin !== undefined && typeof args.skin !== 'string') throw new GameUiError('skin 必须是文字。');

  const { view, theme: themeInState, fields } = normalizeState(args.state);
  const userHash = await sha(ownerOf(userId, meta));
  let gameId = cleanId(args.game_id);
  const issued = !gameId && args.new_game === true && userId === 'public';
  if (issued) gameId = newGameId();
  const result = await renderPipeline({
    view, themeText: args.theme || themeInState, fieldsDecl: args.fields || fields, newGame: args.new_game, cardRequest: args.card,
    store, key: 'b-game-ui/v2/' + userHash + '/' + (gameId ? 'g-' + (await sha(gameId)) : 'current') + '.json', skinRequest: args.skin
  });
  if (gameId) {
    result.structuredContent.gameId = gameId;
    result.content[0].text = (issued ? '本局编号 game_id = ' + gameId + '，之后每次调用 render_game_ui 都原样带上它。' : '') + result.content[0].text;
  } else if (userId === 'public') {
    result.content[0].text += '（提醒：没带 game_id，变化对比可能和别人的记录混在一起；新游戏请设 new_game 为 true 领取编号。）';
  }
  return result;
}

// 外部游戏引擎返回的画面 → 同一套卡片。按存档分别记录上一回合，规则和存档仍由那个引擎负责。
async function callGameViewTool(args, store, userId, meta, engineSkins) {
  if (!args || typeof args !== 'object' || Array.isArray(args)) throw new GameUiError('参数必须是对象。');
  if (Object.keys(args).some(k => !['view', 'theme', 'card', 'skin', 'game_id'].includes(k))) throw new GameUiError('包含未知参数。');
  const root = args.view && typeof args.view === 'object' ? args.view : {};
  const v = root.view && typeof root.view === 'object' ? root.view : root.structuredContent?.view || root;
  const state = {};
  state['标题'] = v.gameName || v.title || '游戏';
  if (v.turn !== undefined && v.turn !== null) state['回合'] = v.turn;
  if (v.scene || v.sceneText) state['事件'] = String(v.scene || v.sceneText);
  for (const k of ['location', 'locationName', 'evidence', 'clues', 'inventory', 'people', 'npcs', 'objectives', 'tasks', 'status']) if (v[k] !== undefined) state[k] = v[k];
  const choices = v.choices || v.actions;
  if (Array.isArray(choices) && choices.length) state['选项'] = choices;
  if (v.completed) state['结局'] = '本关已完结';
  const { view } = normalizeState(state);
  const userHash = await sha(ownerOf(userId, meta));
  const saveId = String(v.saveId || v.id || cleanId(args.game_id) || state['标题']);
  const gameKey = String(v.gameKey || v.gameType || '');
  return renderPipeline({
    view, themeText: args.theme || state['标题'], fieldsDecl: null, newGame: false, cardRequest: args.card || (state['选项'] ? undefined : '状态'),
    store, key: 'b-game-ui/v2/' + userHash + '/hub-' + (await sha(saveId)) + '.json',
    fixedChapter: args.theme ? null : engineSkin(engineSkins, gameKey), skinRequest: args.skin
  });
}

// 嵌入卡片的开源字体（OFL-1.1，授权文件见 fonts/）。只含拉丁字符，中文回落到系统字体。
// GPixel = Press Start 2P（皮肤 E 像素）；GTerm = VT323（数码读数）；GNeon = Orbitron 700（皮肤 D 霓虹标题）。
const FONT_CSS = "@font-face{font-family:GPixel;font-weight:400;font-display:block;src:url(data:font/woff2;base64,d09GMgABAAAAADDgABAAAAAAo5QAADB/AAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGhYcgzwGYACEbAiBYgmaFhEICoKJUIHrZAuDRAABNgIkA4Z0BCAFhEoHhF4MgTEbyJFVB2LEHeDgkiZSjEQIGweAQH3FQFVvB3IcbeUK+A9wihJYG6OnUAshhGYwU8sJisSmGdGEOziHGsMYsqVz0we/TuoFtPqyNKPSs/LvM7A+RxU8I/hz29u6bf1GpfgMuypbQre8/NnueIYU2tGu8t/PwLaRP8nJC8/De9afm7QdQBnYK2GwylrveWn/ASjxj7d7G/DGv8iSwOPpzHIv//91ZvdJXyacUYBky5JBMrHs/PG3HQAyBmEBQ9xUe3rPQp9yi3a7av1PW0owvQNqnua7upM2RBvSkRGkoGRzFcCizKirnjbA5n/TqkoSmFHg2/2YkDYfj+6lQ6YnR/z/X6Pd9/58sTHZv5Y2LxYaPojNOQzifyuRUIiNVPGQKIWMnc2HqKbl9OQNku7+HRIDKi7EDAAwpLbQVvnRG1Km9RPNmZBlUBu6DF1G4sxB6CTBVaJOVAlANO6XalL/2qGBBkDOyK6z0dkk1dSsziok10KhipXPIfpR8AnCaTaJJa369XQGzB8w8v9nqlVaVQAIUOPINS6yfEvt7vkgkT1nMv9yE10G/l9dxa5CN8SGEwCBOgKiHCjKYKQ11OqhuhtUE9I80j+uc1jjOLrzkZYacbzRGWczb7K7LJrJzqXJJUlyOsb0DbRPSUh27Zdfhec7NNGQVhEQW0REQc2k9n+ytWtu+C8tYPf5ySPPistc5oIc2a14jGl1uk42W8spJBZUUMrQFJIvt0cAW75+9YSbKKioCGCtjqUoJXedJiTtjhX9sMcTKb72GtYwmzGgYMQSKxC4zzZggQHKPx2omLBeq+8AGlDt/3KDr0Kt73T37N6Rkmb/zn3IQ6eFxNSY8rMJJt6zkUFqyWGPARAsEfxRcMWaYKANhbnECQTeUkGjNeFafxmRob3p4Qq2mBgxMrH9cAqNSbRBdiKGgruqB5uFymLGoWCPiZmgnkHrMYpfM5qxmGYqhLCmAlIap10RDRoRR2OoeeNKBAH8tlDCVFOBUTszU0NT4Sa38ifSmEF9KrMxgjJVaQFq063STlKOIl5WvrIFN1j8NCrFYQga6lMA9alUFRYBKK/bBFoN/TpXVEQbFP7qptAw4ArYiZdpJLMkpnHbr5xU7ir3VdFcNW/NXwsqszo1rPWBp54T+AYNsxm4t9dIkGVxstGborlonprvrtqtYv4E1He8ew/Gb9/fbr+Nvw2/bsLjefIXZeDjAY8rH9d4bP9o06OMP/1bjQCQAOq4DjKbr5xMJoHk/21A5R8W8B97OM15FrKSVczmIH+xlv9ZzJ8s4hhHOMo8zmHAFjsOOOGOB5544U8AGkGChYoVL0GiJMkyZMqSLddy5rCCGyzhAXnKlKuptgYaaqSxllppra12Ouihl9766Ke/CpWqVBtmKddYxgl28i+72Mdu9nOdi9znErr1nGQdl3nIVY4zlWnc4RQXmMtdpjDSBmYyg1nMxxIjJqxZYMUGe9xwxgVX/PDGB18cCREpTLhoEQ4RJV2KVGlyxOmrSL4CJQoVK1VDfXXUVU8LTTXTXC3tddFRJ910dpiuBhtgoEGG6GmoGN2tYTVb2MpmKv8xvvNdGWg+Oj3V2van6O01OtSnvxn9EQzkSUujRPiFUf4xXcEGccb3ArD0C6ETS3SdeuJZU6tMiMfIZzwlI/32wIP5geyrhCYuEEK6DQgiOkuyqcVjS8nGIfjtOJn5pMkM+0TvoEfXyGvKRth86rVo9fE8eHz93M+DUlhrqhUCCtdEOmQmWWDax0qqxEG+nYJj5I/THvHZ0VAai/IBrEEavwMmIQS1IisEIY77oxAsZRs9kBnpEFTEuqeiO7p0pxI6kCaWzBYtGodFmTkUgDyjkAC1n2zSJijn9NDPjEDW8oqsUho3yMwNH9fV9GTwEnQA+ZYnWWqKFo50OV+x6RbtBpLBiGvUnR67gNBdojQ7Js1JEyo5S7eNMZ/uFwe/GGajI3uFx0BysRvfncdu3H6InmtpGxCvaZOMT1qZLLGvR2ZE9LKecGg2DztMe5KaWnFj3Y6yIak71OX4xYwxNU0RmJAATOyRNn6fPPJa6Tq0tGXQLpI04sL9xSxDNmmCSkAsihnpHNddYBCkJ2mw1TJsg5G5eSv8YphnPc2/WkTkyWhokMjVIvbSti9s0Q1zXweW+ufRqHFowy9tfY+pRIvFh8fsgrDY2SQcFqTpgGHLdc+gZLgSeKDBzUiqDsrGui+zuI8sV/NHbfhyTst3AWUUG5FGJBanBgbEgME4YvosWZiFvN8CxPUuSRD9hoh+fwfE7aFNSKNtz7Du0KNfd/TpZBOHSJr+E40SQhi4PCkxl8UPlkrulmt2QdyyXLcL0URlEtnCZLKVMbKNKWQ7c5EdzE12Mg/ZxbzjWSPm35SuydK2F1SkKxslXaO5Tkk1/mhHK2nGH/+g3m0PrYKWnnQP3U01oEmCSSTJZKIzRlJMIQZzEZO5SZp5SIZ5G7ZBvV5J/vTI6AQd6YNLqLQFle2yb1UwzLeZb9FrigYYBFuzLum2BMbwjEoZgZSsr2uTuiq2ikLrI385TFSXDRSuW6NicAO3XfUvQ6PBaiRrFAHt9wn1bwDA8IHcLpXh9Ul+v9QMagxGvp8Q/JfIsm6qybFs9JkgiYNvb900RYJqoKIKoW+Powv54z4RxxP8vgqw6dd7bRrDtL6Ws2wZQl1F4hgzrtj96vSK9lEuCFDn1ugu2nlUMveRGcBRASfe4z75hv8qaaOa+ksyR7dfcB616RHIOtcVSj+SiX2polfj58dVJBEPhbJIhzzSHUuqqOjRfHkfVRKAzJR+uq10ekSfknFHZctGJBnxnaPsgMX45IqRqEivkJmaaWM0KSNyn9mm8nCw7JjDhllQTLJf6tZIspujh220H2FwsKLrsOCkLEPfHU77CrVotZIa14HKUoy5DHXOwinPFzFwfVsWU+Libu8OVhCFilcB36mLZd7fN+IHY6blPUeEX1cng0cdqlIYXrNcO+/9ppvq+KW5jNCcn/aGYas98KkDw3Y7ayu42Qpzq89pZKJiYZKIHFQXpaZYyem6r8bu3JZ+ytAUDzOWNYX6/Z9i4L6gDfiqj6/ltko4SkEHrGQ0jlbbHPZYTa8FLamlkZw83ZdZ3+hegz09GrdTtdae7D96wBRQd2xVLxMHDZt3cmgrqCNBhX7Wk8G8w2Ytj/FQ77QjpgGGRI8yIse2EehxRuTEIDCiJxmRU9sI9DSj08+YrwA2QM/GiJy7iUDPx4hceBFA9GKMyKWbCPRyjNQV1VSwqxCRa9sIdMKITAeBMZ0xIvNtBLpgpJf46IBdx5jcuIlAb8ZI3yJA6O0YkTs3EejdGJ28Z6CzkPo+OMZ+jT+ge9XD2ceI8slHBrGSxwmKPUkQeVpCVzp9Fu/S7+Jd/T3BG/3BupEfE0R+ShD5uQTnRn+JO/TXuEN/izv0d4uQ5wkiLxJEXpbQI/RVvEdfx3v0TbxH31qEvEsQeZ+gcz7YX71MurRu4dr0LFdyav3zefxzbosIYjbjAMATADkK8hOcKuDyHTABEahzYJ5TVPg/YDlGUaFMc0K05lhDImGLnquSqEpuky1LuBs5s6oyagy8jIokJoIKKAV6f/Vx5bQfe3fRrnUDxx0EIHWXvJJGpqCaUGEqs0F0cGip9cQdvWKqA9RdCYSGa0iDqM+jNth2sGl40HhKpvI9s3rvafbkL8thm2nbycxCzh/cMTk9/+h7m6ZZO/8YEcQQqGfavcz2/unjYAf9k8G2syiLyw8e/DczsH0w2geCGALknv0gA6tKGaDYr+vw7Whp7p7nA2Rj/kD/kKPfMyxsyI2W3pnbYNOTFFDfDjaU8O1NB/LvPW0a8smTbT9NNk19P6U0eKV/MNXTmBOHROTsiYUgM/Swe4tMZJK/ykyWG6amfU9SAGgRIQhFTv734EnGonHkJHm7fhh66xHBAqCC6j3rTZ094JL4cP5kCRECFkyGn+F50/rnZYmCS9DZBYOFQJgzoUWnw1cnjiVvuAZrDNqZqii2Oi5DOQtyTV8G/UgW8BKWvqoqJn38jsH5ibcGqzFlOJ4TPSeu4HwmjXWDDU58OyQdWuOmtZzueF6kSTUPIFGjoIzocsCxwn2gzmucT71M85uG+BVw3AyEuppHVtJqT/yvwbfJDiMKiQbDZw/B8rar2G4lybDuddDA0U7OtwrnO6EmIhrWGlK7+3CWcBNSGr0rayU6NxgxRIXsehw3KNUzIC2DTBIRFrq1QRS9lhGrEToT1YU5VAsLa6/FQuftxLwJK0o/1wVYgAvQovEdaRtE6IvoBOQwOrUkMkDGNEveQVThTJG0s81xU5GgvxQjCSY8pfwGtuj7B5yV5cA5Vz0mxBDmoM3si79gKmXaZwZ6CaTaOlITCgLcyvvoAMNUTqgTfHBKptQrYG6219OCQ9YY2Np9xm/g5FwUS2hWIVI80s4CA9rRNjvEwt5L53pggCd6GRfnrAQ9TcfEDl8Lj+06arGFErZhPWTYvyqhr47FbRIOxt06JEY0RG1hUWWumhX77cEFDUIrG0ru4JnCtcFiTrr2vsDFHcvWPrBPiJKEhqcdCFDFvaMNi6ayUWXAo78nRsulVANJDyfEJIGullDYOjPG3ijsqI5o/rCc4vmC1zWL0b+HHOfmT1r6Vr8zj6oWp9znvqFoBkO0mFyDIemR3AJUwbfgzVmY9JKCZwm1NrLLsADjoFPmJZWoCEHibb8iTkZz4yWDd6bCG8DAM6it/GTVCdoFoAoWaEcsS4GcNMCuWdaeC9HObBLDKupuwiaRnudkM+p1/KhVB6lG1YLzNTehfohjZsC1Pko52yZqf6aHeRNw8S4KSbLGBbeclZhQxFyLSLpCARYExZ25lDU63AFjmn/KWopYMsnTwBy4A/PKlZi7w0owxNjSNslLrb1GWOv2sy1KrsnUHhWvDC9RUO1KRZjIKcd4ZHdvZEh8ZYn4AmGsMpBKEosBsXayurhaTLpSWEYjzYUiFvJhuMqO57EAb6zpqPMm0oZzLeEIqBsGZrW/8ECLTvtAVocDiVgi0z5a8hIsiC+DzmlzKgQkOIQSvMbcdfzGuEd3z3FF5T38ahGAAvM1s/w/Lx9jo6i1TiyK7MPw0sICwKiosWGGa3bnoMjIWnmGQ13O4TZ1ysDyuRQb4ZKBIwLdT1q7d9rBT/Ya7IUZaZsKVVHvIKoVOk6ouT0IodQV1bpiZ4kzHJpWrOjBLdgit3eI0zlE7rB8+ESxyxxTvoycsym4Bbd1357UpCSVSVW5y198yhad+/rFH2NWYPwNGFba7eDVYZ2Be7MyRu0F3FN+S9fQsnOpLPbEbIxv2VciCR7g0g8QDofzSlw9cfTorAuf9cmyHguuA6sKPQYtiaTllpOtAgCXkuQ18ECXzTBwm+hCL4wYDO0XTCct22/k4BXb8EDHHX5aHuOBhzx4H8wCjeatJvICA8oufImp5Qv7nmDgC7Mg87GV+XSA8DeaFv8A5+3A7oJaBgYKxA5Af7yVb2htSItS8biWZE9sxch9mK8yaiF07+IW5bsMjN5T3dgJlwjCjXCIeuudNtQ6aefQFXjkuBgIEsKa2wLH12RdnWspBrgL6DrypG/VoS3ATlca8CwkT/FYQ6/9RYUQ023PefxUnS2uwfXlHwKiFRL+tMsm+jcacqTxmuf8DnPOb/ZFnQYS5wNtcIpTWATNT7ay4fLk1Gsfa2f8+gWcdBGlle5AEhRIbkojSZCkSRAgkuRDs66QHB369a8M4UOC8gn264/6kuh4mF83ulYokuJ8jsQc4JW/bDX478uuw8a+Z1oBNeSH+nCSkoiIKLweD45LzfxpgKZRUt1LcbeIr7C0FKLteodgB486NNDJgtI5PcVTpsq3qyaBlhD79vf5uqtYzF7wEFV/LgKN2eyCgwqtH+QLlkJTMmVcZZ/RYVASesV6RO9dUNlloFfOeXQZSlZK55S595WYfXrYBVgyeSSIWgnxjPdYBEDUl51FUCa27BKkOaEtg5lRBzMTyDuCmetRxtTOWTlup8PInC6Ngp6QIs9EUyNXjidK0aZbXkd/RBS15E70ae6S1s4mmN51jqGUC40U/NmJPGC6uTjEcA+SMbD/YRkpSp01MteqZ/WAYYMhco62LJyqDuDRflmsIgLtjmxXT+REi03WOSkFhdeAs5YtkHR9GQuOFylgKPHiwedqrtBNThiAFwVl264Yq6Hrg24EKpfbw4bZymSDYjqx3/S1ECQWhhwMXUs4yROlWJZ3kRym8LYtbc1TmWDjHI9mea/twl5tajYX7kUCthBXfEEqkQfFfNdARKqGi34IkMcbFvvBcPo4C2MahUR97HIrglhybIR53j6mXLIG4xIkss+uL0m0X0v+K9/pWjUA5l6kVVa9lCqRR+21Plkg9QfBQufoz6kB4vB1V8rWiZdjMfbIx7zC+QrZs29CfBKgwr0qCkF2+DHCiqEm8jWjsQ4h4sWLiO8t35o3euNDw8mHzGMWGIHcEpn91/UY2z/HjKumpkOUF6cJCF4p6jDuwhWV2r9lIU2KQ1Fyh6+S8Ib40IBwPTdnVua/px3EAYbGJp9d+M7Eq1sb+1slyOh+JjGHcC8ug8mJjz1SEwS6ptww60SVZpTVFA5hMRO6slqxxiti96pwPykeEAHNma2/A5XNEEtiv63Em99ZPKYQ0pyjC/hJ9soROx3GA4pgc9kAIFycCtIIenoNGzXasryp8NSNfWltUrzuLnv+yZAzms/HZshG701+gfOF6I9FO+xuphQXrZ5vBOISuBFe0YOgUT5sUTvjInolf0uyobCfZfXWqndEjTyouQYuO8E1aSufPGyqjN+VZZBByeB5nu58UDmHyiURAXSuraNs2OdyDgjEczOS0tpJFoU6KgQbvnKSF40xXVgPTuq+eF+uKUmbuf5st4jxfAgjFyawnrSOkZPQQncfCZHzrJYtwCsfiUhrf6bSDioX2pSt/pF1itrnnqFo1FQhEu4Hll4vrr1uRfEqiPY9J/lWBJepKi5DLEODCGuER5j89YR1EEfbHB14u8euFJfOurqrdO/vPwlDM0OFPLzVOuY1KHwxprHv7RGlGRydVB6e6mm5F01IIFAoocqNfuVaf0GEUG1PgJUg+/qsAZ+zF5jVO4a93qB6KZmT1zS2/f2qE1yZuiL8/t/J27Wxw0qXEvEdQezDlfLV/gWPKWAiK6NPfOVOoiGS8y4YoXKFhJDamzE6O6wbYOPIjf76W2joB+/+EUDX7+hjc5dno1rYwV31mqH30N+qj67yHDeAurLnueH88Hxu2XFbN2JmJDHBrcCjRkjaZvia3EFn+CD48twoHEhCSluPyvtR1+qI9HYfgN5mzAXvaO/QZN8NwMI9u9NlFS1/XLQ2RpR8S3H2eGcZz7KH7c1poisHtG6W/Js7Jgt3jIPPopYY43gzQVOLtflCHF268BiXfyBaC96n6xit1//5pLUoVmSve/Njrk1XgOwqHKRwkNRuPkdHnAmqYWN2BmEqpLXCW0CAyNRopRi9AIoZlXRuCRZHv+plLnmLLpGZeKUzwUWXMcj0Uxov6vqwkVsiMqpkqfTIMT50quW1XANteM1Z5ZCT9U1u8TnFPtjSzyMebCycKODBaPQ3wZX/1JkWuo8Kh9l4/9pJMAx5E8l9HFpdyYadxhB1BvTXDqemXjOZvPT6anlzfo6aPisrzTgXjexDR4EkR5SL8SyLbo9z8cr/pjGCxqmxNECE65/nTuMF1X2l4SpIhJUrknN533dEqCW+83vDIW6JKvi0E1g1scyl8GfCnhf6yksy+/DbdlPPhKga+dZygmKEx1V2G8ElX+KdHD0h26sddscLQjRFNL4eHXzci3tY/JJr7Vn5B/bbHeVRVLbxUKbGWTZ3+QvRwQ1zz/vwg3vP3h/aXr32DaR1J842ayq+Hluoy1pZbZcUvXaTW2Kh+YRxz1Fjl3d98IiR09X0v5/28xui+H9UvpLid83/jr/H/39nS0qQv1uH/s9/Pj+LMhQFdAwKonxoJMtpmMEb5Zc1AVzXWWx2kU+6y9GhoDL/YFgVbjC9n1sF/yDBFFas55taL5935hE7ndSbpUOjp9yHC8KrYEBAKejGNq351nC/rtfFZrwzmC/8pLtHpuc9tQnT+7nb9V9MqOqzdph39Ky78+lcvrz7XTMM6LSCjhsrTituCpKIm/BwIsoSw9F14/qyep3aZrfrWgHKHltcysU+6R6R+5idaJ1w4X4myffJQ+vBS/EM61X2viC9n0lbutpxoevSP2xEaTFudhIibO8AL6tzSZtMZ1yk2nG9l86hxfqEtdIbYJe/cCG3KjCenzNfiP+l8iHU1ZNBIOf78tj98MJBrn6wq1uyP8uE8IHkFgO3ZuvdfEje3buToaWDjgSv1MFx2Eb2lltXlY3JeJFIzdi8APgeGex+0RyNZHq9UJ8A5a0COK7DPcSirXysYy9TO+n0oqvox/PkjG7jdM8fINzRGKTk28Qd/y431tU2Ydf1MVkEuwRwwZPufQQ/FqbrDc7fz8zPL+DHFGeXP/vyswZ9eSc84j75+ONvQyrosCD1g8NCbZjIKfJgIpGUSmuLZLbq0mgI1Qmrxw0kq4nqz2Lab5gPAU7EQ6JIKoNBs+hQjs1CaelsW0c6FiEC1UBFfX7stXz6J340I5kSSxqD0ghRQEqohRzUSnJ9yBl9D9H7JT4QfI7ZbzvS9RHyxf3izoTWMTISlFRSuqoX8qz+DlrQfy6FVWVOXeeLAiLnqff5tXnux/E17kIVP46GJi75UKLJD0AT6TDKSIgxRvZO2u5Du6gWgTplntATcZ2AExM8orxjwzmmaI37GpZyOSbUCUaYJZJIKq4667kwZuM4TPoeQmzUgFRdQif02Eqa0NjPnTJPQcaQrltzm0KUZYCGPe1qW+Ea2cekDy9puOcNDWqiJu9LUfatD64Kk87eRZlwqNsbZJ+QTpAJvuBeNWOypipHf8WVSHhOzo5WbN0ZuJ0sewCtoqu1e1MJE0KvPvcotYPDQicZ0wH0Ehs3Ru9Bvs8GKNkvWWYx6QJ2N5KV2amNFogHsDnIuNC2DDc55IyM6qUQjRcVlFoqn1TD+1LY0jWLkP0wUSgUEgHBMmHy5D461z1ArRf/pJsTqkviCT0lxwScMmmTmIVKrW0qfKqutASLXISIb8hNGSJ7MtRiKPEe4yU3LyxAa0ZEdzAt3KNtupvKLMfQvACAmrC7XJ/46nSNj1yFJ8DCWSwQV1a77BfTfQEMm2m2Hhbzg8MnXcJuRkditpUFAHorAKyMVSirH3c/t12tqVPuE6O3QI9XOIm3gl6oj0WdSauyuBvPpGbUwifzXd9Bg2aPe2kTUNa+W3wJTUVP+DsuvLldRnowyAGD7dfylGPFRkF1PDLXBnHlLlQCqaSSvSHz69UOKFNySqODt5Tn+/CAAgViRgfIQlmLUJs1Ivd+esCQYBkOeOoOEIZYvqbOsV2vJhFXq7y6e5E4nyzs9nXT4uyO+zmo0JtKSIQ5rEW4X6bSV00zmyyVikJK9LgzU+JqbFrOmJG2irALK9a7CFMAtXsETxOg3OZqLmgsvEMJfWxeOE8FSoQgHLhYAy2Sc53F5oDvAcMczjH9m/LTgWXSMB3L2tqtWbXab0bZcSPRcKs3u5oXpzpqu1pkhoW+2mzVB0dRtDCMGmDLXVyxV+rR+kiCWlgHT9w6SrF8LIE74vuU+Qfwyeei+NmnY2pyS/L046knOLnzUaFC6IQxSUm2jF/T8G2gJe/n6LGHibi4J92N5r1L7BNQJojju8YjCuVgf4YcGHCp8aCr4+J2YfETFFZVxeJnNiwgalLIZKL7AlguzDTN/4Z4C3AmHxJqSQe6Dbng7osfMguBAmMlq/LxlNYrsVTYzEHOvO3NMuuU8Rvw9KkofvI8NYfR0TGn+5m/+thMYgqeME8qh1RPH8NjpTngUiy0dlQ6vgc6FjSnT6bhkiashd5gfD+3rMP1OMNaIF9c66xWy28aw1p8QiakhgyLUN9AI7CI4qJEs7XavvlDB3cryZpiAoMMOrxs5Zm4TI0fK1MuvieHgV143KrK3T2t8kwrB5RawIWqwhM/IKAZi0NGw4NS9jS40kRcdfO2Ng4baM9tncmKLr74wqs4DzRwxc5e+aPfR4PEWfq3u7GMKtURtdbKs6D9GHJeyMB0FDQIVTEqzLLFEj4SVjf8qa1aH40RJoS3NFFttEZOAmdBOU5bNh5Ofi43PgQBgaLHOuU84WNA6+LeNFZKq5Ko61ax/w5fWZaRfvsJ0PfYm0UQUDQSahinCT1caZmAwb00zNtQ5TU0RRAnHNkipQnlyrhv1YHVid9+RAKf8PH7GRHIOVos8/52gUVSO0R+pyKQKwT5UCe2uUK6Wrs3YWkCTGuxc2BQLpi22fn5PiRVNB1KWJwnNAvnG5ok0w0UoXKDlAgcXFWjwAEWWpQclzlCdXUy4aMoiAnhefLMDYSw2ImayMRZ51AfZ+KhlsqR2hIQhZ0Mh7uk/1qLSJbCJgJVrQ4OabpqazJFNBEt0x3joe6G43BRaEEk33MVyXfSRw2SJxfFF/D6UnS+xtASDp/V4owxHTApyA+brJr3IDlfTHuR1McktExIp4FtggADw5af1MLw5CVNJJqlNgS0mo5tXZWaNk9pVduCK1J4fo/yYw5hJ0/Oxuzt+SYrLPQNZp2YeCCpEnBr4MEAK/WMQWBN1/5IzUmZB7LEFtaLu2lfEOZPOppVbTctiPW+mU7oHMnxdjdFQTPv0RkLssZWungLw1UKnnITmD6XukcUgx5SU7m8SA9mBF5IhqBClZXD1mxHgxsl4vQOpQ54A0GUy8OtKJROa3e+Hn6YNgPkrcBFwvfbq6vH7TZQlQg2dLwSwkqbwijZgBKLhUgkt3VxBX+Fh+k+HaO8WtRNawR4ZuR3cfqPMEx33H1jt1VYuE0PikV0eb8OFiasgqGHcgNeLIV99sV369uN3q8zr5V2QBdydmCG2xwe0ztnd1t1FBSu7wetLnbuLpyoM2WfaP/tbLA1fl+TE0ySyejbVsX5xzEYT3dHXcwukfDq/anxUwmOElwmFhJqes9os+IML7u4m0S+rTzsceYVC1lrfrf0uxc5LJQEuX4MRomt6NZh6y42WWEh2Z1dKrMjeU/wCldWZkskh1xLyijN/1jifQeEVMWc+A07gMXUZSUQuT14LfKcT1ajzWlXJFtAtr8Two2TEgciYzzskL+oKOMSXYfJSiQVJraPSDUoer2QtwZGUjQJrmpOozW+4E+VzrlSwVH2ONJKM8wcSe2PMBrV2KYQcW9qmcd2YP2bj9xKVoSWRjVvg7dFsew5H1hrDGhxpIJ6tWPnz0ue84HW5Xmf+XyWxQTs6atYB68OJrUnllE8HUAkikFRnEsIQnCitYJrgcWaRzlE6mw0oVeRyoTQ2Fjyxp6/RJq/h17zjWOrYTy2cBOIHr1VCqw0MxmRMSRXIAYhDhHxlQuC5SVSaFDLzlXA5srWeRkygI6JmTeF+5PTIxlQgO4cx2JBnNrOa2KWTBDiuZwlQPu/n9c/nAf/bTQVRfbDqEjlMDvVEqtd1Hl3PB6opLtNoU4eE3pSCyaATXvKlwfg4Vks/fQY3P3vafmzMceAoqCxUge8APpGQIiUtpAB3th1T16/SwpJLAPldDO021c47xspyJgIGJBfQhdfLENADCq4anHU6N6FjWW15nrkOByMLEvDEuSJNi5keB7b5ClBrAdvPP1JTuyDK5Aqhk2/aWZ6QxdizayeMH3E0g26h1jDR2S1KeXboq7pNYwbsSCF334alHU3HG6nv9LsWtZ3ozklpbsq3fGEiMpeAtXax16az2uT9yI2pMmvX7vo4Z9CBgv39rp31+O8WZxR5PExwlQQdZ1WEuA8nR12zu2+jZfkTtpE4meYmOsPH9iJFtgSOg143E0/NKHZfwQXdJiDklJeWUnhnKK9zUeJvAYcs4eDoHcy4Ro+n6XOsVCYSq7TNUkRJhr6I/PzGhbZdiWNwA88qAvZC+q2qfXVcxsvOtybxL14fdjjOb/tv19INwDQRw40+KdFuPUdfP/6HyCEG3SeJBGpOUW7CFzMlvQ2XEoWkw2d68dyXxD1kpdKWNf7Biw4O6tPFLF/yEyW7DfKtIu//ps+9UfK41y70YrpBthfP7lPI1rUwZyM+yu6e3e/xtNQoPpXL+FWWw5C9CNPsIqQgBpRv6wU3KSmO5+vQcciFaj0hjom4LSR7cFJpWQFg0Q0BcapoGkVtieQPL7JxEETVKZ6g9TWcLjYN/BmSCicyqCo4PrO1Tfl/hBGN2Xa47tL9wGSva1oE3CoIU0W78HfXddIlsrRUUhVed+UBFtPnKc/7FZlnAqkstY2ofN2/viKIMzoYAiSGBVLBDe8G2Wq0Rpyh/RXpYY9CbIJ6N75502w9rfYQBH8DWQCU6bYOJOHlSpbGyLt+7FTNWWbCFL7kKie6lA4jVQUsUpYIhsLwI1JZ63oBuGTDUWO6+kFFRaFYlmwxQQZ9MFkb6INV5sy02kRWMgTPkKmfIPwSjNz8boBFmre1pcRzALrt65avNa03n1Hj/Fr54niM7rwDDpQ408IN1iovGGCPXgUFE7qw6r9WCiYD+VQ6bFTnhA+5dM15A6q0rrBflO/PvErGqqc5UGJlI/P5HBpDWq625vpJsH7T4xBNub1D/6aAGGu1R/bnRnz71duEwLsJxruLK9TZsG2NErkkoZD7RZQn5AdpWRWHqJ2pDqIo58LmS3M+2PYNH2Kz/SWixAoWBRZCR8c5Fl/hoK4VHqByiHDoabYVDF30qDtmzZP7twPQ799TOOpv9kqQz88mD2NAS6VinHWtnLZzMzM2x+Yj2a/bCCw/QrOplnQw8amCddb+O0f4ymnCU+o6Us0UqOt6vaeqp7KoSovuMU4bNj/TOPrD4lDvG8sgU5xIQ/3uNPye2+ur2QukhCkmDJMmmAVssN6MtGaXNsfiVhR6GPIg/QYu37Mk3QztUvXXvBqmmWD19K8/pFmae4z68Neq1UrDMPdhNBF4hj3uB6XJiELkY2wJQpM2QGvbMq/h22Ij11+cLg2e+5AAiwF58bDofZv14qF8dbkTjxc9I7z0HeJXRtfJEY5MnqXz5s9+76uQ8CXvC88TFCuu7rVQhWsfRNr0mEG3wGIsJ2MvDdB98FfMZFJWUZUAoLgqjDAHyR2viDfd1oRgje7fGMW9wtDuAHnZslNRhLRYvdky/rZ5WvdTsrQUsMlmffCh+k/HFb+LCoZJiGWiTitLq5piEzRdyplalnObNyFA1hQNPyj/Gn4MIJlzdcm4bEHUwtGHSfMIdFH1qslz4MFgJ1dlfEwPPHQHl4qIGqeChc5SluSRiVQ3ilL6eKMrCQwaUChl0J5AtgzbdElU8VHl4t7Gp482doPJ8k/GhLEVXhMdko1a2WfyxbO7dBYI7mBCMyFvM4Li4/jCcXUD1uWHgEsqXpSk/3X5VWSiAQ0yEBklw6rmZNcVPXUNL9AtEb41YqSqfv+CwS+mwpyplJnLBOcEu/w4aW9QFLRIIcFMiwXTUh+7QWlpDlG1RCc3yflAnsJ/rXAej6XUXRy7YNR+o5SZyTCl6JTPFQiUFnAKBXL7Wwf5OnL6JAkOi7DC8nz9K+ETfrrcCcLez4eFEKUo6BnclEfV3glKkxjEw+da9TfJkDMxkbUPSoNyTyhV1QwYXo/TYgeDyd56aPV5YkrbKwO8tUAldyYV+7kjozlkhgYChGxQuUKpNIwzhN6VCgmzO5Nl7LIg+1MRS7v1g4qufy2chyj2rXK7x02Di/ouyrnHEOWauFcCSoovyWgpgm74sflHTYOJd4PXG6VRZTAglFgDkChRXACyGuWnJa6oDHGS/5WI2L6NQkMknpP5QV151YbLFhz0CX0Ce9yj0BJIL9SjiJ2Z/Um/qK0pg1QXylItO83MIjH4b74yYyslFnyMCsPwsKAS1BpF3JDxIn0NT7RGRK5oYu3kJOSMsMJY2+O+7VLjfprC3t49SO5uK6ewz8I83uBL74Wi776Um8Z+FLqLvqwGb/qxlbKarnFLWfiKGwaKVWuUB8oLcq0me7e78OvFHr/68EnsTevAK8YE61krjZUUE6eB+i0eZ1e1oUIbxvmvGut6jjI3OQKgst9OdKnaCuOdIB001DHzBjtUMqO3relgrOX9N5pivxGWUrGb6hcZMG/S7afqtZHD7sT4r83vLfmY+e6TMPM5enM67L+Gh06pXxhs2v0TuEjna4KfKNrZ0ivyETh7PlwjyQ/IO9kGdXdTIM7mLb2Hqv9hOJfYUJtiOXXxKWvdhxXTtuPuWfTbbWR6i8+bCC4xLmKBm4jX8S80mihIACo9hOsu+YJvazUJsxeMHD4WJt6fuhFaPUQKGJlMESM6mgBXhOnXAAhR6PzQLBuWSf0liomdH6ziLc3At3qBbZvcOQueueNywPJjTTQdnWbGuBP1kcSy84M44EsZuwA9Fq/fFWrVKcK7doLdhox+P8QEuyCqwKHFRAmG+5wecXAEuBN9brhCtLb2q3BzZ+3fdWUCrEnPmOjL62viFfc0XoPgYMZD3R+vD+PY+iVH2flbY9VJEX+Q/ri8fFp38bT02V8VMYRAnA9OJ/pbhrv+Hn55E9/DdDfPzwAv9hIUEn6voovHjSvHhN6krtr8Z2ui3LOAWgzUabzIJKdW6QL4WDBK6wm225h0brcVYf2t/YdonATC7uFuj/wAtEN0Op5h0wQ5XiyTqWLySox+/ReXLa45eDI5TDJ4wO/3O3AjaCO98nWUm0lJwaqWu0JLjHx0XPQDdSOcmWHzL0ouvz88yeGqBSd8BCNW6w5AZwwHm8OnJY4DWenui51gBjg5ivWMFmVNIzUXHn7Adx9HxMWY+uMPuACur9PQoAQRkKejNPw7u5r5Wd1lOZFjB+v89M1JJ2XNO6/+HxPp4fzaYgQ2qCxTTnzp1Ps/OLhwZSLRz4lbWZdCJXxhAto3efl05Bc9I/OJT591d+ZP2Nr6/UlnWI9mXt6/jn3/uquf94sPZzTeBkZwP1I3dR3GR7zPG3wmObXPKf5/llYMrnb/+AgkiWWV9nMmq2cNIK4vDtwN/N/feRgvdST59fuxOnUNxV0ztK+nJwNi9JKupjSWm3Y28kpbaCEiZN79dQBUYzYfA131g/Bs0yc3FgONF/YJRqVL3CZ/XlCYGMB8kQWQxhzY/RrsUyAyMPMYhOzZQWH2GTzWDhhIzKnVCWgMKKyIV+GP6yHSkzEn90/paqkAvUvluSv1fr9tlHPs96N2W94kRhbDZekLx4LYOhoORBLL/JUhPeh5V9XUyk710b617RJSrVl/L87Je9Xkk49oRqZwykyqo8xpePU2ugJuVQS9oYgAATw6G9M8Vo455OlKv4B8D0cn6H08arn/rz5AQ3Y/hoNBioEwEClXQgRMSv2HyujMz5/67vUA1guvqrO8TzfdDTVhNX7P4OuMq5ffHPsrR75Xu+cNa6bvDt+76azJ2B6GLZL63wmSzDey9ZNGRqeJXcSGPJSXd8OHf+z1ELy+4C++I5Of6um0+lklwg8IYMtISxQKNDQNGC33UQQwJJuVMRgBe6KNTQk+PJ6SMGex0MqeZYOGYhRNWTEmzZDJiKk2PZ0DHqoEK8ZIEv86YN1NkhP3a7Ig3EG232eP/v9DdJdvPrK1NHAIF0NNlhjFToapEKSBmI10lV3lfq0NpvpapCsa/XXj0ayOAm1tiKqRVrLd6G1c/9Vk61YS42UysZiguHVtxbrb4ChZqh116Odf4ZKWaOJQbuGlsSZWvvrpavORblQZdQ9zAic5QidtdYuhiowzDi0q53BAFyrQqQYGtV6cnOD6MHGtKtyswuNshhUNOvpqC+2yw/KnaDzoIx5hx5Y+d3xBERBQSXEGU7RyQY628hsQoXpItwzInR1mrOcI1KUaDHOc4GLXCJWnPioBrO78YNf5grdXWMOm9hMslcfv3K9dBmuc4Mebn7Sy8wcL8hVoufHuti9uNnXYkp1bS33nBoGmO/3z0A11VJbHbeoUKVapbrqqR8DDTQ0RCNDDTfCMEvQbaGx1zTRVDNTaK6FkUYzhlEfCfPU2njJXto6zBEWsBAXXHH7EBn+ES//p4tRTGLBfj7yic/YyXeMSfjhwDoMLMOEE0GWYsSaP84UaaeDPAVssGUbW3EUS9awloMc4gTb2cFOdnFcrIznABZibQJ/iw32vGU3GoEC+IOOlostlmIXe4JZmcxEpjGV6YyjvacUxkEcxYkZPOQ2Myl2lwfo/Y8d3VleHjt8+Or92N3bO0w+u392+bK7Qyeuxq/d8rjrXR77+73h6eTVq1dudE6nLzN9/PbVpw+vp+EDiOZO/2+VzD36rxNpTqf5h/c5cj3wVdcZOvQL/570hejrBdJf6rD56wL34Pvd7XpuDDnouo9mns/0ZuzMOS/zNHyZM9eJifZEUt6bf/B/y/Poc/9zF8DgBQkX8K2G5OoyhiU1/P6EJ/9yXiULZp7yx/McxNbKfNt3tcPlET6aSZ4DU+WpHW4WyP2i/9+s2JdNyXPmV2UxgWEXAAA=) format('woff2');unicode-range:U+0000-00FF,U+2000-206F,U+2190-21FF,U+25A0-25FF}@font-face{font-family:GTerm;font-weight:400;font-display:block;src:url(data:font/woff2;base64,d09GMgABAAAAAEYQABEAAAABK5AAAEWsAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGlQbh0AchXIGYACFAAh6CZoWEQgKhI9gg8MpC4NYAAE2AiQDhxwEIAWDMAeFWAyBGFtcAlHBjr0E4g4oSA8j7mcjbLcjFBLUMyMD9WSvtpL9f0LSMYYb9gGovPKHDMEVkJARXspA5lSu3XPl1xG3HK2BjXBsidyficUR3s7JIhkS3kIh7T22sUbaOPQzxMUyzz6VVl75/wxdOUeyVgx0ON9UzsUaOsay5kti0SN+kGou2uIW2mU5dMkZ4A4rNeKE+tqvyno90DMLqIFAEh6RQhIGgCUKRQ5QbfgDQD3n9rf/9F5951Yl6QGQsZh+IL3/S/D9fr89F5fphESm/Q9NRKtKiCSX0MRSIpMp5Q2xqbmxhspf8k4VxsQuVmFzbpLRZ5b8aLLuJh5mmu7DVGFuGt4kn3unve2O5FZkjaxZW2t7e/sNKYUmhwKvNJr3+dHwI/xQ0jk8ePhv0/5i8oAkNBUq6pPUnVGxs/9iup7j9epfTnY8ERdZIgei/WwauDuIas7bhFWErjIgFHBKSMKYzjfYP39ogmq67P0noTfJeDCij0cjcV3j/6v77N0nycQfhj2A/gT2oAKoJAuMZc70O+UWzRYtnj7QP9r+94GiFEtzwkVsF7Evi2WfoJKg2WdFTVGnqyaL9xVm+fvdfXPMgmRyX7JNxSKt2tPpoSnpOvyqn1W95+7hHvBBykyp1NUEg9UDgPqTNaxh5Vi1beRymxY47S/h4caH48LzuZb+yexXh5jLgQSEboHQ6MqO79T6Tsxrt1hXG7PIF81abubl7p+0CIX8p1bjMRKrkws99FD+/15nbt97AiNwivCk4FSciqcyKXvwOK1tdlllDfc9/fd5XwW9LwnmA7IjYU5GcpVcATO/iCI8OUfTmdZEapnSENhxBPZUnEJI+jQmre1Kb4tNzixWnt3MLrPYebfPYr+N3zfLpH69N1sId5MQEsTyWrL/xopdvrWnJrlRAFd1tZRRdY9GM/fOkesmBNhsHLQwFl2qM3O7X+nRo1BqAW2Fwx7CWO/0k5ZKYULZPV+ZdLFjWKuZXTsryVcIRP5BCYsOcR66MLF0br/fL/MNuqfGJg/2TKlrcII4IqLikdQeHz/3/2OaD2M6MzrsuJnmnIA4kaGAH0fvGtP/Pkn2ZW6SXK8p6tOOCMgCS9Hr80JADQDZyCNaGGAYvFQz9J9XRTAUGWYEZqRRyBEPkUce4Z54invhNY6AtGDVWMfE3Bo2S9mLp9EjAITAEC55gEGTIzim7t1TZVY6YJXlae7OadNpkBIQDaRbMFJIhy5HNofmPpTmivb0Tj0aHgHK+mwMYhJ0PbL21/+Fl15554OPPvnsi68ksH92ViLpRKWgr3ZlgeUkI6UGCj2weBavvUdgJxDymuDuWOmEdcDSqh37JJPlGGEpPU7xxx21CBmKKa/Rf/ojDCZgN86RrrrQe7UF8GAKjhWLzAvPAXmV1NFLI/S4Uo99OUfd4mQoZtxzV38AC0nvqwldx9fFf0dF7TU7OmGOUllMMUoAAGf6EUSxwiO6+EJ0B7wVh04zE4wmAUX/sGrTn5Y8T2MqY7p2+ei6bPw2pqgKZAaqEqMX9ENpVwGblgCYIgLz79+7PlDAmw5f6dxlKpekUrtCnbo16DVUMxXizA1QEpoS7Kg9uaqA9r+euw/fHZfLF17vcFJu+3gpve3ZNVdd375SU9iZ3S6Th3I1oUP+Wc19Ru8co6LPnK10VIkeMzZHFekyZX1UgQ4TVkfltBmzPCKjxYjFtg7RZLhqYPe9yDNgt5g/dZaPT+ZfFuPFxOtXqKXekX08feLkwEnuu266LrvOuo4f8SAggou7mEt0kUtyabhUJwbp8Jy3+7Blf8nMEMrDmNCV+YSRilT22jq9b0zgLEahCvXmrT86R7aMM6EHq/ovstpwTKFhmDyE5GHn440xo4UIZuPWGI/RI5klaTMjbawrq8YYZxWkWJwtKSQBxpkWjpggvtEykEKaXIitfCbAQZuX5lbrp4BEuz3SG/BrP9wLGqU2q3cHYR6ZWYhzOocIdmjLAVMve9YMgX4DxMvYP3dS0SWdmwuchoomZppPc4rV8rsMOgWgI2sDlOGAAXtiMY6qhbRt4fvIBBZADj8RRvpfJ7WXD9qM3beHLtzFXMpVlmFXdU037ubdU/e674fAeFyM1f9Ba3mZv0irK9otC+MFzj9RdtSZxo+ZyjJg/jz6KFWAqCYqjfL+zw2+mb0PZh/C53vweUMdq0ulqbonNz56/5M1SeuK0OOxOmPfpkPuAP/XobPYSksdc8U1q2y2xRynLLTdMmsssNoF55y33FUCHbr0GTJjzoIlO/ZkDhw58+bLj78AgcKEixAp2kZzbXLfWp/ESJEqXaY8+QoUqlClWo1a9dp16tKtl6K/AQYaZKj17trgksOWOOKEo06654aPbhppp8t2uOWzOy6aZrp3HrpunvemGmWXWWaabQUNIokWFU3a9JgyYsyELSvWbBhw4s6FK09uzvAQKkiwEFF89EgQK06SeImSpcmVJVuOcsVKlMpQp1mDRq2anNWiH7U++hqswxBe2jzyyjZb7bPfXvuW5Vi2mal84zd1wfottVZNB0ES2eD/QB5S7Ncp1BP0Rpwm6clfihY8wbr/GJkdcPSaNypvvMA2/HNCj3JpC+c99A50xyYjAebQAFBmmwaGVuIFQqaP41H0OF1OsS6jR1h6/Sl68668fcLLN2W7fnUjqdfWr0kV+cphxZF6paY7MhIjFHqxkTYqN/mEvJa8E2Wx8N7IAi2+AHJKyQFPyaCX4zqlBgFNhbRhJRRfRpQGLA3O+wSyBgnz5rWqqghKwVqfI4enjz+cTZeIlRcWVcq/v6PXUXsfmV7F/NINr1O05JPQ9xG4axejbg76K2Dz4kjsJWSptt58E7QbBrjYgBJkqFWDDTWzl8/lXxkKacfRWTqt5wl7Tw5Gexg4DRe835FrHQafZ2DfcIPuIC1rWnZzrXwlac2fGygP0B5qR9itb1L9SfHPDbH3ByGnGAXQmusf/UHzMnpnPl3wwXYhKjcu+fxFvYYIIJMR8PG5zUNSQyKU8Ks4XN0QI9WS7thOf2Uoy27+Ty2zysdqdIns+hI8eRurrCbp1HNPbd/VdNf9Kj558xByPnbldTNUiofeFYunBHkg9tSaJFuogcDhdmDbhLBM1I7LRFooNyd1Hr/y9kU5+pwKcXNN040TAeeE0nxi00/Z9N60lajIJoDQ5YgYky+AHFsVHnkbiTVoiq8BT+EsKIP8V7q2jyach/Lxf9ap+MMPTqaGApXyiw0tVLygNmHUIQJ1iUQrRKFVYqE1YqN14qAN4saOYT4vipU9eRtNLficHGMbTk5UtMt+GlYVB2W/79Kb2CLHXcNbeBOXWPA2FryDBe9iwXtY8D4WfIAFH2LBR1gSPagbo6i/aSbN1NtS6/tRRS56YbrdAPSd/sqWDSHNnQcwbsO2rYbZK4VzPDjq18mxzXBVVdyaxiupdcGxV5xPJSbQTVtbpm9ORZc1GMBrdi4qSe2fRMDwXduuk9hq2TtkBnWaN7YduhN+FzXM0R7tGhblWsFp89Ptl6gctk+rNQPanRJFH5Wba53boLhwq+r2GsZFxNahC7ppDahNIiFpFS1z/bi8uC4DlbpSX6+gCas104rcAcoQHy8YJfVt/MEnB0r3g9OB1RQW0ZRDlV1kq82SU5SciyIvZOyaMQEzrwzBYZWo3CUdgjmzxd+kwSRkstmw7QyHM9iUEpxqVuyz5VKVBfTA61Y2oAwayOSMZg1wW2bLpIlGTUXg1ActOomoBO3WbR9XnOk4KnUmUCMMXOC8mLbE693t6fXYqjPvdvxhjFDdH7JslfPoys56znFMewdJaFgHLj6B55VU5Mu/bXuVvk1ewtR6sKnee8L40r1OUV1q6yAWF28aX73sa/dy11ova/QbfAvUXlvv26DxUp50oXUaS11uEyRbBg7d0akdlijx0bva1Cn0bxtMv4vqtCyUGsoRfJ+Yhyw4AMvTa3a27XxwLGzhk324d6T6og8691fldOHtpuFEq8V80G9N7ulI87h98CyZrUp5+PkIlVB8kPncfnzfWXYwv6g9NbWald3cS9MnGL8TzHTxFCORgmFjRIRoBoxJiBeCESZESGbAlHSZLvpdwACYCYRsDvSDujmMpLxCBZGKUrdExyGVqxEqGbAqoVYIRlkXoZEBm1KvZRMH1a4l6OTAblCvB1VgPxAGOXAYdBoV/SqRvdcbS5OPwcgmDHWnHV5jDLdnhwPUmDth4WC5kiiDXFkU1xbV20At47aRYedg7+CwkuiMR4vmyaJ5tmheGoCrg5uD+0pigA+L4dNi+LIYvhuAj4Ov8/Rr+uLG7CvVNp88O+t/EVXzr67Bf56GUBbkAfAPQL9AO2CgGQx1Ay0B1YJlE+z3hv9srJNJVarqN382XxnlqodvMqmlm+EtJmJz2FkKKFmFG8HNAFjouTVLCNlTBp1ZBlxhyXEJ3nKFQpbnt1SrQkTEHTK95NKB65rstHohCJKRDI8YzwVFo68hkggEdt7L4b632bcP9TaRUIfn97ZwlJVal3XdlKUMTax0+fD+qu5X4ffhqUfqhkY3aRmJ1HVJ1V1rs6fWxQd5gGbCpz9pT/aaTWlCs7cWlGK0y7kNrixiOkTF6tdFTSolKWCbVCpnpaRme84jTodo720PDQcXU9d5I/dZTWkRHeAOmX7Zd3IHd4L1cfqaBuMArSmP1/uhIibSqisVMehcrqjPdDFj2RIyWKWt3GFaEqKOJ5TX8l8iO30+Hw6pwjogd7so/LG7sD03StlDOTGcKBS024axs+3Bw5d6c38vCOWyoUEVNSR9iah+IFC0q5TLiXg8SCkLsf5pDk/ED8QOF0jWXNBVfLUTgLADbyRyJdwQFafA8VkE948zLcfzt3sb41XfK8AXLzzJhixbwmCqyPsYqNS8CoWzmrg9TBJl+l1KfJuwqVT3niIt7GJe0ORKPMe0k1r+sL64YAlbIaSEdf+zzbDDEtimj5AEXU4lPxHcbOxKOwlwqFERnayv1zFGp2BSQaRpOrFer7Dvt8hFno3ePV6IwoCtQ2tmZAsQtws781EKblMa9DyAXm9o7MXpZLEqBqTcDqyFBtCK9iWRsnCArl51Nh9Bq/ZqyoGw4pZTj2X7gpQHjExyDWqXyXEf6DIE3+kWNtl6NfPhtfS7Y6nglwJ97eCbr39uT1/Lpwyo6aSgGXo91Pw55c3gJXoS5qQRxXJGGK0lJptGrycs3ux8UJhf+BA17WaJSD0Gm3qF6HAbdSrBV23FHpvowLyz1pSAVpPYzw9tOf0Yu6p7umHz/Bo9FKfZf6LsEzGyBk9YemqqNP8ppW5Pp4twOiFEZA6BE4GebhZwWgjoSanuJI6g7EtWeOSI6wGu+2x0Car/Yi1FqG5dfzOCKJZdn0Iud0elRaYNpBsqx1+jlZYPncfw+IQszwUb/NntG2qr4yRaZH1EdcPq6MMH5fHmbuIpjUyletjJPD0EnkhMpjQhehFdau63ivADVBVyuizXpNqsK5Krs+ICM7gUULu0Ef3KdXmPvWXILUJ/KWEFjkFy9teiuMCsibicrITKOpfH5zEEha7ORHi/0g7zs/zzmCAcvhjS9EzsOn29NsCkDUUTceLDK5QSH1DfizAiNx1Ca1BHw7oHAMHq5x6xv8hoGTQocNYslRH2q7NxUOzTkHWFS+6uJuOUAvnZLzbROJfR1anZuWPMNTYXiePhrzr8cIgK1qGQaXfRmKAaO+hwtn3K4jKjwD3iyXoorHSU9mtToRAx5otXulUVTMFSivf2aDK9+riYRI+4xnHaP+MPDqJ8w9dr9QVJ2gYBlgaQXdKgqWkfWaKZNaZurk+YnWyzUMX1t+4I2f47LqKq7JhoNACacL/DqwQAQ6uhcljzy/iciKifdFNEbR1auLfBSLUsYe4Inda1evOk0Da67zpdCOwkeHXglXaabzzWP9Oit0sZQ8jFu3fOFU/6s8oWT9iS8/t8qhnt0icNx8JlqiA3bS2LrRx7fmb31U44lgWHEVOBPuKcA3fklXTRC9njsdJQrFXYWO9azPFjHHqs3DsAZLdzeg/PLo/52tyUZhWJweS1IeeDD4g5NmG2EjC7NZwOJ/t6zKQ17EZurEMjcyw4q0aiLAGTbjbjOr5eruhx4bK7dp70LK8SHbLwo4d183OoxhZIEGlozWNZiaOWw17QZdvsRoWAo6699jGku45dMrvtbwoOSckVKKo+sivUv5x+3f66IxTvRsmxlFA15obE55t9xmRK61CWN+032MPU0Zhg4KYHeOS5H5tUXQfi3D9CgCHPKnHImrOKYkbbXqeW6f6sS5xhO/cuy5XNvbzr9c7u/ZVivKJsVw2bCjeJm2aTJ4BPROZDn1sveR2FEVNegLwX+yVoCaT5z9H/fcak7qkufync+bRDy9av1B+K018WElbbRVV26qFEn1cPm7XqiF2UnOm+aUtcKa+42fuOmhS+gjCG9n3gnzbhnVZ1nrnUcJsXWFQh/E/o7PhJuQ/+CW1k7j+WZUj1ISu+YxV0dxus7GEHLC0Iohu2ew8pHPv48tZsO9dpVdz94N4HgefMIBw3r7V/NyKzIS14RMnS+SZ7mMaOoyCjc0mJcwg4GQtQVkuOTdobQCi52CNLyowp0HLhO9F0tXqBuF1qQ/325NK/0RFLlCHcOqTGGkC8m8fSBBU7S0tb1C2u0i7NUJd/E+6TEgA8yZnFT3ki92+I5tu6WZGGtsqcU7NcsDU0uIJFuJjJbltODgNzz0BPqyuAEfuzzOukVXHd4DShOzQzxmDrcij7o7ndUJmhfwDGzwQBGcI+73JpJqsqNTneB7uoM4lo20hD2Li2vHpGLYoeSCLFr+YSQ+xFnsO+u0hPMR9TKFdQR50pw6hhuZW/NmXf3sEjZaj6szeCd6rb3gVi711MJjSOMR9zNBIW2ncXatZGf9qG7Atft+NS5XrSyI4zQlGNwhgraWAQYyCtXGiSNRcAr4QIghshIwQhgoB5pejgmhIVMC7tVkfnBCUEAkHBA2I4oDbexy3eMNogert/FLIxr71X3ObGHyAX+rR+g4lhUApCaAm3iMecjL9yEYzS87Loiu9LcCqFd7gxcpIJ/hokS3euJN5PPo4VsjrkbS3S+9zuei6Piqez44uoCnlOOet5kjNunZELEdN5iGi92Xd0wEj7qeQgYjHiqahNQJS2IFWr7R5yDUCGot5RNeDDGtxqathwq8m8OH5ahRE9ZmiuqglEXebD1dNuiE+tHCmj8zBYy/no7es1cjEPrfixshtfUfo1taZWGITYXdhrXsi3JAh1CaZBaFG40ZhaXBO6wm8ccSuCsZSrhrCaIvUxtgVIFC4LqQX6R9s5QdA/hHFF65ho9Nir8PBqAh8OgRtk4s4msCPQAmKFgWej8c1gZMViOvtZOlgBSQP41Q8e1wl1PW6T5JpJTdylVMeNNMBQG4lFprO37roh7lBy9+W941YRAj2gaLWjC/ARaeUUcNngzqHL8FkmnYzYso27VbwNMS+2czcriXiyrbtdameUxqNQb2kdgPChd0zuF+BDCMrXW0Dla7XlZ4ucRZiFiVC+rtHGE0LLLehAepcYneG7a9y7pIzHo2GX92PtElvLBMQ2dLzg3oIut8Jh3WpkI7vnJ6JUzQY2b/+9ew3RHiOGLs7ofmpsocprPJqUN5cPlK+x+zAWFPj9ymXzsOhYqehz5QF+8i5sfx3fq0Sf3Qg30TClG6aXXbHu+bquKfDsM5soxXNKtK7OK1y8ho6oWFxvz5YGxHTLblAS4cxuUagbkBEQIWImGuIekAn5Fd0XSRvIECEmWE8I5mGqmssE8H7Uu+8lWfVrl0Y/9SAxpYAYV4V1yprklZEOIcosKl5jvfcRecm2QiFhjqyi+xGTJXFXp5JbPiRolvUDSGdtaih3ghEBrfgJifl8FQ6l6UfRmEmeGyWw06Fc21p9UvVhq8U+HMBL2uU7R2sHemmdMfQAw1/grYw0PZam/NIDIiMZlKRJb8tOCu2RkZxXH3uu4dOGUg2uE+e9kV/TuAkR9xUkqPjTx1osUQPAs+p+h1KtB+DnQneAr7pbNXIq4/IYqdHHumFWzV6f0BAPipyUqxrD0bjmDgGd/mjGNMO94ewlSBmXJsn8RYhh6Jrr0euJo/muhKyC1o6z7RCrRXkeFzexqrs4Dc2AJrr9YrSwPSUM5tZpYocBwrjPT3GSloead7wgA5nGoUJWsRMz8eBVcqMXd4ajxHUDJ1MHfBmUcRZ6x6H23VV71Zh5gADquQXse+PKrEl1RqXXTC6MdHdr01kId9TRZkVNX544My6yW4ykpXTEYbjzB2lqLp0xUWHJiPtAaRPyCgAsPkI1EBN2KU3q6IqthHJc1u/Czb4h5tQTemel02GaA8+qP6cbtk8caGf90d+qMmUhy9b+lqENm+GtPhfuGsuzceckZM8Ry42gnSqhEXHfIrpeKOK2ebRbo+rCu0FRbJMQKFhRykSARInLgIj98kZnoKzFXzXOBFhGPk11wO0QdaDfVnvrB7x1zKlBzgV3YSD50PY+GpzWQRZgsC3JKs/LoVyYVis6NZJBqKJKIcKUmu0nQWhJYhCw+KJAS9rM/RLYBefFPDzcGbks+cOHMY2dtQ9ZlqW5csdfvPDyHMkDSrabLVrR18q7Gh6ECBXsNpH+hlvgZCS59PYzzHBtjyHO84RbaLd30zGKWLhaze3oKhTuqe/e0ejLtZsjRoBRDAKIEPMDLsYIEIpEAFAT4nPWZJzUHuZR2a+IJB4KsQdiA219G+FBFszqzZb89UgScW8cvy1TyU8RwjH+5nx9k9NhUDnz1Oe8uzQjXh/YlLpnL4dh1F9VDMd4LtZ/kAS4W4uo84jkV1xIXiyv7kwCWGur88qzMOXVTNroy1WNRmfqO9xHMGqpjy2f9qddwtk3b463jHv5Q0cRBOgKS0KKhoEvN9vQifF5s6Au78eed/cKsYzTzQ/j90xbhYtjVuzO94SoWyqx4ryG4PGDoYdQMGwpMnMzkpqE0K5hOF1PXikYCsrZAUpyIyIqzdxknMdd7Tm8nYSiReyQ5mh5lgfmLpdN06ZqnwbMUgZYmqz7YLcWVnbOWLVxyiLhQmb0f4vr6oxCe7zfu8wraaNSX/elGXlGNhL+HikVKJyCnl6I/P2K3BM+srM1P0iujXDiLg7finhf2pP4c4v+RvwJMdLsHz1k5P2kp9caiFQDhI42Ow+GmsNi3Nj5zuiIK1T/rSg2WHVQeQnXBYQhWqowTIM4kYq4QMy0YWldvYM+MLQsbjN3DF0H9nOq94HqtOegiTShBuzOL5SyM8cmPEUeddc+NtaMpBBIkxbjRryexYEk3z8RocveAP02HJ2368XMFatYOsTVceDt2gED7aL8gsUeyY0+g6mT+31sjlOFqHIE0aqKittB0g3xX2HMDVs1/ljbjw9qaTIqYMFofnAKuQMRoSE7nb2Wdujsw5b0r1esEwbHGrSqrjrNT1q9gBUNPAFPC8EHQWWW/TMEA4fqHds+raN/HqKgs+Ee5wgazxhE4zZKxFDu8dzrdPBXuDt8lGdBpcosl/TAF7Wy64q+DbQKrbC8+oit/O5X29V/UPgPgu0HYRt/tm3l/LPbODy0vfjGZgoEsl8ZbROyt39CAKeBBEN4XWVZ2NshuTCZoCojW1DenuyYSj9JsTO80KblscYYEAnBo2iGfWWyMazVdlXbYPlGZFtGlG3eBbNp9rJr87Zz4Vrb9zFne21xRLYSBRa6QiQ/X8rf2GuvG6YHQYN8ygutcnJl3GMCIxIHLJ8eZ9hiiJWKWuHaEXhVNef8nljS2qjjytOsfLSGayHsa35TZto6sZazQXEIyB62tmyaJuIzr+g2Hiz32zS9klyXsAvWX8QY1P9/0mvTEaa2loNGeltXBvtiauPHybHPwye6aFBEiG63LpoYMeKuQUzszSrgPe1uVHNAdrgRy2zKIT4QfAht8FR674UkkZAiZgmxNea1DcFaKmztzw7xn/g/xy56fDMr69sqIgPfJc2ooQiaNesOFxDVrgHo8jOfDSuUpL5H9OM9FobYCJA2QCFiHUgDGUeUoaIc6B7FDF3kdQ/K1yuFsGJQlCNEj+3TK9gyGuz4Uo9h1foIljhuWd/6JUEgeC1WuhZpDDxDUxyX8S1vWjhFvZbIT9XRf0317/IsYQxrm8kRuJWh77WyMZ9PRpt1aWJt4JChO672hCChM7Jsf7iwblmCXmKI2UpT8m4Bfqc5QgtKSXslZlWnYK/SomKcVNybavFzzOQdWcYcUvfhK1/vt8/IFjVgzCvrv5WvM+Uk/z8yV8swgOgMwXlYgJP3WMTu/E82AXZlU5k6FTZ+yY3C3AUAHAiM6gBmkTXQe8gPEDqNjQedad7u5XU84vZ7BTLV9t8cIRuK9eUOEG3J/ceXvYRdf+Z1cjKywnUbInoN/yXNYjimKSY193bz60G5Nm7ItHfQCV5g0Rssv+9qJfiVvmnNiutD1WmMnezC2kjNcZTK+vnkM8PMXv4blrDfFS2KhvOgcCO+L4yEZHk5X7XebpUWcjcGyPvVrVSacQlk1nL9u+WnhFoYruifap3+ViY30tcd5DWH8WVuH+pU9l8dr5o3ORCFR8gD0MPw/kmo0bYEp2EWidatEO3q+Bl7EbPAzyax4wsig9rFLecfgbycI793Z1lmyROg99qU/UmlO+u+X2Rss7OCgerS+c9NChxGKCn9L6mVtMM2kPgg6vtzAHW22PaaAC7I/VnbgS6aNih+D/bqtDQaLxemRTAN78WlVipflcwnoYwtPyiCp1qQYf9kuQHkSACV8Cyms/pF4+flL5DuUpw3GLmGX3MtUa4jynW+39i5cSCK0XFBBRo/L3+Rm8qGP/PgWkmKAJkP5Y9zazEE61PxgN9vqBxmtuOnnCY/dzmP/pQ/QS852xzftLYQBEXnh7f7aFUQ79vimETpH2iVriXF9GdEv5fuzFKZIRt3bCgFtaUZTPBgeUzwakBxRaXpiOHkf4LMvazQxPV+i5GN5fFZebLj3Iw4wNI1bqxmA8Wh9mfPzX80Dlioiqf3XB6W8Td5SINymRvmmcfZ/2nzt4Bx6DGGj6tnSDYOF5vNyeYHZlBn3jOOcSZiZywpHYxDFXcyIE23kd6WuXBpsPV4E2Lo+OpwLptMRMI+r6oIfBMxHZDKvRcr6+8OG8UtuOzF+ZrheyKeKrVt/bq9TmLj5m3y7MnXbr5+DiGgdBBCG7RzTSmu1T3bNDrT2s4IpRyML8LudGZ7eRvpJWzjWDbOery5MdBvBDsPLl86d/bkiUMHd+7Y3FhZnp+r3V+k4aHbdbuZjKtBz5hxI6LyDI2fNN26fgudodqunI7ka8lO3Ag2sKIrMTuEmHgdz+OCVz+2hteHmnhCKfRN29v1KTQ8JvQEacMZDH1xQ4+INPcu/RyzB9y4UVj91uaiqO+3RN/aQEY7EsVL+EoFtIouOpKgTHrvKCWfyXlncD8YSDmrRPZ8u7pX9zwMlMykvR5FbirIECGJdMl8gnfrHHnMkZ5tdfsmlKUJ/ibiVeTnIHYkAUZCJ5AZuf2kfHG62xmznaEUPaO6F7e7EgHHY8vS6uJ8QkIRxqGym4rQ1eVqXAypMlvK3etKE2Jo6JTiZ9x3BtXi0OGmDwPvIPe4BaxzWvaaBnv59IgU5kuR1Xt+Re9tShy907CMxKUe8aNqTr8uYOxB45K9LJNbCr9QwFw6bBnGTkSNe+0MQDujaDLIWe7oKyPSPa/EzdMKhUDhCrdhDE3fHHXzHlvX8Pp6OewRdRiPKpt8q47rMVtQfkMJ6xHPjavLoZqLVyoBb+3FlUYaknUyqJnd4S4ToTpkAZ9dyKPaUDH6enuuRfCM5iG+gWrdy0+nd7azmUTc8dsWff5D9GhE1J/Q6aUdMN1LQZKlGvoS7DHSFWBHzJlgqaMqZ0SKR5Iyef9IQ/SF5uF42KyRvNhX9pC6wjne3wUrsvQjPor8NspbMDuqT2QTT8+NxXLpdYVLdDM2u726DYsewlfCV+ZNUWAvx6OhWUwkXizRsIfFav6JP30AnmSZwppflvLnkT4Ot6MMTasygx1DckvdFSLaY6G9rdGwnqEbwMySioRZtyoPtgQhPkzsn8AOLmdg+lwrzkbIUgd9FfYioEcMkAzjQCeg9+DZ5bzfGekM/b78awVP3y0ROv7KiKZc2I+lphjaZXkWPTFh1GnshiSmz1oyIp15eVy0YYX9xdD25aFsJhJ2/LLEgai76noT+24m7Ojyp8r0s4vdqjMyy6AsI6VhX/SFcsRAGLtGdWeMhk/Fsa1E3GMvjGdT0m7cVLa7uZ12VVmkmcJFJbKY++ilkDjzDJuzT3e8nE7aBvGHXLE0iZs5mY/95Fz4FMcIU7xSTlNS6lrbXk7jt3Ho/OH+cm6GA+LQOWUkjm7m46byk3FRUIhCdJOZqGbsjCGlvjP21q1ykcszLjQKLOXsqM81zTrbcAw9m7cdIZeXtLobuLRkYDxiSiZj1wGFqRgSKkVKjovAVuv5bNSZWpfCFwrPTR7/IvhmF8dH4E8wvq8L05vrMPuRjBa5dRw6unZGyDRKZwLniZ1a09mS0s4wDBXt4WACzDPOqilKv8KfXTg52Je6k6ZTsWgw4PUYOnOxSgjRKyUb56fdamYI87gKuYz6wCPkziAy2mn9zaiTrKFfLJcPkgJRZq7C5ctRcuMvlSh/um7OH3le/zAe8k1+Z19XzjUdVVK1iq6unMiSeU+Fouq90MvUKPDp9Sy56rTFi+bNnTljilLjGz/OXYVhe1st9esVF5GGlFm5UD3HD3NExg5ZjoyMGzDv01hpKsdWX/UbnbHKV3pzRj8SsBJ2T4GwSKeCqIqdLSeU3Tn7tMry7jwMSBp9vt0s5kpkJ9Jx3FSfJIzRT9x3ahI3VOpQpgbmSQasnlq9+EZwGi8mV3Jydlqb7m4VMDLokDdNukgbejHhNa1QGIxcgWuhx667kTAoAM72KH5nk9Hg2kz7Vur6ozfrMNUyT5cUtjJdpc9m+O5dNZiuvNSZ5zNbVMxsW8tV5t6xjkgvFJWoU1lh3GyrVqAosM4Dibt1fQXuC5gyAxSZ5+jz42GROKF753auULEY4UPXweOYHo5yqFk/yPbZssFPoq3hPbzMobCDlB2QDQW3f13qsm36z2ttvo1PAMz3Gd9qwNb2TfrMdF0k04Wb8Lp4n4sB3AcXCmoutTtiS3Fi3AHDiHsMavqMTYJO0q5z9+wz9pEW4A9j2LeXonaymnhsrRUSMr25Bj15gEMFA1eIxTCt3mCQwPFRXHYQ5R5NFQUz/jWwJe+xtfMLCZ/2c/vl9IAovx7vEfh9PQbDJR5POcVgyoFJQC1YMTATtpwlioKf4Hohgey+yL4c95ZWKKwNuoIRQ4saBRsuzF6qI8WCqp3WYArCzBHK+rfC3gt/A0RjRI87KKovkpKpwYosumBJItHcrgaVxy83EBz08/fLufy4mMfH6LyQR+c2avXiGcFhvBBoOVqnAKKgM0BskHtSQlcRciWIYWafxSI95SYEPLU8HMWsjqHnNtUkZDQiADCizBihOldkTFncj2QZDf1VxEnFk8qFpJ7eFUTExnz+ADUe8Z147LjnbCzxNCK2WItMuKQVznh9gHOOYWChgz5yIcFZ5zV9/609yyI+gvwE+r4u1DfXofm4LZCGcoyRLxQVLbIiVeVdKlt9FzZle8AR2aMzQsuonWGYfQN3xtMa7lQCzTdXzsnHFUL1AYXTygeAybt8wqmTbh79Et+EFzWRbEF2GDNcXxGicqR61JMl4EN4Z0Aah9QZFeMJFcIUndb4hOwU9w/QmLfXDiMkkh5Q/XCzmLRlkVavBBcZIBj0KXCf43UluK4oPrLvZhKRgKEI7NkZ4WZmLfSG9JkMNYWtmN9SqfvYllxdmLM6Stz/r3jns3zxaG8rHQ87HplnTu8mba2RBxedRQ7LK6bXLBQXI2fLbB/g1k03b+gL4912uVD1OZEh/2ruqkJxOlE4lH4Kduts1pskGGwbbE3/oWJvixXPwzmJW7KfDDxiBVu9GNjAd3XShibDKrREtab3Swn7FKkj83rWtIHXulG5whnTHgBMwbTvjqeS0QitpOsaa4Cf4lPfllaZIjAXDnejQZ8qQmm6osLlfRe5/akEqhyFFkmV0tjL1zsCbWY/bO6pVc46Udbr8+WeaxrEleXeaZltVUmqwau+7qJmtGke2iUPWRj5ksS0R91EtbMhLRvRc1ESGYU9xDCM5xTG0dytJzKfE5jnAQUrEIE7Xay1tQITU5tXGF/JXAHMsqtG4B5wj715ZSGBg61TZ1Sd8qmoB3SfwevZNRjizW1CriLT339SkbmAF6dPOgAqlvmsO3MOnsCOSDc+eFkzywrJGBre2arPJG1dRGMQVVyL/Xy9bjZLa5+Zb5c8/MPlUi7TMFoy8suCkO1l59mn2uu5D2fPMChxBbm3rRP6bMGHNK7QpNqQzKRDGPZ55aU8Hb0EnMzFYqcfWan1Mkx0QF2aYJeK2bua+YUMiSydgHpop1ad1AVJzYERgu/kXgVP2KuyrFBAdVsBBpc59+DVw6iJA1BU8/8iRI7UHLnGSkA8pOOJVGcn55JYMKZM3WqUX5mfjjyjyYKWP2Nj7R9KrbcwDW2Y2tCWbvDavFMLU9TUg2viDBB0NDap4j0vM9PA5oauEQny7OldTLareXh1e/bdGlT2x3hCbIRP57TKPjmNdutslrwkc2ghcA6iw6UDET00nMc57eaxmkdXDa2nRCQxEx64xxMNVyzC5expGJtMgPTfaNEjSZ6Irwk4kt2ja8wFJc2YLuSUfSImtqEKl+YNqM+h7DB8PoU0Euno0Ewb1FZ7EslwYqxaF6H+UdVrFY8Ez56jo8EP8y45n6HMaLQRc5GAtxeDNtOIgO31FMaRVpwtyAV6BnPi0ipkDnrjOHO4BtPRY0EdTTsjBhmHbpJGFsHhlN5FM8jNzSgFZ/ttm1N7W5v53JpDxyeveRgbkSOJPYqbNPxciavnRqgPdU4ptAkib34Wwj3e5VrgJn+mopWKrzvzULqLr0Mkq7xRMwzDzrBN3bPfE3djlP+Qd1MQrGJf4fFhY68QH8If4JDQa1oBpJuiKXoy6XgMEwLf8BVCKJjFEJh4tCUjNOHeZEl1UMrJG4HSOIFroLxapaIN+5tRSPf/Qj0l06LYvasiUo3uKwh9HBUbOpgIUAk4C4xKYBfd71ZLBYxz3R6owKngWCBmqZDNJ3DN5ma+opS3Q4evBJwu/DZcx1/uxFCZFCO44DllTys5E2mG3RTIU/T54QBZviLM5/TWx39I/Y8KmcQkUN3LuVgoz1PkCwaqXaCC+sCc00zjY69v8YGpevJEbDybhHZXK+4cQNoQTEKPjUgvlhWf87TCeMK4wtnG0GW4ePWYga2AUivLPXD9/pzArlPWshN+fN8RWBK/udYnPklRwJN1ofT7NgdjAFQlW+69VGV+ZFD4PZ4ane/XOni5ZR2MR0N8wEIRXEinOtSTdM9n066VRTrODeKkNR1ORGLBBlTSxSMBhwsdjOqU3lihQemETOvNk8vZiCcf0wFfHkFLGHhcqknyTJ78ywWZbcP9eqU/SJhaper5uCzSGbNTmffWYlY5DQEl3GXoUL+BA2Xjgjg0UIfF+3yeD+lhf8Hl091ACVeCixCh/okWyUWTX9DU5z9Y/R+JICWg52FETR4B0flCocR1BQg/SYKiYw5RYjJuhm0l3v6C0XYZhToSl2Gkuo02Jix8Vo2OOATrxGBQj8ViqJKWsvXs8PlE9QHCuAxWEF+u4fw60suQ5zNgakJdnIqnXGQVKy2TBKlJSCfSdDPXT1HKQAK4FLDP4LW4l7RCoaRyhSY3Sque7FiaEhpEh74dy8thM1AiCbTl1Mz7xjs5eDbMcEP7BVl66XtiMxXTZR6fn9pap9WvAC4VAI+mlORsVSJyMHYSQLozsugt8NTEz07zuUZI5mLy4rIQ0bS1jwOlXpmwJy6VwE/H+gRFHgAhBwvYThYw5LJmbblaMjbIASI20hnEApqlAdG4ix7msAuNVAyyF+EyyAu/tvZMmP9Tu+VmNuSw8Kpxxcd2Njk5xEM0oZfQ1nwZEcoUxTdmR6JXLEJh7DL0F84ud+7+BMLEAVmZRwXeNJXrlfxcU1elkg3BctgDaqcWpR3fO5YjbqRbli2qmKlID2lBvCto5XRXtM5mCYo62U0VD1I4Xbh0Hbrj0JY2/AwbD87hJnJDeMqcUOLGEmxt9OApugr0eINnnovXL2sSHG2+pHieYgXm5x2my9UVw8T9id2djfUu8UWF9R/Cbjg6DMrppxO9AnL0TYAy4d5uiBUGAistkO9ywdRdVDcgc9k8BBBYbzxTRwEHnL+SgwqXJqT3wb9cxXgV8SJEqccJyqCY5mrxMfmJETBHdFcCI7FTq50dqRSeCNFFNIl8LOQ6PFloZK7QpCvoZJYXIilS2Z5RfnmDZA33yNLWFGeUuzqOdwCz3BHj8SgzuBpY24UAnAiJ4KrkkSnpVKdUawdE5umE51ihMGhcgbdDfZnqLuTmxhQzd0YSTTtI8osrWJeA4HIQa78txIKl0V+JJXRrrbWq5m5We6Ki3ILSNZJJF3ZUhzOeoke5x13SAAqY6H+twM3qCkYM3Q5YNBQMPTDnQK5XySwkSRveL0CBTRH2Y8tCaEbXkfMwoolooD28THkPUZWMNhugBMuZYgktWcNASOZ5SRQjKR5184IgYfykw/XkDZbicnG5x9pn4D8d4vSNj6bxDA3DCUeipxMxT8ToHsc1NkDSSEtcSTeBPHu4ICERDXiOBgwEBZTQC9uNjpeg9rllCmLVd4ESwlgnXtMTeaClgDXzIw5p2+hLBVGb24N4PklORjzGnG/z1vmmXDoTsE8DcjSYiJ3KcJkCbKFrTuE1p/cBtcYRRYBXk4f38mmRmgz5OT/R1BDnW6kStH45juyeT2It1OwcnDWuCGpOt0A3OHpkisGXaFWkIq3kuI6g7C085qVxfcr2E7g63MyrEYqzbI8OwZSLMh+G5zjUUYXn3GFFB5AATpKeHnrtO0oFBQIeSXCfVF7Yj3gNDys4yEtnJFI4Fk1gVQ4NVAkqZtSW4xLAhTZOqkG8ZSX0UTJVdo/aKxMXTiGlcKA2/GyiRluhUOJcAeKbbyCBmGgAlq/xY0kaHNPYC+OpwHECLxaZNpFsrtmIefNjEiN1PJl0nvQnzEgxp3sH4J5TFHp3AtMkhQJGsojHWEVbLu0iI6cVxmPaiAeAVpkCHRal6adDlcCjHZQmF/1cMlcjbTOeLoJfFYWbJoHswPuF/ItKY6ti+4YrrjPvJ1xTadfufZ5g9/KZbT7IBYFx7BxcZf4dOeutEaQZj73bSB+s4CLCubqGQ+Wq8B7gNWJYIkR8bPRHNgYbGkBvNKxWJplF42L54iCBhmIYVm7PcJbO++A8EV49O+NyvNr6tTotZ6kpgpSIC2E5x0Vf4uB+NpoDbjK+fc33yrTCpbfIK4Ct3znplnMSB/1szNHNcbu0fMkQsXn8pAt0B8gQqBCgoxyDfL2WZ9OJLESq2o0YqFRIw9N8upz9mBtfRPYV8Nxnlt/jsmGljeBs71vMQUZVJkZdG3lB+8RCArvXZU2rzuk81vygEHmvLfpCDmZHCoVFVsjxgYxWoM2kqTc215nhrJWvNJ9Rzyw2YpCO0M5tsjIDVUqQesRNzXVFwCzsZMDOuCfmok9Mvj76sF6rBRB+20VAfiKyK6PcMc4zScHvK8tQLhoVIhSdAEtwvwN5Qnun823nlosglwkZjw5zmt3MegzcY0j83qvjbN/qYhXKIhykUyJAa0pdDrS0gBK7M/b+bashcALrUhwNlnE69Lh0X309KpE4hUst9IMYsc0UQhXkO1LzpoSHzr3HTTl2xbckDoWP61LkouozVLR6EhpgNnQLo409+qeXgkdzdqYjhE65V23IX23SES1qeBHi9NtidzgrXN/rS5JjsTXBHN8Uk/BEMoqn0mO4h5HZjIRoGptaP5V8IGHsQnCZx1o/2MbpNMA5YJNcIstq1tdzRPLoLkw8YuB+QkxpE9GDCcOIrmcKl01XSMbQ9G4cDgMHkNZuCYnkn/VoI/TVWMbGQY8eNHIGOzMsz9ZtOZhK3mTBQ4oxSlEj1pAbT8mS89kRDBu0/2fZNbMGwyO0274lUz2S4Ja8M6DF0LoQmVKDT3m2Pl9AaM/UKBhQRkcXZykb5p6vEhun1ZUQnNowf9ZSWVZCzeNCgUbRToZ5tk5rH2KIRBPz3GPfvskyTlZXKKCGrQB9bzvzNMWm2rQltscRfWfPNqi1lnDal7NqGNiGrqFRRkqnVvUYYxxnHdu2oOsaa0C3dpc0mLD2I6n4/DFQjzYtFOjAIqe8TQavf5zOZeYS8fHV9+FAw8yGbRGiKdoL09Z3MQoDuTRAlFQIPVDwLPJ22z7BbViYludDZUeQRg7NK1kiywMJ5sm63RQCEt7BT+LJ0GkfDh7ltZEpSNWk2GbPkahj0GK6lYDCZ95h9ARw8dtlK+XD9LJCoSLqKeBlPrycCslVBjqSp3cAYhRW9eAIcbTlgiF7tklHazD4cXxAn/TfGIO6rb68Dr4nkPkDjkyRMRlGew5oUFei1nTuKtBTAnIFbpg9hRl5mvN9jiuICacwcwd7aZejJW/3eR1IZun0DQ03pCX7bqTjUhPcxCscEoi6wuoYFntU/8W39YWlqaLA3Li8ODkOa7OVdVJEIwfeofqk4+v94GrFFZcB+T+k+L+3oNM5k+bRWAvHSw4CY9e9TcSHeiMHDbjOiTKhnKiYcp16/lqmiIxTGvkxJigUAuo1oPaPuk5yWfw6z39JYpPnbyN96B0SdSwrHHIIW6F4DHhv+9+369LUaZK2zKIIsAvh3E591ThUjcyA8r80//M+KMj55m2gRwL6iNZCQBTvcp3JD4KOy10rlInVS+2+1DydaBvRTi7HRvrmizzY8xuC6SOpPQ0Bd8xesAK7rFDvvmnC6l9CXEUX8zbSRyr5b5QHSMawRtjBcjmeq2vUtfMzL0327qPWCBbCVNbYFsTWkSZHdIXrLL2u1IGNtXUMND4zudNWIeuWahBhn3ctE4W2bI7bZOY8hwPolMaGuU30Sk2uJddpSGNLsx+h86idCbKJpLMlJOgd3M3PGGaet5555lm3RzaQVQ1ljr9ssAKEbxz5iDEpC2keL/Qob5tDQDph0F1jEp7mtSD2v+eqznipBaLyx6+hEJ3odDJvlRT3d9Zxt2ugFlPoSo26PIooT/LmpJ943B++ot87dVlBj983i2rOfqs0J4V6atbWagiQpljyKWxgFJm48bbjzqxgUjOYEEeeqslqPdUL0g772bR1HhedGcA0rihFD7tXSQU7KqKnriZVnoIdbbQaorrnYz4tDH6bKwj+g1MkpkE8hXd/EGoyETCh23LeObdgz+5QED3l6Vix7DkAYMHcieC42zsK7uWePs4jjvCs6RqoARophiYmIU1F43vNiIjLakV7tZ/qK+jbLg3EEYRQptmxugqNR+CSAUMbZZT37SjJS6dCqz4jpbgDOMI8BCGBWJpyS95CqUQet92rqYp1GSuK0BWcJRWgy8Bok54zg5p7rgT6iDv5iPwY+fJDJMmSpAE60Q0ycuZbCijJ76u657TbCvEYKhZSZQMpL55XAbXcxGBt9Si1zpYQpL3DzdBx1prUxlRngNfBawtyybpIygllaHJPkxJ3lXubQZHxDeYVxt9rrABHnnDvQD8GClNk1OYBrgxzpkjDXTxBRGZ/oIOJJKLIOrmcdjzs6bSnHOc6YWqh3uRiBfMDH+Js2Mqz2jvmJ8+461jmB3lD8CX95Be2pMuLQ57yqxuhG00WUi45lSSfbQOew/sGm4EKUXmHnIuMLNqF+UwAQWRT+uP3l9FwKXsGlZoqSGFedKzPpFJAOama0k5jlu/4bphQy8GLXb29VlpmLXT4CM2OeR60kG37EaxQ8PsI7lGYdjdQpeGWuPQifV3K1XbC4P4gXCDs9Hpqq8/YJgRXRUWpMxTO/zs0rKkJV+ESXbsfeKc2fZyYFC5tKG9CCkfZnXINFa0peIh7VCRiyTNnKN3A5RCAJomBLLgku98aFOdk7K6Rt7Dmf7FCDHQJ70lIY1JJPfCoG2EOlqFu+0RtZ9uf7bSTc44CVpvZ3Q3IszWbkSqgVPJJymONqlEL1n+S0I3QAQFXggHWsF02VvuCFm5kkNkFweBt8E6QEnGfMLBOTAEi6/PeqJjMaByfxVxy85wmk1a1j4rV8y+ZXmFqq2pt0a+d/YqgRLvgJg2AdAZd5YqQ3R2pGGoOY8QBkFfsvTr3RxiF6+nqAtkt6rWoIPVisEyooWtv2KrcsVb6h5cCyhXgfYCTW00VnnTqVsPhG8hUmHaDkHJq9jbCp5Gu7lr2dzl1byO3owKzWAA7uTtoJjNeEChFO8CBhtCIiH7nkpS2gozfhROwijMOqujVUDuNk+Dkow2RUjpl9fsWNHTQIq3bYD+sssejSISybI1z/VUVj3IkPP4emfIPpo2Y8Iy2sfNyO4OSMmywn+rg3QIO0fdlsCkNlkaIEqwX7HiN4QZX7nD1RQIlEzsXPa8DO0XlTvRUArW2s9+V1g4mbQspZz3LslC3U72EiZTOVu/hQUn70Hs6vSanf7lTLyzJUSWyTswVL5fpJBTkjZt7OodN0Y9t4nW2ClvPIEIR9CTmuZ5dRvgWOXDn2Te+3fGdD4oiwze8PD2piTWwzj3C1Vp74b3ltr6oUmnKmbqV2pPYMrU/3+kmhSw+3QXRTYLzBxtWm9Zu0iXk7yR5lqMhIR9e2AowpHP+lpgHQuYDbFQCDpDCkXv6WCQDlgmN6eN8/bftkwUFn61d80mE63ajJvoTkwX/qpMUIM6JXUQygIHyGn5LRMIY/r7nzshpBTBvwh/t7tlsWKZtORiCml+2nyyY0k5WIaZ3G1+H8am9pwr3j/a4+mIqP1zZ3ZFRlsbFVWdGq9EDuJLJ2ZMpJCMSnsU86TrK/GnUn7V2H892JWY4P+bQmMj2oAH7fe8WWJIFhSSVTvqoZS0G4ZCkmxW2+Sgn8OwRNU+gLIqYZ1pHDXlouTMC+pi0QlJ3ghiRrbiMiyOsm22dBo+k/u1mP99EAaFfPCQZwHFpm0yVB9e6xjOOWi/7TRUlMw2ugO8rwVQWsxTDa4MMyNtiSRtqymCH5+O9J/RkqhIYxHMG7Nbv4czvBX0iN3k2qJILIl+0JAwBL0IxQmD/uZsiHWlI/XUS8t1Itz3cXTJWuPRBWWFMDC3ipkxqVKUUhBjVIYieAvB1Agn/ILfjYVezlIudP0rLlfxyLtifUnLLX8KYfOwFSC8AltDL1gbMDm3ABOtLW1DrFkaZxF9XIkOAUb4BRoKeC7jelwp+2nVlGeFl6mvCAH/R5dOkLXrHu/tuaJOP5jw+ZJJ54234xnyLRYTuhiuxaSE/7LJ1y0dG2DBa99ui2LBuvmTrEb6lexwlvHRS2tyGdjwiqSRGv6W9c/usRuDltXXn/lLCutizFe+jBc1/bjLuIKGUXtH2LtCSjGl6m1g3fl0tJkMqJ4zZTskwBpHoPHvqU7tW/nMqjLs+XQDwIxisNXqn21Ho217uIWVMK6yOYe53qp8RVmzqDzb4OWBYQR2HK6m+KI49tRrwzOP3j2USk4dN5dNkmWItje/3ROo/7shY+llLm5kdscRkXBXk32EJkQs6Ab8D9wH0U7dvplqmqhC1meuuKAzuiNzz9HNcB088PozrL86RMG3U1NkEtG3C75PYko5bXzyP4saY5zCISejVBapZsNUDusYjIoSiQtqfH+LXNXPg4Mc9BnPa1vE26y+PBnTv8qsvV/lWOdswWEu5UqM1+QWQCsUwXcmpc0Xb+Cr9m3njiMas3RaFcmNL56al8B03hfqZXaHe/L///3s9r5e+q0oClpHVbA9ZWJGz8cGRyinp1uSvjXMVNiLN0ZnLP436yXJ2/5+eJbac6f+PLzJrzlY0rmZX8F2JG5r2RdrzsadtvK+neoWGSh7VPOqS9jzqkHpotn/z4cPtW9eunrrsfwLPnzt+7NDBY++7LHWdBpdXU2YqPqc2HHk57dmHh7Z7ZbLCP2/zCjC4mvfIczoZJyJkEgo9b3VsupUfL5Q01fCjDFVfj9vltHZ6/Ru/zGT8e+DiuNi3BX/mVZFtwtxTB7/4Z2flz1xi0J4ug70PGUNT89g1jol0dNpLTsIZ5SWW0IN8uA7ayZFVtG3CdyPd7CUjDfrus4uhgQb1x4ra+L1jnb6f48Hd3Eqfh/98gt3jSLJEjlQeHbCEUyorVmlaizRhhn2zXlPM6tlX684K8Fp3b26kkou6o6VL63dU5rNdjiuLIQFIp2+5/+vCdgvwWyKLc+FgXGl+T7yXBBOrd6iMICfFSDA/9DYqICscCmCNRWDIJtU1BUoNhGUAZ0AmnO1iicd0E7SZQC2mukBAp6OMeP5ZOabehwYvS+tA4qQDpLOBAY6asfsV7szWg8X/aNUfkK0q0zywC8XS2nWzjk7GfxaortwN1RAM3rMHV8PuRgQY/L2+/malBzM+0v0G8OxlxwYCPG/x/6Ne5WttLB+QxAAQ/ErIIR3doN9nA9kv/RbTASXnz27nlcjmqb8e/KUwWr3e/cWZ3VfCzYyWfcyecczBbTuHoFXkoOMvBX+iPb5w4Hr+oBd/4hGP9PePcBUxtbPHP1elzWWMacuBR1ZfBZfnOY4z/2QzeOQulDDizK/whokN555k+MdpeLQClr2Pnf3IXWRsgnBEDyBk9+Xf/TM8eKmYgTD8l4Hl5iqVrb9spZwR8M8Tkos0MJmqTAO+VGXBEeC14qgwBdjn6vHJRMvpJzN69j6Z8zf2yQIr7Vgsz8VSeXCLnp0ANunvl6lF8puonyZ9dVDrr9W++k3XzZeirzZ+8qRaPnGxIIGC+CjUcrr8AN0a9O1o0VejmKKXLJAv/4M5XYFsVn+nRimRpUyuKPNWyYzJTKJQG2K71uYSUNf3FyCAN7l5j1qsVrTka6aiU4smbN8EA/TXTnGgr8ydWov+DnX4aifs2y2eokPX06S+mih6eGD2oXBILxYIfMb/gRIM5+yKSxrt0GSn2Vy4aubmC3ctLrvqGg+evHi77oabbvHxC2kvVKtAt93R5p45dtktyA/BQoQKE+6+B9o9FCFSlGjfxEjWcdvSKdP3WC1FKkWar9Kp3ZxPHxkyZcn2SH8DDYpIBsiJKHJ/we2WweG+hxhmuKHWGGGPIj9/Yezbcooy5UYabYxRKlSqUu27o2oimtPOWGElYyZMf91u9qtq/28TMUrKc9x/ZPhPjjjnTGJL3zaCdSSGHK0l0mLHSGLEU6terHjadOyzl0EksMVWJ51ywX4HHHTI+UhkvBNUkc0EC+n55Td3yBzYm6fBehqcaJpsommmmm6cOp8lRLJylad8pStDmSJUS1kyiFS2cpjhpcdmSvLUC08K26zPzVnVzScPD5xcW5k1Bp8+1tp+uWfuPYePXa0v8ZfyhfBi+g8w4D/wdzeg5x02ml3ran0hgpxT/zhQkDy2vf10Y/DwjuPDye+D/4RB7qF/y0DKch24dPHOW+w/s7fyonzQsZMH0/7XpMeZMyf27T+jlXClMxf/5gOmh8Xn+5nbXwpk/dDlAf9X6MyKrfhNe4ut/Uqq/O91B2Geb5v/eRympyP83aPn7heJiTTz/3v7YvtgNEOk/Rg67fT16yS/7vVrFlT+omveXqF15GCj/5x9UOHW+KzD1umWce79z75fy0dkN9whHCZ2+rYdpb+rdXpYcgcAAAA=) format('woff2');unicode-range:U+0000-00FF,U+2000-206F,U+2190-21FF,U+25A0-25FF}@font-face{font-family:GNeon;font-weight:700;font-display:block;src:url(data:font/woff2;base64,d09GMgABAAAAABmAABAAAAAAP7AAABkhAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGnwbkTwcKAZgP1NUQVQqAIRYEQgK0kC+JAuCeAABNgIkA4VsBCAFhEoHg2MMBxsHM0UHYtg4AAjcjSOK6kkm+79M0I4wfruC6BAtolgOKTMZpniIUpNoMmIsC212W/dHSwstX1zHS367Oq7yZhf3LnFvPuF3x/J6hMY+yeX5YH/wnbnz3vty4zIURjFuNRqi1BW3pHVI29YJzsQcT3P2s5ts8CA1C7K7qWFJNoJFaX8bpGZQwXoHpUeBiuclmF+hTqH1GGK5Fq8ouR7QlBMLZ8p9Mf7a7KXtPeo7OP7+UlvSYcA0VQdXblgD3Az+voqLMCeEiVBRUeEJ//buM2fWloUtTZPAs7ZMI+6O5kYjdAhJvCRCI+SVTqM1Ep7miMrtkUPvZ/Y09zkTOHizm70SywqJug5ok9z9PWC0+brCV/gKQ7oF8P9/Ost2vmdnD1AXQoehX4VLKqq8a/N6aaRZeTQeY0jW6gCt6Ej2ob15z/JeXmyHgDuyb/fIAaSWXp+Xios2qVNU6ctcUTd5Si6BG9OFhjRTDrE//Vqvc8HaSWlIdhhkEJ8bfs+Rm9nG1kcWqERuhHH/H6qAvQCEH4wLjDsPGC++MLPMg1mMhOHjwyyzDGaFUBihKBg5BYzKKhitRJhNdsLssQcmRQZMpmwYIzOWFi1YMGA3ihx+xVXajcB98LbcA8DFBsy0AAV/4K6cAzDzJ/2lgQsUDCgg1YCDDRRXWJ0qHLBK42mN3y7hh1HOUZ+B46i9hhcn/kj/KNuodjD3vb1Vk0v4XNgGq8Sod2VnVGLjUtkWZWxDzrs0rrbjbOVi7LgGX4nVjpU1ripwDzS5OB/pMGAX7Ia5eAZegBfiRTgAr8DBWIAlWI4VIhZ08+E3FwOJd2UzMjFrgXOFIZHL3fgF2+tteOvdbm9XtqLt2CaPxWXb3I0rm+R1av1qdayPVuN6YT2xbl5Xr9S6cPlqebKcW04sscvC/qZHu6Bz+53m5//5JHfTkJpos7i+q6YqqvhS12xX479//vqD94anUOkMMzZq245de/YdunDl2o1bT569ePXuE4fL4wuEIrFEKpMrlCq1xlyL6fQGCB/3L7+tiDKohTq7eDcAr8PZfHrkP4mSDHhLfKy5pvpn7osRv0ijYymIlxqvnLyp+Vx4z1xwKBuMYwsAQHgtvBTtIvYFAsbbbdAJBtqWh7t4TwOu/lYMHPxhOn9dDCzOi/Y9Ip9WDRrCJOVV8ycFQYm8suPzoKUp+cObsearHRkvC+WQea5EpmKCHPwGmDO0fke0kPhoarlp0bgNfib8l74qnpURu9Od64PhwfjM8glyAA/lAwEUAhEQQxlQQCXBHGJQB4zAMvcxhccyEo8sRiTAnEiHIx2RoPDLF03N58xbv88eddiuLxruyJyBCSgAlle+AlLQIFSphCMX7GEf3koP5CwKnK9+oq8xfSJxCDzrfIIgH0w1J7KpZFkSIjn71hAYFjAvd/VQIMIR1pd8AhnntPddDLDdLzewQGhK0AUujlIA9Pk3VCZq+xrU3G5J753ooUGOoUEIXAFRYtvAxkpy7yBIQpnDMPH5gD2Rs7TQYRRqitKTDicE46C1vqzqY4YBGF9pS6KCyaxM3CZvJ5Xdrv7UAEXP7QmbCegQ5qQFSyM7Orq5n5LU3GWjhergpI9uTLyNkrVWMWEGHgWLAv8Xe1gByLnnPqQl0vI5+FX+qPjBhtYAq/DEkBmHQPDahuXIrj3Op8MsnBfnSnGq/RanhGm+SOneBPSRgq+dw9MBun5VFFpgw2te0c6QgwNY/Os6l8t2D32vQcIFCERRaTrofh27UTofLe6N1yT7GX8Gmiz0YcHTnWceWcITbc/xiH2ersNKQ3hx3QhFIwUJQM6dZEM0yHqdLu9qgu/J2gu5ZZAvjLZROzj9Brb9/vLgFUyvYf/id/b1EgyQGD14/eYF/vFtT7oiuKFa5JbTbwy3aK54AwiLBoXNQvgAZg7WlmBUJSxhoxLO1JoSXPjMCIcdtxCK+AGwYxdz+Zw5lfsIkJeyFbjePHzdLLx2ej78E+Ae4DL05NbbQiPemX6sP8cDbK/Tn0ABckXswGk4bJR1wVFa+jj8sXsycvcxmQerBb8PcEE/SRZbU0H9/b2MHAEXQmqXU5rdZtWuU7cRb3zqV//wP9NYWG3Io0zkk8ZYLJYr7yhvHm8RL4BH8YwBftMuTgslk6zRbRb/4fp86K3P/e5fZ2Q9hpMf4c3lLfwTLwFgD1DzJ9zzy5rs8YP/frQX9ie2yTbb19cn+n/A+es9662rXz4rh1ECN7vuK+AHAL4pHONis4spJaCuQn9vrzntHINLbrqtXpFielccV+GYAiecdF2TZmfdOtZoPfPqvPhXT/8yhcpVaz/y+F9f4p5SN5x3xkWX9bhLh4BjccHG4cqDLy5vPuaZbY65lgjiLwApUKNQKwULIbJXBAmpKDKRoimsoqYRK1GceAk222GrbXba7poMqdKky0LZBYPNtAMA7wLqUeA9sOc8sPdl0PsB6k+AwOfZSFVgJo1ti3qJrFtXEc9xMlUWDHZpKs4WDe+LAx6J3DoPlmb2oWOxZYxlBaTrBLdxZb5YzqEpSi4wZyFrg03HEPeA9cEiGdO1l3QaIZZGtTXTXNdNXb3WpfXpRLRdG89Ec/JIkH6DX5UNGS1Vs2Eb1Km5MW1wU53tmpQQgsTEPZsWGUtTtHEWfnuY8V7hvkYB5PuvunR9YOCRZR0jkckrJvywW6Nh7hGAjY39fUXRQr5FZKSLLfWTqp0YxCI0wwZq0eBH49qwVULNh6tP1zRJFIrSc7b04yxdofJmaES+/3IAi9HBkufNOXNdHYiUTnfAhYdDQHU4KWdhTxl4Xofrhrt3WuC6/4VVre/Xs6+Xl/Z+mpWoezXIXCQKoe42cn0nMCl22O3ZEclRdN1Sbj1lJqPfbqS2sqHPNXpZHVUq87kKy10WRcHlUaiiV/2rYZSE+QVYz+ZUlaOFpaaZ5fxiEceslJe2Wqgd2mBWHEWu5WmfLSnvpU4DpCc2sIVQ6XncQ081KkFRfxnR+BwKPKxfTpVn6RjgPDaAikJW6TxXtbKm5WtuLB1GXrbeqMilRapuwSxpome+SMnOZ0PVXsWA7QBxLJWS9C0xm0lnq0WM3UqY0I8Bj1Nqw1wC3mEOCkE43eNTD7W/7ic14FoOpthcpnsqWbNwBWskZbCsJnFt4fgMiFotyq41OG2/bAEaTJLCHWINyMkz0sxBZaIxsb64IR6OYA0NQRxY7V2HurqGzOHVRUF169pGWpZqmOsSNGwclHZpSOPmGXxaD+ASDdW5lLWeE7u1ZZ8OPHJmhelXmjKa2ED6k9uIIwPTWEl1JvRupfvYsUQme8bHpWYK4lgkF6ISjDVtHLRWOfMeffN4DGCUYetNcynTFkZLKnCJNmxpMDCfrcVlBuB2nuSLdODMvV+IjkvKBMMiRSn3VeUBFeDRplaflm5V6y+v5lnWe9YlP9abq08uXCGDdqkt/yvnxfFlPj+QImzA3fuRGfXHrk/6gZ2uTaNfrBlGT6m2XjagriZbFWnhW+OsbWuzLDOFVUmLxtoVe+o7m7pjfVgZXLtbYtPe7Fp4po5Q3oitUdNxiuNgo621E7FE5NordMNzqRWEweqg+jPaI9XYphsFi2nbzd7yHSvf0oePmN+Mnz9xHngDCfhyLBuMCQ/PjVDRkh6PnhCrRXLde5X6KhMCsu6zohRSbMp2J+MuvHGuUcfa7NIvdMAwRDMN5vQABasUQ2O1Pg2WzFIvVlXqVv60+YhgRXEuVsVYnb7AOBugWMZEuyLLKru1mFkhAcqsF23zvJvY5mmsn0E7GtMFoXdCaUrAOnq/5NwsZzDD/hXOYXpmrov+WifBfnn0N/1Xfy1+a1989Aq5yYFae9ONkczqC75Toe5fYabrnrVa2bZ/DaOftjSprb7XgCqJUcuvbnl5tw7XAmLPNC4Xzc//dPmtB3vvdw1oCWpjsGIojIZFsG0P8Gp4V290t5qDGsia4iQb1Y8prWK4NrGllCeV9HrjfR4epQ+u7b77eubZySXxr5I7F/cy6fmez+zkyHy6X8BzGHnhb4KyojKQaaikSaqH+iuJ0hj+ePyHHuU9fkrkE2YijXgKDNA6bTH4Nd4tuNvoZzh3nM2HDtK0yyuFCDufmkyiyr3EaziKeReppL8odaX+t6wUkKjkvbOX1xCbCZ0mkFZIgyEG2ya2q8pA+/j7nvEJ8KENILOrjbBtIpx2vaUDM1iQWTfS9TbUvEhSkOWCJzGEq5VmC8/SNRv4XvKqQGrXkw5Sfy6FZXZkh0pGb71eWy4XY3CWrtobyDt/BVVRXgqugqoOxTskSD/c2mkNILFXsxkWU2OW+PiofVXeHzN6vLiG52Ib1xsGDEnb7qIdDOPI3JD95AisV9eAwWB6dEEygkWbQSp5iuqDv3sc77w8oluGJj/zVMg9UB3otdlwUeFTku/ATR98Sr4SaBrmiPVhKYU9UVyOIdrzdJ1wg6IyjOoYAWSwljLYDeRaDK5Fo4/BtK0NhqFx5IIiRBlyXlaCpUCMlJkmbomz/QaNE+XESIbtfz3/g2AguUrYIFn5ZnpsFemt9FZQVeP/P71qSATu2oFLf4T+GnpVO+gFAqji2rwN9nM36KUm46iJZ+uINKIXDb2sbHugi3h3VTKRph+HHktW9Ldez05lD0iqUHFu6PU5S4QMpcAAjnrl7KWhVNwkJdAROIXs6sMDamyXvo9dY9QgemAqzME1sbr/zDFaAdcXHyaYmqWmXoyzSXNBBEeozsf6cewU/BX6agCKnaDftczeJCcneXeeJGXU2KObRUc5KWG6BmY7VePZUAepWwcIQY3UupOgR3pY9iwB2wTo/6qhleh9Kt5JwaFtFIO17ZX0V5+XBX3zv8n/BZWGWelfQK8o5ag+tyIb5QED6hFHS226DiKfGBFu69VgO2Io+lHVUbcZQpcuZaOT7oX8amxqrJ8od7WC8dUHXwNg8ydh2RDbrcq/8cgQuvizSfhGEZtrH172oLAgBBuqrhJFGRuzebOR7wBpcoTwUyTab9MUtZ7Qr4yWghRi6V2jVIe/6VDybVKpoC4x5FKQrVCdSz56h0p+byjIoU9oOBO1foW+Cqd7G0cfQx94eWRD6yOHjRCtqnde//p6fYwKXOBrVWnZptpNRZe36LaUvlWlmXU3dRAMgaOs0X8FVlzsuiUqYuJf4+DA8kt9F/ugZDyL8CqvG7WJLrahSip6rwYGKkvDylDc+aXAEOUgFWQbnTROdVDjSXQbmYYdVIewGI77S2SDz6FAc+8G38IMicbkwKvtIIWZbnPrK1nvmxuGGCSqKGcc3UTGT1Lg9CwZgn7E3OWIKufkE1Xs9KKmTBaC44Qg4Ydb0w30aEWNp0TmFzD/ApCvsAOeQ8fD4y+uHq9P1ad2HJfAv+wwhKHmlsuU2jXyZzY/RTLh+q3MSjnjqcucZjn7vk3OS/RET6EifCXH1jFD7SpdV4k0eANKKDxBL+1PrmIcdNmv/cyZ9hkVUT77ZZR0i1TJ6cvrFChn1yw7oNoinV3RoYKdDv3+NSUpER0YSqz0WBJ10c2lOqjRXfR9EXOboevyDFW/EmAAIQQiBNMoz39uN4gGh0J3Ph0EvyrIGEB6BExfRox0a5D0KXAQR/eUvww8kIdO8+xcOAQqKt5J/kGkEc1ccOq/zwzb0hDKfyPyiSjdUJXCZWqMMDNplPp9c1Tob//PeNjXGQbQ9/8VVTQGMcwM6j07Rzy/RPEcsM6Cd9auTT9C0qeO8M+g00do/vwWyDVpGVptKigh9NoGdHxFWSnqCL9QILxgBWQ4U4vyypUNyBp8zRB2rQXey7YgMK8sswAHyhyK90ocSvgc3sYW8x3q0t6i9D4d56QYNCglW4vt6iCBVVdMOnHOmiTheV6DKxuOnDPQu5wkf+71igrrTY8gYal6blAhAn1D/vlKz0oG7P0o6lkU2uu1RD6LRP12kE0COo9A5AS05ROGEULPOq18CnkB87piYTWMo5feGhFEj2Fan+fP777J+bMKt8GfgeaK6S8Q0twV8MYbOnWdIe9ZkMVZqBM8+66u0ckoWZKsT46h40bpz9Db8j7YKf0pySl0Slr5Fn0G/umQcfjWlonz3IePoWNP9E9WPUFPMqZ+yFmV0947gzoN0hv4k9GUEIWWb6/uWgPtTODX0dFOfkM6Sq/nO+Npti6MyCdqbyZd4sg6Kn6Sbkif7VV3s+7w1bi4IBDq2JZd7A4DDSi5MRmpDF+MH+mMo5frV7LTCQ6Rzm6KQlGNTQjOb4OyYlRcgkrKUXkZtLbCTTCz0FpkZVUkZN2cSlZxnDGzMiETqsFtCppEK6dKXDjGpgpZIiAP5P7k46XBbWhgnWO9X9/8+2G4xYGmPw43/Z7rt08bln0S1Pd5EH0pbZBPqZYoeXN5i1KEJBRCRVP0+vLGKHYO1Tqf0lLzrdQmqnGOmjbC2g873T5xX+f+idtO9xcSvJj5MXnNMfcauZlSIWozlgE7drReuus89PcmVi/XNq+IOvkNHU19e5JaHRa+obYquK1YtHZ7fkxT+IlMLB4k8ondkIO+g2yNg7P/17N16X466SPy0MCRi0M9M8/gTyD/0kgWaj4ci0riQ/4RZNHt8hDpcz+Y5OxZUEekgRWmfvnuyb1k8khxj9DU1qnMw98/+z7S28+Brc+2QlcGPZZEaqmkUXoT6YyntGT8JLmJe/A9Iu2WSSfETp8/F4jSoQE1QOBp0Ov1Cb93cSXzOKx8o+C+QVi9Q/Ab+hWdUHNAyp102ujB+GiY99zC+oWChQ0LRQuLqF3hwh0MDvhFwXAB7EsHuPEU3y3my1MTBDt2BCfu3Qbrr5AbhuAbsHmD9dN6wM+FATuY06RsTW1RG9UmtZW0gLu/aQVReoXGFcQrotRGYsKzjm+WpbaojcQkFyeBayUvcuMVpbaojWoTacEr1Ga1RW0kJikkXCPFtFU2UFvURrVJbSUtSTnk2EtUynZAVHIbmRSxS5MC7c025nnZ19LXiE1yU3S8QW6JOH3bOFptURvVJtIiUwIoO8clKXIHmRSxS5OSmT7TEwGB0TTYY8CkOTuxBMz7h1asa6bb4pn782n9ez1w8ZGhgRNe/b8JoPvTpQAAp14HGejdrCFD+lpV2cjIwR0kIzQHt7uQD1xUkb50lSoGAZ/BEjMBKrS3eQTqWJwNvIUkod7JcmBgi401RPpaVOlzygE2PxORcIc82WIiaMVWRLWylmCEnIkaRoMJLSaCNJuKAcAnsMSMQbH2NiKoI3EceMNnQJ7+LpMrRUTCWuE2ZQ2R91QzhoQT1uEZyyaQwy3eOxtSxplqRxFZvwCnAN5q8F0trtIWmJU/jbbFzNTUmdbyHcEj3jAglJ/35p3JByJ/k1ms7wDvt1cY4PNTWe20Znzr3HbAcOAABeo/Mustxuj//tcC8/xkvZspM1tNdqM1DYNpuYhmSGhqSrL8H32U7WgrvIHUuGWAgsbMBHq0DXZ7xheRtsfujSQtP8lITGhNIuo5ALlcKo9dRpR/mMkt/ihwuUiH6hWCm8I+pUQE6SQcvVw4VC5i0kWgRWVO2uvR85aZKPcszSWMzwjzggBwwPDrwf06mhRgKpawX2PSTcy/Lh1sOU+YBowzM+7xpzELbQVpdRKli1bp2WYtgQJpcXBMlpFvw7SypbwQ1tGkeNwJnGWpkDR1WC4dA5GvMW/w83frT4JEY3xC5jVRblqSZjPqkMP5r3m9CC9uwIkrEOVPWIEk5W9O+RPUDEzNJAgBERnGNIN/ZrUKhjBjQgBHviaD5f4UUeGAXlWfEpgT/HumgHyGrn6+/qsGEIUN7jnl4x/jv6e3iKoztx8JbSGm7xK1gqS6rDSOAbMNTD2YLjBZYBrBrAF1Q+ZKySIRxlD1qxTfm1W1ZtaULcb4woB3bUCIxG4Hry8wYLdTWLDFDcDvxpe7Y3w82h3nqnd3llAVu7PNlwsE2Q4cIt+NS8hzfxjAXiDY4YbbItV+6TLkam2IHyQTEj5knxz7c54blWCHeKZ8utlypAuRIJZWghx77ZcrR7YDVlLKlinFZqlyPKgtzBMuWOitdRh/FK/GLSKqeJx4mrCa4Zmp7+SqYfFBR+XkRWPTkFwS+MYKUodIQSSq4B2p9vFdhTwkIjuL6Tx8PPLQlZtuv9PJsxfL98mWJWTLSZXJfA/xPHl02dKEyI627FIr8Bz2L+dZL9UhZDz/yVNIxHJoGn68PbIUkLUOSLssQDDc81TnknBfzrvA2Z56bC+TfcyqkCgpaHypnnjmeeXXsi+89MpIzRXF9u2nCWf3oXQfsbASEBJhiEmMGpNhnJRMhEg/iqK237syveOALI00mQSrrHYQpXyvemxtWm/kyndYXvXW60m0zhHrHXXcCcec1FJf9v42K7bFVqeccdZp22y3w04/sdlVy2bWjsl5NW2uL++6tk3EPWzNAjQp5IXDTwwPnpLsFk3OR6s2Su06dOpCcMcqHGOBngsDrl/9phuPvyX2cBXITREkOWyMwDiYC+aKuWHuUEGlnMOn3prw2Y68h/eHhipC2ZpHcrJXbikIlbj94+jm1JNfDtz23JGXO2d2GW4eVuGWe19myn1luLgbmzY87HIA) format('woff2');unicode-range:U+0000-00FF,U+2000-206F,U+2190-21FF,U+25A0-25FF}";

// 游戏界面卡片（按 AI 游戏总纲 §四：母卡 4 张 + 选择卡 1 张，皮肤 A/B/C/D/E）。
// 字体：内嵌 OFL 开源字体（只含拉丁字符，见 game-ui-fonts.js）；音效：Web Audio 现场合成，不加载任何外部文件。
// 每次只画一张卡；展示卡纯静态；选择卡可点，点后销毁为一行文字记录。
// 样式写死在这里，AI 只交数据；颜色显式写死，不跟随系统深浅色。

const gameUiHtml = String.raw`<!doctype html>
<html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>游戏界面</title>
<style>
/*FONTS*/
*{box-sizing:border-box;margin:0;padding:0}
html,body{background:transparent;-webkit-text-size-adjust:100%}
body{padding:6px 10px 12px 6px;font:13px/1.5 "Songti SC","STSong","Noto Serif SC",serif}
.A{--bg:#E8DCC3;--ink:#43352A;--main:#3C4A66;--hot:#7C3B2C;--gold:#AE8A55;--soft:#F1E7D0;--mute:#8A7356;--drop:#8A6F4A;--good:#2F6B45;--bad:#7C3B2C;--warn:#9A6A1C}
.B{--bg:#221510;--ink:#F2E7D5;--main:#D9B878;--hot:#6E2E24;--gold:#B8924F;--soft:#3A2519;--mute:#A89A86;--drop:#0D0806;--good:#A9CF9A;--bad:#E0624C;--warn:#D9B878}
.C{--bg:#0A0F0A;--ink:#4ADE80;--main:#4ADE80;--hot:#F87171;--gold:#2F8A50;--soft:#102016;--mute:#4A9A68;--drop:#020502;--good:#4ADE80;--bad:#F87171;--warn:#FBBF24}
.card{position:relative;background:var(--bg);color:var(--ink);padding:10px 12px}
.card.A{border:1px solid var(--gold);box-shadow:3px 4px 0 var(--drop),0 6px 14px #43352A33}
.card.A::before{content:"";position:absolute;inset:3px;border:1px dashed #AE8A5588;pointer-events:none}
.card.B{border:3px double var(--gold);box-shadow:0 0 18px #B8924F33}
.card.C{font-family:Menlo,"SF Mono","Courier New",monospace;font-size:12px;border:1px solid var(--gold);box-shadow:0 0 0 4px #1E3A24,0 0 14px #4ADE8033;margin:4px;overflow:hidden}
.card.C::after{content:"";position:absolute;inset:0;background:repeating-linear-gradient(0deg,#FFFFFF07 0 1px,transparent 1px 3px);pointer-events:none}
.head{display:flex;align-items:baseline;gap:6px;margin-bottom:6px}
.head .t{font-weight:700;font-size:14px;letter-spacing:1px}
.head .star{color:var(--gold)}
.head .en{font-family:Georgia,serif;font-size:10px;letter-spacing:2px;color:var(--mute)}
.head .r{margin-left:auto;font-family:Georgia,serif;font-size:11px;color:var(--mute)}
.judge{display:flex;align-items:center;gap:8px;margin:2px 0 5px;font-size:12.5px}
.die{width:28px;height:28px;flex:none;display:grid;place-items:center;border:1.5px solid var(--main);color:var(--main);font-family:Georgia,serif;font-weight:700;transform:rotate(-5deg);background:var(--soft)}
.stamp{margin-left:auto;border:1.5px solid currentColor;padding:0 7px;transform:rotate(-8deg);font-weight:700;font-size:12px}
.ok{color:var(--good)}.bad{color:var(--bad)}.mid{color:var(--main)}
.news{font-size:12px;color:var(--hot);margin:0 0 6px}
.B .news{color:var(--main)}
.ev{font-size:12px;color:var(--mute);margin:0 0 6px}
.ev::before{content:"— "}
.top{display:flex;flex-wrap:wrap;justify-content:space-between;gap:2px 8px;font-size:11px;color:var(--mute);font-family:Georgia,serif;margin-bottom:3px}
.top b{color:var(--main);font-size:12px}
.d{font-size:10px;font-weight:700;margin-left:2px}.d.up{color:var(--good)}.d.down{color:var(--bad)}
.bar{display:flex;align-items:center;gap:6px;font-size:12px;margin:3px 0}
.bar .n{min-width:34px;flex:none;white-space:nowrap}
.bar .t{flex:1;height:6px;background:#D2C2A0;border:1px solid #B9A37C}
.B .bar .t{background:#3A2519;border-color:#6E5536}
.C .bar .t{background:#102016;border-color:#1E3A24}
.bar .t i{display:block;height:100%;background:var(--main)}
.bar .t i.low{background:var(--bad)}
.bar .v{font-family:Georgia,serif;color:var(--main);font-weight:700;min-width:40px;text-align:right}
.quick{display:flex;flex-wrap:wrap;gap:5px;margin:5px 0;font-size:11.5px}
.quick span{border:1px solid var(--gold);padding:1px 6px;background:var(--soft)}
.quick em{font-style:normal;color:var(--hot);font-weight:700;margin-left:3px}
.goal{font-size:12px;margin:3px 0}
.goal b{color:var(--hot);margin-right:6px}
.line{height:1px;background:var(--gold);margin:8px 0 7px;position:relative}
.line::before,.line::after{content:"◆";position:absolute;top:-7px;font-size:8px;color:var(--gold)}
.line::after{right:0}
.opts{margin-top:2px}
.opt{display:flex;gap:7px;align-items:flex-start;width:100%;text-align:left;font:inherit;font-size:13px;line-height:1.4;color:var(--ink);background:var(--soft);border:1px solid var(--gold);padding:6px 9px;margin:0 0 6px;cursor:pointer;box-shadow:0 3px 0 var(--drop);clip-path:polygon(0 0,calc(100% - 8px) 0,100% 8px,100% 100%,6px 100%,0 calc(100% - 6px));transition:transform .08s,box-shadow .08s;-webkit-tap-highlight-color:transparent;touch-action:manipulation}
.opt:active,.opt.press{transform:translateY(2px);box-shadow:0 1px 0 var(--drop);border-color:var(--hot)}
.opt .k{background:var(--main);color:var(--bg);font-size:10px;width:16px;height:16px;display:grid;place-items:center;flex:none;font-family:Georgia,serif;margin-top:1px}
.C .opt{clip-path:none;box-shadow:none;font-family:inherit;font-size:12px;padding:5px 8px;margin:4px 0 0;color:var(--ink);border-color:var(--gold)}
.C .opt:active,.C .opt.press{transform:none;background:#1E3A24;border-color:var(--ink)}
.C .p{white-space:pre-wrap}
.C .p.w{color:var(--warn)}.C .p.r{color:var(--hot)}.C .p.dim{color:var(--mute)}
.rec{text-align:right;color:var(--mute);font-size:10px;margin-top:6px}
.loc-en{font-family:Georgia,serif;font-size:9px;letter-spacing:3px;color:var(--mute)}
.loc-name{font-size:16px;font-weight:700;letter-spacing:2px;color:var(--main)}
.loc-desc{font-size:12.5px;margin:4px 0 8px;opacity:.92}
.scene{margin:-10px -12px 8px;padding:16px 12px 10px;background:radial-gradient(ellipse at 70% 0%,#D9B87833,transparent 60%),linear-gradient(180deg,#3A2519,#221510)}
.A .scene{background:radial-gradient(ellipse at 70% 0%,#FFF8E655,transparent 60%),linear-gradient(180deg,#D8C7A4,#E8DCC3)}
.C .scene{background:radial-gradient(ellipse at 70% 0%,#4ADE8022,transparent 60%),linear-gradient(180deg,#102016,#0A0F0A)}
.nodes{display:flex;flex-wrap:wrap;gap:6px}
.node{font:inherit;font-size:12.5px;color:var(--ink);background:var(--soft);border:1px solid var(--gold);padding:4px 10px 4px 8px;display:flex;align-items:center;gap:6px;box-shadow:0 3px 0 var(--drop);-webkit-tap-highlight-color:transparent;touch-action:manipulation}
button.node{cursor:pointer}
button.node:active,button.node.press{transform:translateY(2px);box-shadow:0 1px 0 var(--drop)}
.node i{width:8px;height:8px;flex:none;transform:rotate(45deg);background:var(--main)}
.node.dg{border-color:var(--bad)}.node.dg i{background:var(--bad)}
.prog{font-size:11px;color:var(--mute);margin-top:8px;font-family:Georgia,serif}
.alert{font-size:12px;color:var(--bad);margin-top:5px}
.grid{display:grid;grid-template-columns:1fr 1fr;gap:6px}
.tile{position:relative;border:1px solid var(--gold);background:var(--soft);padding:6px 8px;box-shadow:2px 2px 0 var(--drop);min-height:46px}
.tile .nm{font-weight:700;display:block;font-size:13px;padding-right:40px}
.tile .q{font-family:Georgia,serif;font-size:11px;color:var(--mute);margin-left:4px;font-weight:400}
.tile .ds{display:block;font-size:11px;color:var(--mute);line-height:1.4}
.tile .tag{position:absolute;top:-1px;right:-1px;font-size:10px;font-weight:700;padding:0 5px;background:var(--hot);color:var(--bg)}
.tile .tag.clue{background:var(--main)}
.tile.new{border-color:var(--hot);border-width:1.5px}
.foot{font-size:11.5px;color:var(--mute);margin-top:7px;border-top:1px solid var(--gold);padding-top:5px}
.who{display:flex;gap:10px}
.face{width:82px;height:104px;flex:none;display:grid;place-items:center;border:1px solid var(--gold);outline:3px double var(--gold);outline-offset:-7px;background:radial-gradient(circle at 50% 35%,#FFF8E6aa,transparent 65%),var(--soft);font-size:30px;font-weight:700;color:var(--main)}
.B .face,.C .face{background:radial-gradient(circle at 50% 35%,#FFFFFF22,transparent 65%),var(--soft)}
.info{flex:1;min-width:0;display:flex;flex-direction:column;gap:4px}
.info .nm{font-size:16px;font-weight:700;letter-spacing:1px}
.info .id{font-size:12px;color:var(--mute)}
.chips{display:flex;flex-wrap:wrap;gap:4px}
.chips span{font-size:11px;border:1px solid var(--gold);padding:0 6px}
.info .rl{margin-top:2px;font-size:11.5px;color:var(--mute)}
.info .rl b{color:var(--main);font-family:Georgia,serif}
.tl{margin-top:6px;font-size:11.5px;color:var(--mute)}
.tl div::before{content:"· ";color:var(--gold)}
.done{font-size:12.5px;padding:8px 10px;border:1px dashed var(--gold);background:var(--bg);color:var(--ink)}
.done .s{display:block;font-size:11px;color:var(--mute);margin-top:3px}
.done .s.bad{color:var(--bad)}
.recover{display:none;margin-top:6px;gap:6px;flex-wrap:wrap}
.recover.on{display:flex}
.recover button{font:inherit;font-size:12px;color:var(--ink);background:var(--soft);border:1px solid var(--hot);padding:3px 10px;cursor:pointer}
.recover textarea{flex-basis:100%;font:inherit;font-size:12px;color:var(--ink);background:var(--soft);border:1px solid var(--gold);padding:5px;min-height:40px}
.loading{color:#8A7356;padding:14px;text-align:center}
.strip{display:flex;flex-wrap:wrap;gap:4px 10px;font-size:11.5px;color:var(--mute);margin:0 0 6px}
.strip span b{color:var(--ink);font-weight:700}
.strip .chg b{color:var(--hot)}
.cine{margin:-10px -12px 8px;padding:9px 12px 8px;text-align:center;border-bottom:1px solid var(--gold);background:linear-gradient(90deg,transparent,#B8924F22,transparent)}
.cine .l{font-size:15px;font-weight:700;letter-spacing:4px;color:var(--main)}
.cine .t{font-size:10px;letter-spacing:2px;color:var(--mute);font-family:Georgia,serif}
.B .cine .l{color:#D9B878;text-shadow:0 0 12px #D9B87855}
.C .cine{background:linear-gradient(90deg,transparent,#4ADE8018,transparent)}
.C .cine .l{color:var(--ink);text-shadow:0 0 10px #4ADE8055}
.dlg{font-size:12.5px;line-height:1.55;margin:0 0 8px;padding:6px 9px;background:var(--soft);border-left:2px solid var(--gold)}
.dlg div{margin:1px 0}
.dlg .spk{font-weight:700;color:var(--main);margin-right:2px}
.dlg .hd{font-weight:700;letter-spacing:1px;color:var(--hot)}
.C .dlg{background:#0F1A10;border-left-color:var(--ink)}
.ic{margin-right:2px}
.hint{font-size:11px;color:var(--mute);margin-top:7px;padding-top:5px;border-top:1px dashed var(--gold)}
/* ===== 皮肤 D 霓虹街区（赛博朋克） ===== */
.D{--bg:#0B0A1F;--ink:#E0E7FF;--main:#22D3EE;--hot:#FF2E88;--gold:#A855F7;--soft:#15133A;--mute:#8B8FC7;--drop:#05041A;--good:#22D3EE;--bad:#FF2E88;--warn:#FACC15}
.card.D,.done.D,.card.E,.done.E{font-family:"PingFang SC","Microsoft YaHei","Noto Sans SC",sans-serif}
.card.D{margin:4px;border:1px solid var(--main);box-shadow:0 0 0 1px #FF2E8844,0 0 18px #22D3EE40,inset 0 0 26px #A855F722;background:linear-gradient(#22D3EE0C 1px,transparent 1px) 0 0/100% 16px,linear-gradient(90deg,#22D3EE0C 1px,transparent 1px) 0 0/16px 100%,var(--bg)}
.card.D::before{content:"";position:absolute;top:-1px;left:-1px;width:18px;height:18px;border-top:2px solid var(--hot);border-left:2px solid var(--hot);pointer-events:none}
.card.D::after{content:"";position:absolute;bottom:-1px;right:-1px;width:18px;height:18px;border-bottom:2px solid var(--main);border-right:2px solid var(--main);pointer-events:none}
.D .head .t{font-family:GNeon,"PingFang SC",sans-serif;letter-spacing:1.5px;text-shadow:-1px 0 #FF2E88,1px 0 #22D3EE}
.D .head .star{color:var(--hot);text-shadow:0 0 6px var(--hot)}
.D .head .en,.D .loc-en,.D .cine .t{font-family:GNeon,sans-serif;font-size:9px;letter-spacing:3px;color:var(--hot)}
.D .head .r,.D .top,.D .prog{font-family:GTerm,monospace;font-size:14px}
.D .top b,.D .bar .v,.D .tile .q,.D .info .rl b{font-family:GTerm,monospace;font-size:16px;color:var(--main);text-shadow:0 0 6px #22D3EE88}
.D .bar .t{height:5px;background:#15133A;border-color:#2A2760}
.D .bar .t i{background:linear-gradient(90deg,#22D3EE,#A855F7,#FF2E88);box-shadow:0 0 6px #22D3EE88}
.D .bar .t i.low{background:var(--hot);box-shadow:0 0 6px var(--hot)}
.D .line{background:linear-gradient(90deg,transparent,var(--hot),var(--main),transparent)}
.D .line::before,.D .line::after{color:var(--main)}
.D .opt{background:#15133AEE;border-color:#2A2760;box-shadow:none;border-left:2px solid var(--main)}
.D .opt .k{background:var(--hot);color:#fff;font-family:GNeon,sans-serif;box-shadow:0 0 6px var(--hot)}
.D .opt:active,.D .opt.press{transform:translateX(3px);box-shadow:0 0 14px #22D3EE66;border-color:var(--main)}
.D .die{transform:none;border-color:var(--main);background:#15133A;font-family:GTerm,monospace;font-size:19px;box-shadow:0 0 8px #22D3EE66}
.D .stamp{transform:none;box-shadow:0 0 8px currentColor}
.D .news{color:var(--hot)}
.D .quick span,.D .tile,.D .node{background:#15133A;border-color:#2A2760;box-shadow:none}
.D .tile.new{border-color:var(--hot);box-shadow:0 0 10px #FF2E8855}
.D .node{border-color:var(--main)}.D .node i{background:var(--main);box-shadow:0 0 5px var(--main)}
.D .scene{background:radial-gradient(ellipse at 85% 0%,#FF2E8838,transparent 60%),linear-gradient(180deg,#1A1145,#0B0A1F);border-bottom:1px solid var(--hot)}
.D .loc-name{font-family:GNeon,"PingFang SC",sans-serif;color:#fff;text-shadow:0 0 8px #22D3EE,2px 0 #FF2E88}
.D .cine{background:linear-gradient(90deg,transparent,#FF2E8826,transparent);border-bottom-color:var(--hot)}
.D .cine .l{color:#fff;text-shadow:0 0 10px var(--hot),-2px 0 var(--hot),2px 0 var(--main)}
.D .dlg{background:#15133A;border-left-color:var(--hot)}
.D .dlg .hd{color:var(--main)}
.D .face{background:radial-gradient(circle at 50% 35%,#22D3EE33,transparent 65%),#15133A;outline-color:var(--hot);color:var(--main);font-family:GNeon,sans-serif;text-shadow:0 0 10px var(--main)}
.D .chips span{border-color:var(--gold)}
.D .hint,.D .foot{border-top-color:#2A2760}
.done.D{border-color:var(--hot);box-shadow:0 0 10px #FF2E8840}
/* ===== 皮肤 E 像素冒险海报（8-bit 复古） ===== */
.E{--bg:#F4E4C1;--ink:#2B1B17;--main:#3A6EA5;--hot:#B5302A;--gold:#2B1B17;--soft:#FFF4DA;--mute:#7A5C45;--drop:#2B1B17;--good:#3E8E41;--bad:#B5302A;--warn:#F2B33D}
.card.E{margin:2px 6px 6px 2px;padding:14px 12px 10px;border:3px solid var(--ink);box-shadow:4px 4px 0 var(--ink)}
.card.E::before{content:"";position:absolute;left:0;right:0;top:0;height:5px;background:repeating-linear-gradient(90deg,var(--hot) 0 10px,var(--warn) 10px 20px);border-bottom:2px solid var(--ink);pointer-events:none}
.E .head .t{font-weight:800;letter-spacing:1px;text-shadow:2px 2px 0 #E3CFA4}
.E .head .star{color:var(--hot)}
.E .head .en,.E .loc-en,.E .cine .t{font-family:GPixel,monospace;font-size:7px;letter-spacing:1px;color:var(--hot)}
.E .head .r,.E .top,.E .prog{font-family:GPixel,"PingFang SC",monospace;font-size:8px;line-height:1.9}
.E .top b,.E .bar .v,.E .tile .q,.E .info .rl b{font-family:GPixel,monospace;font-size:9px;color:var(--main)}
.E .bar .n{font-weight:700}
.E .bar .t{height:11px;background:#E3CFA4;border:2px solid var(--ink)}
.E .bar .t i{background:repeating-linear-gradient(90deg,var(--good) 0 6px,#2E6B30 6px 8px)}
.E .bar .t i.low{background:repeating-linear-gradient(90deg,var(--bad) 0 6px,#7A1F1A 6px 8px)}
.E .line{height:0;background:none;border-top:3px dotted var(--ink)}
.E .line::before,.E .line::after{content:"■";top:-9px;font-size:9px;color:var(--hot)}
.E .opt{clip-path:none;background:var(--ink);color:#FFF4DA;border:2px solid #FFF4DA;outline:2px solid var(--ink);box-shadow:3px 3px 0 #2B1B1799;margin:2px 2px 8px}
.E .opt .k{display:block;white-space:nowrap;background:none;color:var(--warn);font-family:GPixel,monospace;font-size:9px;width:auto;height:auto;margin-top:4px}
.E .info .en{font-family:GPixel,monospace!important;font-size:7px!important;color:var(--hot)!important}
.D .info .en{font-family:GNeon,sans-serif!important;font-size:9px!important;color:var(--hot)!important}
.E .opt .k::before{content:"▶ "}
.E .opt:active,.E .opt.press{transform:translate(2px,2px);box-shadow:1px 1px 0 #2B1B1799;border-color:var(--warn)}
.E .die{transform:none;border:2px solid var(--ink);background:var(--soft);color:var(--hot);font-family:GPixel,monospace;font-size:10px;box-shadow:2px 2px 0 var(--ink)}
.E .stamp{transform:none;border-width:2px;font-weight:800}
.E .quick span{border:2px solid var(--ink);box-shadow:2px 2px 0 var(--ink)}
.E .tile{border:2px solid var(--ink);box-shadow:3px 3px 0 var(--ink)}
.E .tile.new{border-color:var(--hot)}
.E .tile .tag{border-left:2px solid var(--ink);border-bottom:2px solid var(--ink)}
.E .node{border:2px solid var(--ink);box-shadow:2px 2px 0 var(--ink)}
.E .node i{transform:none;border-radius:0}
.E .scene{margin:-14px -12px 8px;padding:18px 12px 10px;background:linear-gradient(180deg,#5DA9E9 0 70%,#8FCB6A 70%);border-bottom:3px solid var(--ink)}
.E .loc-en{color:#FFF4DA}
.E .loc-name{color:#fff;text-shadow:2px 2px 0 var(--ink),-1px -1px 0 var(--ink)}
.E .loc-desc{color:var(--ink);background:#FFF4DAE6;border:2px solid var(--ink);padding:3px 6px;margin-bottom:2px}
.E .cine{margin:-14px -12px 8px;padding:14px 12px 7px;background:var(--hot);border-bottom:3px solid var(--ink)}
.E .cine .l{color:#fff;text-shadow:2px 2px 0 var(--ink)}
.E .cine .t{color:#FFF4DA}
.E .dlg{position:relative;background:#1C1430;color:#FFF4DA;border:3px solid #FFF4DA;outline:3px solid var(--ink);margin:3px 3px 10px;padding:6px 9px 12px}
.E .dlg .spk{color:var(--warn)}
.E .dlg .hd{color:var(--warn)}
.E .dlg::after{content:"▼";position:absolute;right:7px;bottom:1px;font-size:9px;color:var(--warn);animation:bob .8s steps(2) infinite}
@keyframes bob{50%{transform:translateY(-3px)}}
.E .face{border:3px solid var(--ink);outline:none;background:repeating-linear-gradient(0deg,#FFF4DA 0 6px,#F4E4C1 6px 12px);color:var(--hot);font-size:34px;text-shadow:3px 3px 0 var(--ink)}
.E .chips span{border:2px solid var(--ink)}
.E .hint,.E .foot{border-top:2px dashed var(--ink)}
.done.E{border:3px dashed var(--ink);font-weight:700}
</style></head>
<body><main id="app"><p class="loading">正在载入游戏界面…</p></main>
<script>
(function(){
  var root = document.getElementById('app');
  var pending = {}, seq = 0, mode = 'standard', caps, ready = false, current = null, audio = null, sentText = null;

  function esc(v){ return String(v == null ? '' : v).replace(/[&<>"']/g, function(c){ return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]; }); }
  function fmt(v){ return typeof v === 'number' && !Number.isInteger(v) ? String(Math.round(v * 10) / 10) : String(v); }
  function has(list, x){ return Array.isArray(list) && list.indexOf(x) >= 0; }
  function list(v){ return Array.isArray(v) ? v : []; }
  function delta(d){ return typeof d === 'number' && d ? '<span class="d ' + (d > 0 ? 'up' : 'down') + '">' + (d > 0 ? '+' : '') + fmt(d) + '</span>' : ''; }
  var VITAL = /生命|hp|血|理智|san|体力|精力|电量|饱食|水分|体面|耐久|氧气/i;
  function isNum(s){ return s.value !== null && s.value !== undefined; }

  function tone(res){ return /大成功|极难成功|critical/i.test(res) ? 'ok' : /成功|通过|success/i.test(res) ? 'ok' : /失败|fail/i.test(res) ? 'bad' : 'mid'; }
  function judge(v){
    var j = v['判定']; if (!j) return '';
    return '<div class="judge"><span class="die">' + esc(j.roll) + '</span><span>' + esc(j.name) + '判定' + (j.target !== '' && j.target != null ? ' · 目标 ' + esc(j.target) : '') +
      '</span><span class="stamp ' + tone(j.result || '') + '">' + esc(j.result || '?') + '</span></div>';
  }
  function news(ch, onlyGains){
    var moods = list(ch.moodChanged);
    var s = list(ch.summary).filter(function(t){
      t = String(t);
      if (t.indexOf('来到：') === 0) return false;
      if (moods.some(function(k){ return t.indexOf(k + '：') === 0; })) return false;
      return !onlyGains || t.indexOf('：') >= 0;
    });
    return s.length && !ch.first ? '<div class="news">' + s.map(esc).join(' · ') + '</div>' : '';
  }
  function lab(s){ return (s.icon ? '<span class="ic">' + esc(s.icon) + '</span>' : '') + esc(s.label); }
  function isDialogue(t){ return /\n/.test(t) || /^[【\[]/.test(t) || /^[^\n：:]{1,10}[：:]/.test(t); }
  function dialogue(t){
    return '<div class="dlg">' + String(t).split(/\n/).filter(function(x){ return x.trim(); }).slice(0, 8).map(function(line){
      var h = line.match(/^\s*[【\[](.{1,16})[】\]]\s*$/);
      if (h) return '<div class="hd">' + esc(h[1]) + '</div>';
      var m = line.match(/^\s*([^：:]{1,10})[：:]\s*(.*)$/);
      return m ? '<div><span class="spk">' + esc(m[1]) + '：</span>' + esc(m[2]) + '</div>' : '<div>' + esc(line) + '</div>';
    }).join('') + '</div>';
  }
  function events(v){ return list(v['事件']).slice(0, 2).map(function(t){ return isDialogue(t) ? dialogue(t) : '<div class="ev">' + esc(t) + '</div>'; }).join(''); }
  function strip(v, ch, withPlace){
    var parts = [];
    if (withPlace && v['地点']) parts.push('<span>📍 <b>' + esc(v['地点'].name) + '</b></span>');
    list(v['时间']).filter(function(c){ return c.label !== '回合'; }).forEach(function(c){ parts.push('<span>' + esc(c.label) + ' <b>' + esc(c.text) + '</b></span>'); });
    list(v['氛围']).forEach(function(m){ var k = m.label || m.icon; parts.push('<span class="' + (has(ch.moodChanged, k) ? 'chg' : '') + '">' + (m.icon ? esc(m.icon) + ' ' : '') + (m.label ? esc(m.label) + ' ' : '') + '<b>' + esc(m.text) + '</b></span>'); });
    return parts.length ? '<div class="strip">' + parts.join('') + '</div>' : '';
  }
  function cine(v, ch){
    if (ch.first || !v['地点'] || !has(ch.sections, '地点')) return '';
    var t = list(v['时间']).filter(function(c){ return c.label !== '回合'; }).map(function(c){ return esc(c.text); }).join(' · ');
    return '<div class="cine"><div class="l">' + esc(v['地点'].name) + '</div>' + (t ? '<div class="t">' + t + '</div>' : '<div class="t">SCENE CHANGE</div>') + '</div>';
  }
  function turnText(v){
    var c = list(v['时间']), r = c.filter(function(x){ return x.label === '回合'; });
    return r.length ? '第 ' + esc(r[0].text) + ' 回合' : c.map(function(x){ return esc(x.text); }).join(' · ');
  }

  function statusBlock(v, ch, withTimeline){
    var stats = list(v['数值']);
    var bars = stats.filter(function(s){ return isNum(s) && s.max; }).slice(0, 4);
    var plain = stats.filter(function(s){ return bars.indexOf(s) < 0; }).slice(0, 5);
    var rt = list(v['时间']).filter(function(x){ return x.label === '回合'; })[0];
    var html = '<div class="top"><span>' + (rt ? '第 ' + esc(rt.text) + ' 回合' : '') + '</span><span>' + plain.map(function(s){
      return lab(s) + ' <b>' + (isNum(s) ? fmt(s.value) : esc(s.text)) + '</b>' + delta(ch.statDelta[s.label]);
    }).join(' · ') + '</span></div>';
    html += bars.map(function(s){
      var pct = Math.max(0, Math.min(100, s.value / s.max * 100));
      return '<div class="bar"><span class="n">' + lab(s) + '</span><span class="t"><i class="' + (pct <= 25 && VITAL.test(s.label) ? 'low' : '') + '" style="width:' + Math.round(pct) + '%"></i></span><span class="v">' + fmt(s.value) + '/' + fmt(s.max) + delta(ch.statDelta[s.label]) + '</span></div>';
    }).join('');
    var items = list(v['道具']).slice().sort(function(a, b){ return has(ch.newItems, b.name) - has(ch.newItems, a.name); }).slice(0, 4);
    if (items.length) html += '<div class="quick">' + items.map(function(it){ return '<span>' + esc(it.name) + (it.qty != null && it.qty !== 1 ? ' ×' + fmt(it.qty) : '') + (has(ch.newItems, it.name) ? '<em>新</em>' : '') + '</span>'; }).join('') + '</div>';
    var goal = list(v['任务']).filter(function(q){ return !q.done; })[0];
    if (goal) html += '<div class="goal"><b>目标</b>' + esc(goal.name) + '</div>';
    if (withTimeline) {
      var tl = list(v['事件']).concat(list(ch.summary).filter(function(t){ return String(t).indexOf('：') >= 0; })).slice(0, 3);
      if (tl.length) html += '<div class="tl">' + tl.map(function(t){ return '<div>' + esc(t) + '</div>'; }).join('') + '</div>';
    }
    return html;
  }

  function optionButtons(v, terminal){
    return '<div class="opts">' + list(v['选项']).map(function(o, i){
      var k = 'ABCDEF'.charAt(i);
      return terminal
        ? '<button type="button" class="opt" data-say="' + esc(o.text) + '">&gt; ' + k + ' ' + esc(o.text) + '</button>'
        : '<button type="button" class="opt" data-say="' + esc(o.text) + '"><span class="k">' + k + '</span><span>' + esc(o.text) + '</span></button>';
    }).join('') + '</div>';
  }

  function choiceCard(v, ch, card){
    if (card.variant === 'terminal') {
      var lines = [];
      var j = v['判定'];
      if (j) lines.push('<div class="p ' + (tone(j.result || '') === 'bad' ? 'r' : '') + '">&gt; ' + esc(j.name) + '判定 ' + esc(j.roll) + (j.target !== '' && j.target != null ? ' / ' + esc(j.target) : '') + ' [' + (tone(j.result || '') === 'bad' ? 'FAIL' : tone(j.result || '') === 'ok' ? 'OK' : '??') + '] ' + esc(j.result || '') + '</div>');
      if (!ch.first && v['地点'] && has(ch.sections, '地点')) lines.unshift('<div class="p">&gt; [场景切换] ' + esc(v['地点'].name) + '</div>');
      else if (v['地点']) lines.push('<div class="p dim">&gt; 📍 ' + esc(v['地点'].name) + list(v['氛围']).map(function(m){ return ' · ' + (m.icon ? esc(m.icon) + ' ' : '') + (m.label ? esc(m.label) + ' ' : '') + esc(m.text); }).join('') + '</div>');
      var stats = list(v['数值']).slice(0, 6).map(function(s){ return (s.icon ? esc(s.icon) + ' ' : '') + esc(s.label) + ' ' + (isNum(s) ? fmt(s.value) + (s.max ? '/' + fmt(s.max) : '') : esc(s.text)) + (typeof ch.statDelta[s.label] === 'number' ? '(' + (ch.statDelta[s.label] > 0 ? '+' : '') + fmt(ch.statDelta[s.label]) + ')' : ''); });
      if (stats.length) lines.push('<div class="p dim">&gt; ' + stats.join(' · ') + '</div>');
      var gains = list(ch.summary).filter(function(t){ t = String(t); return t.indexOf('：') >= 0 && t.indexOf('来到：') !== 0 && !list(ch.moodChanged).some(function(k){ return t.indexOf(k + '：') === 0; }); });
      if (gains.length && !ch.first) lines.push('<div class="p">&gt; ' + gains.map(esc).join(' · ') + '</div>');
      list(v['事件']).slice(0, 2).forEach(function(t){
        if (isDialogue(t)) { lines.push(dialogue(t)); return; }
        var warn = /^[!！]|警告|危险|警报|异常/.test(t);
        lines.push('<div class="p' + (warn ? ' w' : '') + '">&gt; ' + (warn ? '[!!] ' : '') + esc(t.replace(/^[!！]\s*/, '')) + '</div>');
      });
      return '<div class="card C"><div class="head"><span class="t">&gt;_ ' + esc(v['标题'] || '终端') + '</span><span class="r">' + turnText(v) + '</span></div>' + lines.join('') + optionButtons(v, true) + '<div class="rec">REC ' + recTime() + '</div></div>';
    }
    var body = '';
    if (card.variant === 'with-status') body += cine(v, ch) + strip(v, ch, !cine(v, ch)) + statusBlock(v, ch, false) + '<div class="line"></div>' + judge(v) + news(ch, true) + events(v);
    else body += cine(v, ch) + '<div class="head"><span class="star">✦</span><span class="t">你打算</span><span class="en">CHOICE</span><span class="r">' + turnText(v) + '</span></div>' + strip(v, ch, !cine(v, ch)) + judge(v) + news(ch, false) + events(v);
    return '<div class="card ' + card.skin + '">' + body + optionButtons(v, false) + '</div>';
  }

  function mapCard(v, ch, card){
    var l = v['地点'];
    var nodes = list(l.points).map(function(p){
      var say = p.danger ? '小心地靠近' + p.name : '去查看' + p.name;
      return '<button type="button" class="node' + (p.danger ? ' dg' : '') + '" data-say="' + esc(say) + '"><i></i>' + esc(p.name) + '</button>';
    }).join('');
    return '<div class="card ' + card.skin + '"><div class="scene"><div class="loc-en">LOCATION' + (v['时间'] && v['时间'][0] ? ' · ' + esc(v['时间'][0].text) : '') + '</div><div class="loc-name">' + esc(l.name) + '</div>' +
      (l.desc ? '<p class="loc-desc">' + esc(l.desc) + '</p>' : '') + '</div>' + judge(v) + news(ch, false) +
      '<div class="nodes">' + nodes + '</div>' + (l.alert ? '<div class="alert">' + esc(l.alert) + '</div>' : '') +
      '<div class="prog">' + (l.progress ? '探索度 ' + esc(l.progress) + ' · ' : '') + '点一个地点就出发 · 红色有危险</div></div>';
  }

  function locationCard(v, ch, card){
    var l = v['地点'];
    var pts = list(l.points).slice(0, 4).map(function(p){ return '<span class="node' + (p.danger ? ' dg' : '') + '"><i></i>' + esc(p.name) + '</span>'; }).join('');
    return '<div class="card ' + card.skin + '"><div class="scene"><div class="loc-en">LOCATION</div><div class="loc-name">' + esc(l.name) + '</div>' +
      (l.desc ? '<p class="loc-desc">' + esc(l.desc) + '</p>' : '') + '</div>' + judge(v) + news(ch, false) +
      (pts ? '<div class="nodes">' + pts + '</div>' : '') + (l.alert ? '<div class="alert">' + esc(l.alert) + '</div>' : '') +
      (l.progress ? '<div class="prog">探索度 ' + esc(l.progress) + '</div>' : '') + '</div>';
  }

  function itemsCard(v, ch, card){
    var tiles = list(v['道具']).map(function(it){
      var n = has(ch.newItems, it.name);
      return '<div class="tile' + (n ? ' new' : '') + '">' + (n ? '<span class="tag">新</span>' : '') + '<span class="nm">' + esc(it.name) + (it.qty != null && it.qty !== 1 ? '<span class="q">×' + fmt(it.qty) + '</span>' : '') + '</span>' + (it.desc ? '<span class="ds">' + esc(it.desc) + '</span>' : '') + '</div>';
    }).concat(list(v['线索']).map(function(c){
      var n = has(ch.newClues, c.name);
      return '<div class="tile' + (n ? ' new' : '') + '"><span class="tag clue">' + (n ? '新线索' : '线索') + '</span><span class="nm">' + esc(c.name) + '</span>' + (c.desc ? '<span class="ds">' + esc(c.desc) + '</span>' : '') + '</div>';
    })).join('');
    var gains = list(ch.summary).filter(function(t){ return /^(获得|新线索)/.test(String(t)); });
    return '<div class="card ' + card.skin + '"><div class="head"><span class="star">✦</span><span class="t">背包</span><span class="en">INVENTORY</span><span class="r">' + (list(v['道具']).length + list(v['线索']).length) + ' 件</span></div>' +
      '<div class="grid">' + tiles + '</div>' + (gains.length && !ch.first ? '<div class="foot">' + gains.map(esc).join(' · ') + '</div>' : '') + '</div>';
  }

  function characterCard(v, ch, card){
    var people = list(v['人物']);
    var p = people.filter(function(x){ return has(ch.newPeople, x.name); })[0] || people[0];
    var rels = list(v['关系']).filter(function(r){ return r.label === p.name; });
    var rel = p.rel !== null && p.rel !== undefined && p.rel !== '' ? esc(p.relLabel || '关系') + ' <b>' + esc(p.rel) + '</b>' : rels.map(function(r){ return '关系 <b>' + (isNum(r) ? fmt(r.value) : esc(r.text)) + '</b>' + delta(ch.statDelta['关系:' + r.label]); }).join('');
    var others = people.filter(function(x){ return x !== p; }).map(function(x){ return esc(x.name); });
    return '<div class="card ' + card.skin + '"><div class="who"><div class="face">' + esc(String(p.name).slice(0, 1)) + '</div><div class="info">' +
      '<span class="en" style="font-family:Georgia,serif;font-size:10px;letter-spacing:2px;color:var(--mute)">' + (has(ch.newPeople, p.name) ? 'NEW · ' : '') + 'CHARACTER</span>' +
      '<span class="nm">' + esc(p.name) + '</span>' + (p.desc ? '<span class="id">' + esc(p.desc) + '</span>' : '') +
      (others.length ? '<div class="chips">' + others.slice(0, 3).map(function(o){ return '<span>同场 ' + o + '</span>'; }).join('') + '</div>' : '') +
      (rel ? '<span class="rl">' + rel + '</span>' : '') + '</div></div></div>';
  }

  function statusCard(v, ch, card){
    var star = { C: '&gt;_', D: '◢', E: '★' }[card.skin] || '✦';
    var hasDlg = list(v['事件']).some(isDialogue);
    return '<div class="card ' + card.skin + '">' + cine(v, ch) + '<div class="head"><span class="star">' + star + '</span><span class="t">' + esc(v['标题'] || '状态') + '</span><span class="en">STATUS</span></div>' +
      strip(v, ch, !cine(v, ch)) + judge(v) + (hasDlg ? events(v) : '') + news(ch, false) + statusBlock(v, ch, !hasDlg) +
      (list(v['选项']).length ? '' : '<div class="hint">直接在聊天里说你想做什么</div>') + '</div>';
  }

  function recTime(){ var t = (current && current.turnIndex) || 1; var m = t * 3 + 2; return '00:' + (m < 10 ? '0' : '') + m + ':' + (17 + t * 7) % 60; }

  function render(sc){
    var v = sc.view || {}, ch = sc.changes || {}, card = sc.card || { type: 'status', skin: 'A' };
    ch.statDelta = ch.statDelta || {}; ch.sections = ch.sections || [];
    current = sc; sentText = null;
    var html;
    if (card.type === 'choice' && list(v['选项']).length) html = choiceCard(v, ch, card);
    else if (card.type === 'map' && v['地点']) html = mapCard(v, ch, card);
    else if (card.type === 'location' && v['地点']) html = locationCard(v, ch, card);
    else if (card.type === 'items') html = itemsCard(v, ch, card);
    else if (card.type === 'character' && list(v['人物']).length) html = characterCard(v, ch, card);
    else html = statusCard(v, ch, card);
    root.className = /^[A-E]$/.test(card.skin) ? card.skin : 'A';
    root.innerHTML = html;
    wire();
    armSound(cardSound(v, ch, card));
    size();
  }

  // ===== 音效：全部现场合成。手机需要先碰一下卡片才能出声（浏览器规定），静音模式下不响。 =====
  var WAVE = { A: 'triangle', B: 'sine', C: 'square', D: 'sawtooth', E: 'square' };
  function ac(){
    try {
      audio = audio || new (window.AudioContext || window.webkitAudioContext)();
      if (audio.state === 'suspended') audio.resume();
      return audio;
    } catch (e) { return null; }
  }
  function beep(f1, f2, d, at, vol, wave){
    var a = ac(); if (!a) return;
    var o = a.createOscillator(), g = a.createGain(), t = a.currentTime + (at || 0);
    o.type = wave || WAVE[root.className] || 'square';
    o.frequency.setValueAtTime(f1, t); o.frequency.exponentialRampToValueAtTime(f2, t + d);
    g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(vol || .05, t + .008); g.gain.exponentialRampToValueAtTime(.0001, t + d);
    o.connect(g); g.connect(a.destination); o.start(t); o.stop(t + d + .02);
  }
  function hiss(d, at, vol, freq){
    var a = ac(); if (!a) return;
    var n = Math.floor(a.sampleRate * d), buf = a.createBuffer(1, n, a.sampleRate), x = buf.getChannelData(0);
    for (var i = 0; i < n; i++) x[i] = (Math.random() * 2 - 1) * (1 - i / n);
    var src = a.createBufferSource(), f = a.createBiquadFilter(), g = a.createGain(), t = a.currentTime + (at || 0);
    src.buffer = buf; f.type = 'bandpass'; f.frequency.value = freq || 2400; f.Q.value = .8; g.gain.value = vol || .08;
    src.connect(f); f.connect(g); g.connect(a.destination); src.start(t);
  }
  var SFX = {
    tap: function(){ beep(520, 830, .07); },
    dice: function(){ for (var i = 0; i < 4; i++) hiss(.035, i * .07, .12, 1800 + i * 500); beep(700, 700, .05, .3, .04); },
    pickup: function(){ beep(660, 660, .06, 0, .05); beep(990, 1320, .12, .07, .05); },
    ok: function(){ beep(523, 523, .08, 0); beep(659, 659, .08, .09); beep(784, 1046, .18, .18); },
    bad: function(){ beep(320, 140, .32, 0, .06); beep(300, 120, .32, .05, .03, 'sine'); },
    scene: function(){ hiss(.45, 0, .07, 900); beep(220, 440, .4, .05, .035, 'sine'); },
    blip: function(){ beep(880, 880, .05, 0, .035); }
  };
  function play(name){ try { if (SFX[name]) SFX[name](); } catch (e) {} }
  function cardSound(v, ch, card){
    var j = v['判定'];
    if (j && has(ch.sections, '判定')) return ['dice', tone(j.result || '') === 'bad' ? 'bad' : 'ok'];
    if (!ch.first && v['地点'] && has(ch.sections, '地点')) return ['scene'];
    if (list(ch.newItems).length || list(ch.newClues).length) return ['pickup'];
    return ch.first ? ['blip'] : [];
  }
  // 本卡的事件音：能直接出声就马上放；不能就等玩家第一次碰到卡片时放一次。
  function armSound(seq){
    if (!seq.length) return;
    var done = false;
    function go(){ if (done) return; done = true; play(seq[0]); if (seq[1]) setTimeout(function(){ play(seq[1]); }, 380); }
    try { var A = window.AudioContext || window.webkitAudioContext; if (audio && audio.state === 'running') { go(); return; } if (A && !audio) { audio = new A(); if (audio.state === 'running') { go(); return; } } } catch (e) {}
    root.addEventListener('pointerdown', go, { once: true });
  }

  function wire(){
    [].slice.call(root.querySelectorAll('button[data-say]')).forEach(function(b){
      b.addEventListener('touchstart', function(){ b.classList.add('press'); }, { passive: true });
      b.addEventListener('touchend', function(){ b.classList.remove('press'); });
      b.addEventListener('click', function(){
        if (sentText) return;
        sentText = b.getAttribute('data-say');
        play('tap');
        destroyTo(sentText);
        deliver(sentText, 0);
      });
    });
  }

  // 选择卡点击后销毁，收成一行文字记录（总纲：点击后本卡销毁，转为纯文字记录）。
  function destroyTo(text){
    var skin = root.className || 'A';
    root.innerHTML = '<div class="done ' + skin + '">✦ 你选择了：' + esc(text) + '<span class="s" id="st">正在发送…</span>' +
      '<div class="recover" id="recover"><button type="button" id="retry">重新发送</button><button type="button" id="copy">复制这句话</button><textarea id="manual" readonly></textarea></div></div>';
    document.getElementById('retry').addEventListener('click', function(){ document.getElementById('recover').className = 'recover'; deliver(sentText, 0); });
    document.getElementById('copy').addEventListener('click', function(){
      var m = document.getElementById('manual'); m.value = sentText || '';
      try { navigator.clipboard.writeText(m.value).then(function(){ status('已复制，粘贴到聊天框发送即可'); }, function(){ m.select(); status('请长按上面的文字复制'); }); }
      catch (e) { m.select(); status('请长按上面的文字复制'); }
    });
    size();
  }
  function status(text, bad){ var s = document.getElementById('st'); if (s) { s.textContent = text; s.className = 's' + (bad ? ' bad' : ''); } size(); }

  function supports(name){ return caps === undefined || caps === null || caps[name] !== undefined; }

  function sendOnce(text){
    if (mode === 'compat' || (!ready && window.openai && typeof window.openai.sendFollowUpMessage === 'function')) {
      if (!window.openai || typeof window.openai.sendFollowUpMessage !== 'function') return Promise.reject(new Error('宿主不支持发送消息'));
      return Promise.resolve(window.openai.sendFollowUpMessage({ prompt: text }));
    }
    var ctx = supports('updateModelContext')
      ? rpc('ui/update-model-context', { content: [{ type: 'text', text: '玩家在游戏界面卡片上选择了：' + text }], structuredContent: { gameUiChoice: { text: text, turnIndex: current && current.turnIndex, at: new Date().toISOString() } } }, 6000).catch(function(){})
      : Promise.resolve();
    return ctx.then(function(){ return rpc('ui/message', { role: 'user', content: [{ type: 'text', text: text }] }, 15000); })
      .then(function(r){ if (r && r.isError) throw new Error('宿主拒绝了这条消息'); return r; });
  }

  function deliver(text, attempt){
    status(attempt ? '正在重试发送…' : '正在发送…');
    sendOnce(text).then(function(){
      status('已发送');
    }, function(err){
      if (attempt < 1) { setTimeout(function(){ deliver(text, attempt + 1); }, 900); return; }
      status('没发出去：' + (err && err.message ? err.message : '未知原因') + '。可以重试，或复制后自己发送', true);
      var r = document.getElementById('recover'), m = document.getElementById('manual');
      if (m) m.value = text;
      if (r) r.className = 'recover on';
      size();
    });
  }

  function rpc(method, params, timeout){
    return new Promise(function(resolve, reject){
      var id = ++seq;
      var timer = setTimeout(function(){ delete pending[id]; reject(new Error(method + ' 响应超时')); }, timeout || 15000);
      pending[id] = { resolve: resolve, reject: reject, timer: timer };
      window.parent.postMessage({ jsonrpc: '2.0', id: id, method: method, params: params }, '*');
    });
  }
  function notify(method, params){ window.parent.postMessage({ jsonrpc: '2.0', method: method, params: params }, '*'); }

  var lastH = 0;
  function size(){
    var h = Math.ceil(document.body.getBoundingClientRect().height);
    if (h === lastH) return;
    lastH = h;
    if (mode === 'standard' && ready) notify('ui/notifications/size-changed', { width: Math.ceil(document.documentElement.scrollWidth), height: h });
  }

  function apply(result){
    var sc = result && (result.structuredContent || result);
    if (!sc || sc.kind !== 'game-ui' || !sc.view) return false;
    render(sc);
    return true;
  }

  window.addEventListener('message', function(event){
    if (event.source !== window.parent) return;
    var m = event.data;
    if (!m || m.jsonrpc !== '2.0') return;
    if (m.id !== undefined && pending[m.id] && (m.result !== undefined || m.error)) {
      var p = pending[m.id]; delete pending[m.id]; clearTimeout(p.timer);
      if (m.error) p.reject(new Error(m.error.message || '宿主返回错误')); else p.resolve(m.result);
      return;
    }
    if (m.method === 'ui/notifications/tool-result') apply(m.params);
    else if (m.id !== undefined && (m.method === 'ping' || m.method === 'ui/resource-teardown')) window.parent.postMessage({ jsonrpc: '2.0', id: m.id, result: {} }, '*');
  });
  window.addEventListener('openai:set_globals', function(){ if (window.openai && window.openai.toolOutput) apply({ structuredContent: window.openai.toolOutput }); });
  if ('ResizeObserver' in window) new ResizeObserver(size).observe(document.body);

  if (window.openai && window.openai.toolOutput) apply({ structuredContent: window.openai.toolOutput });
  rpc('ui/initialize', { appInfo: { name: 'b-game-ui', version: '0.8.0' }, appCapabilities: { availableDisplayModes: ['inline'] }, protocolVersion: '2026-01-26' }, 6500)
    .then(function(r){
      caps = r && r.hostCapabilities;
      ready = true;
      notify('ui/notifications/initialized', {});
      lastH = 0; size();
    }, function(){
      if (window.openai && (typeof window.openai.sendFollowUpMessage === 'function' || window.openai.toolOutput)) {
        mode = 'compat';
        if (window.openai.toolOutput) apply({ structuredContent: window.openai.toolOutput });
      } else if (!current) {
        root.innerHTML = '<p class="loading">卡片已载入，但没连上聊天。请直接在聊天里继续。</p>';
      }
    });
})();
</script></body></html>`.replace('/*FONTS*/', function(){ return FONT_CSS; });


const VERSION = '0.8.1';
const UI_MIME = 'text/html;profile=mcp-app';
const protocols = ['2025-11-25', '2025-06-18', '2025-03-26', '2024-11-05'];

const tools = [...gameUiTools];
tools.push({
  name: 'show_game_view',
  title: '显示外部游戏画面',
  description: '把外部游戏引擎返回的画面显示成游戏卡片（和 render_game_ui 同一套卡片与皮肤）。如果你同时连着别的游戏引擎插件，先让它返回当前画面，再把那个 view 原样传进来。' +
    '会自动拆开场景末尾“📍 地点 | 🔍 线索 8 | ⏳ 时间线 2/15”这类状态行，并按存档对比上一回合标出变化。不执行动作，不改那个引擎的存档。',
  inputSchema: { type: 'object', properties: {
    view: { type: 'object', additionalProperties: true, description: '游戏引擎返回的 view 对象，原样传入。' },
    game_id: { type: 'string', maxLength: 40, description: '可选，本局编号；公开部署下建议带上，避免和别人的记录混在一起。' },
    theme: { type: 'string', maxLength: 60, description: '可选，题材词，用来选皮肤。' },
    card: { type: 'string', enum: ['自动', '选择', '状态', '背包', '人物', '地点', '地图'], description: '可选，默认没有选项时出状态卡。' }
  }, required: ['view'], additionalProperties: false },
  annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
  _meta: { ui: { resourceUri: GAME_UI_URI, visibility: ['app', 'model'] }, 'openai/outputTemplate': GAME_UI_URI, 'openai/widgetAccessible': true }
});

class ProbeError extends Error { constructor(message, code = -32602) { super(message); this.code = code; } }

async function callProbeTool(name, args, store, userId, meta, engineSkins) {
  if (name === 'show_game_view') {
    try { return await callGameViewTool(args, store, userId, meta, engineSkins); }
    catch (e) { throw new ProbeError(e instanceof GameUiError ? e.message : '游戏画面暂时无法显示，请直接用文字继续。'); }
  }
  if (gameUiTools.some(t => t.name === name)) {
    try { return await callGameUiTool(name, args, store, userId, meta); }
    catch (e) { throw new ProbeError(e instanceof GameUiError ? e.message : '游戏界面暂时无法生成，请直接用文字继续。'); }
  }
  throw new ProbeError('未知工具。');
}

const INSTRUCTIONS =
  '游戏界面层：本服务不含任何游戏规则和剧情，只负责把游戏状态画成卡片。' +
  '跑文字游戏时，每回合先写 2～4 句叙事，再调用一次 render_game_ui，把当前完整状态（中文字段名）交给它；新游戏第一次调用填 theme 并设 new_game 为 true。' +
  '新游戏第一次调用后，工具会给出本局编号 game_id，之后每次调用都原样带上。调用后不要在文字里重复数值、背包和选项。玩家点卡片上的选项后，那句行动会作为玩家消息发来，按它继续下一回合。' +
  '数值前后要一致，不要随手改数。如果同时连着别的游戏引擎，可以把它返回的画面交给 show_game_view 显示。';

const resourceMeta = (description, modes) => ({
  ui: { csp: { connectDomains: [], resourceDomains: [] }, prefersBorder: false },
  ...(modes ? { 'openai/ui': { availableDisplayModes: modes } } : {}),
  'openai/widgetDescription': description,
  'openai/widgetPrefersBorder': false
});

function json(body, status = 200) { return new Response(JSON.stringify(body), { status, headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store', 'x-content-type-options': 'nosniff' } }); }

async function processRpc(message, env, userId) {
  if (!message || message.jsonrpc !== '2.0' || typeof message.method !== 'string') return { jsonrpc: '2.0', id: message?.id ?? null, error: { code: -32600, message: 'Invalid Request' } };
  if (message.id === undefined) return null;
  const reply = result => ({ jsonrpc: '2.0', id: message.id, result });
  try {
    switch (message.method) {
      case 'initialize': return reply({ protocolVersion: protocols.includes(message.params?.protocolVersion) ? message.params.protocolVersion : protocols[0], capabilities: { tools: { listChanged: false }, resources: { listChanged: false }, extensions: { 'io.modelcontextprotocol/ui': { mimeTypes: [UI_MIME] } } }, serverInfo: { name: 'b-game-ui', version: VERSION }, instructions: INSTRUCTIONS });
      case 'ping': return reply({});
      case 'tools/list': return reply({ tools });
      case 'resources/list': return reply({ resources: [{ uri: GAME_UI_URI, name: '游戏界面卡片', mimeType: UI_MIME }] });
      case 'resources/templates/list': return reply({ resourceTemplates: [] });
      case 'resources/read': {
        if (message.params?.uri === GAME_UI_URI) return reply({ contents: [{ uri: GAME_UI_URI, mimeType: UI_MIME, text: gameUiHtml, _meta: resourceMeta('游戏界面卡片：按游戏状态自动显示数值、地点、背包、判定、线索、人物、任务和选项按钮；点选项会把整句行动作为玩家消息发出。') }] });
        throw new ProbeError('Resource not found', -32002);
      }
      case 'tools/call': {
        if (!userId) throw new ProbeError('需要登录后才能使用。', -32001);
        try { return reply(await callProbeTool(message.params?.name, message.params?.arguments ?? {}, env.PROBE_STORE, userId, message.params?._meta || {}, env.ENGINE_SKINS)); }
        catch (e) { console.error('tool_error', JSON.stringify({ tool: message.params?.name, code: e.code ?? -32603 })); return reply({ isError: true, content: [{ type: 'text', text: e instanceof ProbeError ? e.message : '服务暂时不可用，请稍后再试。' }] }); }
      }
      default: throw new ProbeError('Method not found', -32601);
    }
  } catch (e) { return { jsonrpc: '2.0', id: message.id, error: { code: e.code ?? -32603, message: e instanceof ProbeError ? e.message : 'Internal error' } }; }
}

const core = { async fetch(request, env) {
  const url = new URL(request.url);
  if (url.pathname === '/health') return json({ ok: true, version: VERSION, isolated: true, storageConfigured: !!env.PROBE_STORE });
  if (url.pathname !== '/mcp') return new Response('Not Found', { status: 404 });
  if (request.method !== 'POST') return new Response('Method Not Allowed', { status: 405, headers: { Allow: 'POST' } });
  const userId = request.headers.get('oai-authenticated-user-id');
  if (Number(request.headers.get('content-length') || 0) > 65536) return json({ error: 'Request too large' }, 413);
  let body;
  try { const text = await request.text(); if (text.length > 65536) return json({ error: 'Request too large' }, 413); body = JSON.parse(text); }
  catch { return json({ jsonrpc: '2.0', id: null, error: { code: -32700, message: 'Parse error' } }, 400); }
  if (Array.isArray(body)) return json({ jsonrpc: '2.0', id: null, error: { code: -32600, message: 'Batch requests are not supported' } }, 400);
  if (body?.method === 'tools/call' && !userId) return json({ jsonrpc: '2.0', id: body.id ?? null, error: { code: -32001, message: 'Authentication required' } }, 401);
  const result = await processRpc(body, env, userId);
  return result ? json(result) : new Response(null, { status: 202 });
} };



// 两种部署方式：
// 1) 私人：设置 PROBE_MCP_PATH（/probe-<64位十六进制>/mcp），只有知道这个地址的人能用，所有记录归同一个主人。
// 2) 公开：设置 PUBLIC_MODE=1，地址是 /mcp，谁都能连；每个玩家、每一局按 game_id 分开记录，旧记录 30 天后自动清理。
const TABLE_SQL = 'CREATE TABLE IF NOT EXISTS probe_objects (key TEXT PRIMARY KEY, value TEXT NOT NULL, etag TEXT NOT NULL)';
let tableReady = false;

export class D1Store {
  constructor(db) { this.db = db; }
  // 公开部署省掉手动建表：第一次请求时自动建。
  async ensureTable() { if (!tableReady) { await this.db.prepare(TABLE_SQL).bind().run(); tableReady = true; } }
  // 大约每 200 次请求清理一次 30 天没更新的记录，防止数据库越积越多。
  async sweep() {
    if (Math.random() > 0.005) return;
    const cutoff = new Date(Date.now() - 30 * 864e5).toISOString();
    try { await this.db.prepare("DELETE FROM probe_objects WHERE json_extract(value, '$.updatedAt') < ?1").bind(cutoff).run(); } catch {}
  }
  async get(key) {
    const row = await this.db.prepare('SELECT value, etag FROM probe_objects WHERE key = ?1').bind(key).first();
    return row ? { etag: row.etag, json: async () => JSON.parse(row.value) } : null;
  }
  async put(key, value, options) {
    const digest = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(value));
    const etag = [...new Uint8Array(digest)].map(n => n.toString(16).padStart(2, '0')).join('');
    const condition = options.onlyIf;
    let statement;
    if (condition instanceof Headers && condition.get('If-None-Match') === '*') {
      statement = this.db.prepare('INSERT INTO probe_objects (key, value, etag) VALUES (?1, ?2, ?3) ON CONFLICT(key) DO NOTHING').bind(key, value, etag);
    } else if (typeof condition?.etagMatches === 'string') {
      statement = this.db.prepare('UPDATE probe_objects SET value = ?1, etag = ?2 WHERE key = ?3 AND etag = ?4').bind(value, etag, key, condition.etagMatches);
    } else {
      throw new Error('Conditional writes are required');
    }
    const result = await statement.run();
    if (!result.success) throw new Error('Test database write failed');
    return result.meta.changes === 1 ? { etag } : null;
  }
}

function notFound() { return new Response('Not Found', { status: 404, headers: { 'cache-control': 'no-store' } }); }
export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (url.pathname === '/health' && request.method === 'GET') {
      return Response.json({ ok: true, isolated: true, build: 'cloudflare-0.8.1' }, { headers: { 'cache-control': 'no-store' } });
    }
    const isPublic = String(env.PUBLIC_MODE || '') === '1';
    const isPrivate = /^\/probe-[a-f0-9]{64}\/mcp$/.test(env.PROBE_MCP_PATH || '') && url.pathname === env.PROBE_MCP_PATH;
    if (url.search || !(isPrivate || (isPublic && url.pathname === '/mcp'))) return notFound();
    if (!env.PROBE_DB) return new Response('Storage unavailable', { status: 503 });
    url.pathname = '/mcp';
    const headers = new Headers(request.headers);
    // Cloudflare 不提供可信的登录身份，客户端发来的身份一律不信。
    headers.delete('oai-authenticated-user-email');
    headers.delete('oai-authenticated-user-full-name');
    headers.set('oai-authenticated-user-id', isPrivate ? 'isolated-cloudflare-probe-owner-v1' : 'public');
    const store = new D1Store(env.PROBE_DB);
    if (isPublic && !isPrivate) { await store.ensureTable(); await store.sweep(); }
    return core.fetch(new Request(url, { method: request.method, headers, body: ['GET', 'HEAD'].includes(request.method) ? undefined : request.body, duplex: 'half' }), { PROBE_STORE: store, ENGINE_SKINS: env.ENGINE_SKINS });
  }
};
